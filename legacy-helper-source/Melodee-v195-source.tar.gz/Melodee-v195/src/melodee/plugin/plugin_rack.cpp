// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 Kerem Kilic (Ellic Studio)
#include "melodee/plugin/prism_spectrum.h"
#include "melodee/plugin/strings_info.h"
#include "melodee/plugin/orchestra_info.h"
#include "melodee/plugin/melody_pattern.h"
#include "melodee/plugin/plugin_rack.h"
#include "melodee/plugin/meter_page.h"
#include "melodee/plugin/scope_peaks.h"
#include "melodee/engine/dsp.h"
#include "melodee/engine/engine_host.h"
#include "melodee/plugin/clap_instance.h"
#include "melodee/plugin/idle_gate.h"
#include "melodee/plugin/plugin_runner.h"
#include "melodee/plugin/plugin_support.h"
#include "melodee/plugin/rate_bridge.h"
#include "melodee/plugin/nam.h"
#include "melodee/plugin/vst2_bridge_instance.h"
#include "melodee/plugin/vst2_instance.h"
#include <juce_audio_processors_headless/juce_audio_processors_headless.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <system_error>
#include <unistd.h>
#if defined(__GLIBC__)
#include <malloc.h>
#endif

namespace melodee {
namespace fs = std::filesystem;

namespace {
constexpr int bridge_block_ms = 40; // a 32-bit plug-in that has not answered by then counts as crashed

// JUCE's message thread, for VST3 plug-ins: made and torn down on it.
class MessageThread {
public:
    void start() {
        std::lock_guard<std::mutex> once(starting); // two racks' threads (the live one's and a print host's) may ask at once
        if (thread.joinable()) return;
        std::mutex m;
        std::condition_variable up;
        bool ready = false;
        thread = std::thread([&] {
            auto* messages = juce::MessageManager::getInstance();
            messages->setCurrentThreadAsMessageThread();
            { std::lock_guard<std::mutex> held(m); ready = true; }
            up.notify_one();
            messages->runDispatchLoop();
        });
        std::unique_lock<std::mutex> held(m);
        up.wait(held, [&] { return ready; });
    }
    void stop() {
        std::lock_guard<std::mutex> once(starting);
        if (!thread.joinable()) return;
        juce::MessageManager::getInstance()->stopDispatchLoop();
        thread.join();
        juce::MessageManager::deleteInstance();
    }
    bool running() const { return thread.joinable(); }
    template <class F> void run(F&& f) { if (running()) juce::MessageManager::callSync(std::forward<F>(f)); else f(); }
private:
    std::thread thread;
    std::mutex starting;
};
MessageThread& message_thread() { static MessageThread t; return t; }
// Racks alive: the message thread stops with the last (a print host's rack goes while the live one plays on).
std::atomic<unsigned> racks {0};

void put(char* to, size_t room, const std::string& text) {
    std::snprintf(to, room, "%s", text.c_str());
}

// A plain number as a plug-in may write it ("75.000000", "0.010000"): without the zeros that say nothing.
std::string tidy(std::string text) {
    size_t dot = text.find('.');
    if (dot == std::string::npos || text.find_first_not_of("-+0123456789.") != std::string::npos) return text;
    size_t last = text.find_last_not_of('0');
    text.erase(last == dot ? dot : last + 1);
    return text.empty() || text == "-" ? "0" : text == "-0" ? "0" : text;
}

// Where plug-ins are copied to run from: RAM (/run on the MPC; the card is noexec).
fs::path stage_root() {
    if (const char* own = std::getenv("MELODEE_PLUGIN_STAGE")) return own;
    std::error_code error;
    if (fs::is_directory("/run", error) && access("/run", W_OK) == 0) return "/run/melodee-plugins/stage";
    return fs::temp_directory_path(error) / "melodee-plugins/stage";
}

// The folders beside a plug-in on the card, linked beside its copy: one that looks beside itself for its data finds
// it there (Surge XT: its SurgeXTData folder, patches and wavetables).
void link_neighbours(const fs::path& from, const fs::path& to) {
    std::error_code e;
    for (auto it = fs::directory_iterator(from.parent_path(), e); !e && it != fs::directory_iterator(); it.increment(e)) {
        std::error_code f;
        auto name = it->path().filename();
        if (it->path() == from || name.string().empty() || name.string()[0] == '.' || !it->is_directory(f)) continue;
        if (!fs::exists(to / name, f)) fs::create_directory_symlink(it->path(), to / name, f);
    }
}

// A plug-in's files into `to`: a VST3 bundle without other machines' builds, an Open MPC folder whole, a .so alone;
// the folders beside it linked.
bool stage_copy(const PluginFile& file, const fs::path& to, std::string& error) {
    std::error_code e;
    fs::create_directories(to, e);
    fs::path from(file.path);
    link_neighbours(from, to);
    if (!fs::is_directory(from, e)) {
        fs::copy_file(from, to / from.filename(), fs::copy_options::overwrite_existing, e);
        if (e) { error = "Could not copy: " + e.message(); return false; }
        return true;
    }
    fs::path target = to / from.filename();
    fs::create_directories(target, e);
    for (auto it = fs::recursive_directory_iterator(from, e); !e && it != fs::recursive_directory_iterator(); it.increment(e)) {
        auto rel = fs::relative(it->path(), from, e);
        auto first = rel.begin(), second = std::next(first);
        // Contents/<other machine>: not needed here.
        if (file.format == PluginFormat::Vst3 && *first == "Contents" && second != rel.end() && *second != "aarch64-linux" && *second != "Resources") {
            if (it->is_directory(e)) it.disable_recursion_pending();
            continue;
        }
        if (it->is_directory(e)) fs::create_directories(target / rel, e);
        else fs::copy_file(it->path(), target / rel, fs::copy_options::overwrite_existing, e);
        if (e) { error = "Could not copy: " + e.message(); return false; }
    }
    return !e;
}

// The staged copy of the plug-in's library (the same place inside `to`).
std::string staged_library(const PluginFile& file, const fs::path& to) {
    fs::path from(file.path);
    std::error_code e;
    if (!fs::is_directory(from, e)) return (to / from.filename()).string();
    return (to / from.filename() / fs::relative(file.library, from, e)).string();
}
std::string staged_path(const PluginFile& file, const fs::path& to) { return (to / fs::path(file.path).filename()).string(); }

// A VST3 or LV2 bundle or a CLAP library: listed by its file's name until it is opened, then by its plug-ins' own
// names.
bool named_inside(PluginFormat format) {
    return format == PluginFormat::Vst3 || format == PluginFormat::Lv2 || format == PluginFormat::Clap;
}

// The formats JUCE hosts: made, scanned and freed on its message thread.
bool juce_hosted(PluginFormat format) { return format == PluginFormat::Vst3 || format == PluginFormat::Lv2; }
// A host for one of them. An LV2 one is a lilv world of its own (the plug-ins it opens keep it), so two copies of the
// same bundle staged for two entries never meet in one world.
std::unique_ptr<juce::AudioPluginFormat> juce_format(PluginFormat format) {
    if (format == PluginFormat::Lv2) return std::make_unique<juce::LV2PluginFormatHeadless>();
    return std::make_unique<juce::VST3PluginFormatHeadless>();
}
// Whether a JUCE-described plug-in is an instrument. JUCE's LV2 host asks for lv2:GeneratorPlugin up the plug-in's
// class tree, which it cannot walk without lv2core's own description (every LV2 comes back as an effect, of category
// "Plugin"), so for LV2 one with audio out and no audio in counts as an instrument.
bool described_instrument(const juce::PluginDescription& d) {
    if (d.isInstrument) return true;
    return d.pluginFormatName == "LV2" && d.numInputChannels == 0 && d.numOutputChannels > 0;
}

// The plug-ins a staged bundle holds, by a host made for it on the message thread. An LV2 one makes its plug-ins
// only from the world that read their bundle, so the same host makes the one picked (then is freed there too).
std::unique_ptr<juce::AudioPluginFormat> juce_types(PluginFormat format, const std::string& path,
                                                   juce::OwnedArray<juce::PluginDescription>& types) {
    std::unique_ptr<juce::AudioPluginFormat> host;
    message_thread().start();
    message_thread().run([&] {
        host = juce_format(format);
        host->findAllTypesForFile(types, juce::String(path));
    });
    return host;
}
void free_juce_host(std::unique_ptr<juce::AudioPluginFormat>& host) { message_thread().run([&] { host.reset(); }); }

bool hidden(const juce::AudioProcessorParameter& p) {
    auto name = p.getName(64);
    return !p.isAutomatable() || name.startsWith("MIDI Ch.") || name.startsWith("MIDI CC");
}

// The programs PRESETS lists: those with a name. Plug-ins that keep a fixed
// number of slots name the unused ones "(empty)" (TONE3000), or leave them blank.
PluginProgramList named_programs(juce::AudioPluginInstance& instance, bool folders) {
    std::vector<PluginProgram> out;
    for (int i = 0; i < instance.getNumPrograms(); ++i) {
        auto name = instance.getProgramName(i).trim();
        if (name.isEmpty() || name.equalsIgnoreCase("(empty)")) continue;
        const int slash = folders ? name.indexOfChar('/') : -1;
        if (slash > 0 && slash + 1 < name.length())
            out.push_back({i, name.substring(slash + 1).toStdString(), name.substring(0, slash).toStdString()});
        else
            out.push_back({i, name.toStdString(), {}});
    }
    return PluginProgramList(std::move(out));
}

// Where Melodee keeps what a CLAP plug-in's preset files said (plugin/clap_instance.h), in the plug-ins' home on the
// card: read again only where a file changed. None without a card.
juce::File clap_preset_cache(const std::string& home, const std::string& id) {
    if (home.empty()) return {};
    std::string name = id;
    for (auto& c : name) if (!std::isalnum((unsigned char) c) && c != '.' && c != '-' && c != '_') c = '_';
    return juce::File(juce::String((fs::path(home) / ".cache" / "melodee" / ("clap-presets-" + name + ".txt")).string()));
}

// Where plug-ins keep presets and settings: Melodee/Plugin Data on the card,
// as their home folder. They lay it out as on a Linux computer: most under
// .config (TONE3000: .config/TONE3000/Presets), which a Mac's Finder hides.
fs::path plugin_home(const std::string& card_top) {
    if (const char* own = std::getenv("MELODEE_PLUGIN_HOME")) return own;
    if (card_top.empty()) return {};
    return fs::path(card_top) / "Melodee" / "Plugin Data";
}

// Whether `inside` is `folder` or in it, part by part (so /media/card2 is not in /media/card).
bool under(const fs::path& folder, const fs::path& inside) {
    if (folder.empty()) return false;
    auto rel = inside.lexically_normal().lexically_relative(folder.lexically_normal());
    return !rel.empty() && *rel.begin() != "..";
}

} // namespace

// Melodee's transport as a plug-in hears it (plugin/host_time.h): set before each of its processBlocks.
class PluginClock final : public juce::AudioPlayHead {
public:
    juce::Optional<PositionInfo> getPosition() const override { return position; }
    PositionInfo position;
};

// What the audio thread runs (PluginRunner): the plug-in, its buffers made up
// front, and MIDI gathered between renders. Made on the rack's thread. A
// plug-in at a rate of its own (an Open MPC one at 44.1 kHz) is heard at the
// device's through a PluginRateBridge.
class PluginHandle final : public PluginRunner {
public:
    PluginHandle(std::unique_ptr<juce::AudioPluginInstance> plugin, bool is_instrument, double rate, double plugin_rate)
        : instance(std::move(plugin)), instrument(is_instrument), sample_rate(rate), plugin_rate(plugin_rate > 0 ? plugin_rate : rate) {
        channels = std::max({2, instance->getTotalNumInputChannels(), instance->getTotalNumOutputChannels()});
        memory.assign(size_t(channels) * EngineHost::block, 0.0f);
        bridge.reset(unsigned(std::lround(plugin_rate)), unsigned(std::lround(rate)), is_instrument);
        midi_in.ensureSize(8192);
        auto* bypass = instance->getBypassParameter(); // the slot's own Bypass does that job
        for (auto& p : instance->getParameters()) if (!hidden(*p) && p != bypass) shown.push_back(p->getParameterIndex());
        instance->setPlayHead(&clock);
        idle.reset(is_instrument, this->plugin_rate);
    }
    ~PluginHandle() override {
        if (!instance) return;
        instance->releaseResources();
        instance->setPlayHead(nullptr); // the clock goes before it
    }

    void midi(uint8_t status, uint8_t data1, uint8_t data2) override {
        if (pending_count < pending.size()) pending[pending_count++] = {status, data1, data2};
        idle.midi(status, data1, data2);
    }
    void silence() override {
        for (uint8_t ch = 0; ch < 16; ++ch) {
            midi(uint8_t(0xb0 | ch), 120, 0); // all sound off
            midi(uint8_t(0xb0 | ch), 123, 0); // all notes off
        }
    }
    // Roadmap P4: what the plug-in reports (at its own rate, so scaled to the device's) and the rate bridge's.
    unsigned latency() const override {
        int own = std::max(instance->getLatencySamples(), 0);
        return unsigned(std::lround(own * (sample_rate / plugin_rate))) + bridge.latency();
    }
    void parameter_changed() { idle.request_wake(); }
    // Not on the audio thread: blocks of silence through it before it is offered (PluginRack::load), so its code and
    // buffers are paged in, and whatever it does on its first calls is done, here rather than in the audio thread's
    // first blocks with it.
    // It hears the transport stopped at the top meanwhile: the engine host's clock belongs to the audio thread.
    void warm_up(unsigned blocks = 8) {
        std::array<float, EngineHost::block> l {}, r {};
        warming = true;
        for (unsigned b = 0; b < blocks; ++b) {
            l.fill(0.0f);
            r.fill(0.0f);
            render(l.data(), r.data(), EngineHost::block);
        }
        warming = false;
        load.store(0.0f, std::memory_order_relaxed); // what it costs to play counts from here
    }
    void render(float* left, float* right, unsigned frames) override {
        frames = std::min(frames, EngineHost::block);
        if (!frames) return;
        auto t0 = std::chrono::steady_clock::now();
        follow_clock(frames);
        // Asleep (plugin/idle_gate.h): not run at all. An effect's input is as quiet as its output; it gives silence.
        bool sleeping = !warming && idle.asleep(pending_count > 0, now.playing, instrument ? nullptr : left, instrument ? nullptr : right, frames);
        asleep.store(sleeping, std::memory_order_relaxed);
        if (sleeping) {
            if (!instrument) { std::fill(left, left + frames, 0.0f); std::fill(right, right + frames, 0.0f); }
            load.store(load.load(std::memory_order_relaxed) * 0.95f, std::memory_order_relaxed);
            return;
        }
        if (bridge.converting()) bridge.render(left, right, frames, [&](float* l, float* r, unsigned n) { run(l, r, n, false); });
        else run(left, right, frames, instrument);
        double took = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        float share = float(took / (frames / sample_rate));
        load.store(load.load(std::memory_order_relaxed) * 0.95f + share * 0.05f, std::memory_order_relaxed);
    }
    // One processBlock of `frames`: an effect's input in left/right; the output added there (`add`) or in their place.
    void run(float* left, float* right, unsigned frames, bool add) {
        int ins = instance->getTotalNumInputChannels(), outs = instance->getTotalNumOutputChannels();
        std::array<float*, 64> pointers {};
        for (int c = 0; c < channels && c < 64; ++c) pointers[size_t(c)] = memory.data() + size_t(c) * EngineHost::block;
        juce::AudioBuffer<float> buffer(pointers.data(), std::min(channels, 64), int(frames));
        buffer.clear();
        if (!instrument) {
            if (ins == 1) for (unsigned f = 0; f < frames; ++f) pointers[0][f] = 0.5f * (left[f] + right[f]);
            else if (ins >= 2) { std::copy(left, left + frames, pointers[0]); std::copy(right, right + frames, pointers[1]); }
        }
        midi_in.clear();
        for (unsigned n = 0; n < pending_count; ++n) {
            const auto& m = pending[n];
            uint8_t bytes[3] {m.status, m.data1, m.data2};
            int size = (m.status & 0xf0) == 0xc0 || (m.status & 0xf0) == 0xd0 ? 2 : 3;
            midi_in.addEvent(bytes, size, 0);
        }
        pending_count = 0;
        stamp_clock(frames);
        instance->processBlock(buffer, midi_in);
        if (compressor_history_enabled && outs >= 2) {
            float input_peak = 0, output_peak = 0;
            for (unsigned i = 0; i < frames; ++i) {
                input_peak = std::max({input_peak, std::abs(left[i]), std::abs(right[i])});
                output_peak = std::max({output_peak, std::abs(pointers[0][i]), std::abs(pointers[1][i])});
            }
            const auto encode = [](float peak) { return unsigned(1023 * std::min(peak, 1.f)); };
            const unsigned in = encode(input_peak), out = encode(output_peak);
            auto peaks = compressor_peaks.load(std::memory_order_relaxed);
            unsigned next;
            do {
                next = std::max(in, peaks & 1023u) | (std::max(out, peaks >> 10) << 10);
            } while (!compressor_peaks.compare_exchange_weak(peaks, next, std::memory_order_relaxed));
        }
        const bool analyze = !warming && analyzer_focus && analyzer_focus->load(std::memory_order_relaxed) == analyzer_entry;
        if (analyze && outs > 0) {
            const unsigned head = spectrum_head.load(std::memory_order_relaxed);
            const auto encode = [](float value) {
                return std::isfinite(value) ? uint16_t(int16_t(std::lround(32767 * std::clamp(value, -1.f, 1.f)))) : uint16_t(0);
            };
            for (unsigned i = 0; i < frames; ++i) {
                const uint32_t left = encode(pointers[0][i]);
                const uint32_t right = encode(pointers[outs > 1 ? 1 : 0][i]);
                spectrum_ring[(head + i) % prism_fft_size].store(left | (right << 16), std::memory_order_relaxed);
            }
            spectrum_head.store(head + frames, std::memory_order_release);
        }
        if (analyze && outs > 0) {
            unsigned index = scope_head.load(std::memory_order_relaxed);
            const unsigned stride = waveform_scope ? 24 : frames;
            const auto* left_out = pointers[0];
            const auto* right_out = pointers[outs > 1 ? 1 : 0];
            for (unsigned offset = 0; offset < frames; offset += stride) {
                const auto at = index++ % scope.size();
                const auto count = std::min(stride, frames - offset);
                scope[at].store(scope_column(left_out + offset, count), std::memory_order_relaxed);
                scope_right[at].store(scope_column(right_out + offset, count), std::memory_order_relaxed);
            }
            scope_head.store(index, std::memory_order_release);
        }
        if (outs <= 0) {
            if (!add) { std::fill(left, left + frames, 0.0f); std::fill(right, right + frames, 0.0f); }
            return;
        }
        const float* l = pointers[0];
        const float* r = outs >= 2 ? pointers[1] : pointers[0];
        idle.heard(l, r, frames);
        auto safe = [](float x) { return std::isfinite(x) ? std::clamp(x, -8.0f, 8.0f) : 0.0f; };
        if (add) for (unsigned f = 0; f < frames; ++f) { left[f] += safe(l[f]); right[f] += safe(r[f]); }
        else for (unsigned f = 0; f < frames; ++f) { left[f] = safe(l[f]); right[f] = safe(r[f]); }
    }

    std::unique_ptr<juce::AudioPluginInstance> instance;
    const bool instrument;
    const double sample_rate;
    const double plugin_rate;            // what the plug-in itself runs at (an Open MPC one: 44.1 kHz)
    std::vector<int> shown;              // parameter indices the pages show, in order
    bool qlinks = false;
    bool compressor_history_enabled = false;
    std::atomic<unsigned> compressor_peaks {0};
    std::array<uint32_t, 64> compressor_history {};
    unsigned compressor_history_head = 0;
    std::chrono::steady_clock::time_point compressor_history_at {};

    uint8_t instrument_visual = 0;
    std::array<std::array<char,24>,192> visual_names {};
    unsigned visual_count=0;
    std::array<std::atomic<uint32_t>, prism_fft_size> spectrum_ring {};
    std::atomic<unsigned> spectrum_head {0};

    bool waveform_scope = false;
    std::shared_ptr<std::atomic<unsigned>> analyzer_focus;
    unsigned analyzer_entry = max_plugins;
    std::array<std::atomic<uint32_t>, 64> scope {};
    decltype(scope) scope_right {};
    std::atomic<unsigned> scope_head {0};
    bool nam = false;                    // Neural Amp Modeler: shorter card names (plugin/nam.h)
    std::atomic<bool> transport {true};  // TRANSPORT: it hears Play and Stop (off: always stopped), set by the rack
    std::atomic<float> load {0};         // share of a block's time
    std::atomic<bool> asleep {false};    // its last render skipped (plugin/idle_gate.h)
    std::string stage;                   // the RAM copy it runs from, removed with it
    PluginFormat format = PluginFormat::Vst3;
    PluginProgramList programs;          // its named programs, as it listed them on opening (a CLAP one's: once found)
    int program = -1;                    // the one picked last here (under the rack's lock)
    bool switching = false;              // a pick queued for the rack's thread (under the rack's lock)
    bool finding = false;                // a CLAP plug-in's presets still being looked for (under the rack's lock)

private:
    // The engine host's clock at its block's start (engine/effects.h, EffectClock), counted on by the device frames
    // this plug-in has played of the block already: an instrument is played in parts, between the block's steps.
    void follow_clock(unsigned frames) {
        if (warming) { now = EffectClock {}; quarters = 0; per_frame = 0; return; }
        now = *effect_clock_now;
        if (!transport.load(std::memory_order_relaxed)) now.playing = false; // TRANSPORT off: the place, never Play
        if (now.block != block_seen) { block_seen = now.block; into_block = 0; }
        double quarter = std::max(now.quarter, 1.0);
        quarters = now.playing ? now.song + into_block / quarter : now.song;
        per_frame = now.playing ? sample_rate / plugin_rate / quarter : 0.0; // quarter notes a frame at its rate
        into_block += frames;
    }
    // Where this processBlock of `frames` (at the plug-in's rate) starts; the next one starts after it.
    void stamp_clock(unsigned frames) {
        using Head = juce::AudioPlayHead;
        double bar = 4.0 * now.sig_beats / now.sig_unit, bpm = now.bpm > 0 ? now.bpm : 120.0;
        double bars = std::floor(quarters / bar + 1e-9), seconds = quarters * 60.0 / bpm;
        Head::PositionInfo p;
        p.setIsPlaying(now.playing);
        p.setIsRecording(false);
        p.setIsLooping(false);
        p.setBpm(bpm);
        p.setTimeSignature(Head::TimeSignature {int(now.sig_beats), int(now.sig_unit)});
        p.setPpqPosition(quarters);
        p.setPpqPositionOfLastBarStart(bars * bar);
        p.setBarCount(int64_t(bars));
        p.setTimeInSeconds(seconds);
        p.setTimeInSamples(int64_t(std::llround(seconds * plugin_rate)));
        clock.position = p;
        quarters += frames * per_frame;
    }

    struct Midi { uint8_t status = 0, data1 = 0, data2 = 0; };
    PluginClock clock;
    EffectClock now;           // the engine host's clock as this render found it
    uint64_t block_seen = ~uint64_t(0);
    double into_block = 0;     // device frames of that block played already
    double quarters = 0;       // where the next processBlock starts, quarter notes from the song's top
    double per_frame = 0;      // and how far a frame at the plug-in's rate moves it
    bool warming = false;
    PluginRateBridge bridge;
    IdleGate idle;             // when it may sleep
    std::array<Midi, 512> pending {};
    unsigned pending_count = 0;
    int channels = 2;
    std::vector<float> memory;
    juce::MidiBuffer midi_in;
};

static void follow_melody_key(PluginHandle* handle,const std::string& name,unsigned root,unsigned scale) {
    if(!handle)return;
    const int base=melody::parameter_base(name,unsigned(handle->shown.size()));
    if(base<0)return;
    const auto& params=handle->instance->getParameters();
    if(params[handle->shown[base+12]]->getValue()<.5f)return;
    const float key=float(root%12)/11,mode=float(std::min(scale,12u))/12;
    if(std::abs(params[handle->shown[base+2]]->getValue()-key)>.0001f)params[handle->shown[base+2]]->setValue(key);
    if(std::abs(params[handle->shown[base+3]]->getValue()-mode)>.0001f)params[handle->shown[base+3]]->setValue(mode);
}

PluginRack::PluginRack(EngineHost& engine, std::string stage) : host(engine), stage_tag(std::move(stage)) {
    racks.fetch_add(1);
    thread = std::thread([this] { run(); });
}

PluginRack::~PluginRack() {
    {
        std::lock_guard<std::mutex> held(lock);
        stopping = true;
    }
    wake.notify_all();
    if (thread.joinable()) thread.join();
    // The audio has stopped: whatever the host held is ours to free.
    std::vector<std::unique_ptr<PluginHandle>> all;
    {
        std::lock_guard<std::mutex> held(lock);
        all.swap(handles);
    }
    for (auto& h : all) {
        std::string stage = h->stage;
        if (juce_hosted(h->format)) message_thread().run([&] { h.reset(); });
        else h.reset();
        std::error_code e;
        if (!stage.empty()) fs::remove_all(stage, e);
    }
    if (racks.fetch_sub(1) == 1) message_thread().stop();
    give_back_memory();
}

void PluginRack::push(Job job) {
    {
        std::lock_guard<std::mutex> held(lock);
        jobs.push_back(std::move(job));
    }
    wake.notify_one();
}

bool PluginRack::referenced(const Project& project, unsigned entry) const { return plugin_used_by(project, entry); }

bool PluginRack::asleep(unsigned entry) const {
    std::lock_guard<std::mutex> held(lock);
    return entry < max_plugins && entries[entry].asleep;
}

void PluginRack::sync(const Project& project, uint32_t asleep) {
    double rate = dsp::sample_rate();
    std::vector<Job> wanted;
    bool moved = false;
    {
        std::lock_guard<std::mutex> held(lock);
        melody_root=project.root;melody_scale=project.scale;
        for (unsigned e = 0; e < max_plugins; ++e) {
            auto& entry = entries[e];
            follow_melody_key(entry.live,entry.file.name,melody_root,melody_scale);
            entry.transport = project.plugins[e].transport;
            if (entry.live) entry.live->transport.store(entry.transport, std::memory_order_relaxed);
            entry.preset = project.plugins[e].preset;
            if (entry.live && entry.live->program < 0) entry.live->program = program_keyed(entry.live->programs, entry.preset);
            std::string want = project.plugins[e].used() && referenced(project, e) ? project.plugins[e].path : "";
            int32_t id = want.empty() ? 0 : project.plugins[e].id;
            // Freeze plan F2d: used only by deep-frozen tracks, it sleeps (plugin/plugin_sleep.h).
            bool only_asleep = !want.empty() && asleep && !plugin_used_awake(project, e, asleep);
            auto step = plan_plugin(entry, want, id, only_asleep, rate, entry.live != nullptr);
            if (step == PluginStep::Keep) continue;
            moved = true;
            entry.error.clear();
            switch (step) {
            case PluginStep::Keep: case PluginStep::Changed: break;
            case PluginStep::Sleep: wanted.push_back({Job::Kind::Sleep, e, entry.generation, {}, 0}); break;
            case PluginStep::Unload: wanted.push_back({Job::Kind::Unload, e, entry.generation, {}, 0}); break;
            case PluginStep::Rerate: { // keep what it is now through the reload
                juce::MemoryBlock block;
                entry.live->instance->getStateInformation(block);
                entry.state.assign(static_cast<const uint8_t*>(block.getData()), static_cast<const uint8_t*>(block.getData()) + block.getSize());
                [[fallthrough]];
            }
            case PluginStep::Load: wanted.push_back({Job::Kind::Load, e, entry.generation, want, rate, id}); break;
            }
        }
    }
    if (!moved) return;
    changed();
    for (auto& job : wanted) push(std::move(job));
}

void PluginRack::set_states(PluginStates states) {
    std::lock_guard<std::mutex> held(lock);
    for (unsigned e = 0; e < max_plugins; ++e) {
        entries[e].state = std::move(states[e]);
        entries[e].reload = true; // a new project: every entry it uses loads again, with its state
    }
}

PluginStates PluginRack::states() const {
    PluginStates out;
    std::lock_guard<std::mutex> held(lock);
    for (unsigned e = 0; e < max_plugins; ++e) {
        const auto& entry = entries[e];
        if (entry.live && entry.status == PluginStatus::Ready) {
            juce::MemoryBlock block;
            entry.live->instance->getStateInformation(block);
            out[e].assign(static_cast<const uint8_t*>(block.getData()), static_cast<const uint8_t*>(block.getData()) + block.getSize());
        } else {
            out[e] = entry.state;
        }
    }
    return out;
}

void PluginRack::clone(unsigned entry, unsigned copy) {
    if (entry >= max_plugins || copy >= max_plugins) return;
    std::lock_guard<std::mutex> held(lock);
    auto& from = entries[entry];
    std::vector<uint8_t> state = from.state;
    if (from.live && from.status == PluginStatus::Ready) {
        juce::MemoryBlock block;
        from.live->instance->getStateInformation(block);
        state.assign(static_cast<const uint8_t*>(block.getData()), static_cast<const uint8_t*>(block.getData()) + block.getSize());
    }
    entries[copy].state = std::move(state);
}

std::string PluginRack::summary() const {
    static const char* const states[] {"none", "opening", "ready", "failed", "crashed"};
    std::string out;
    std::lock_guard<std::mutex> held(lock);
    for (unsigned e = 0; e < max_plugins; ++e) {
        const auto& entry = entries[e];
        if (entry.path.empty()) continue;
        auto status = entry.status;
        if (entry.asleep) { // freeze plan F2d
            std::string name = entry.file.name.empty() ? fs::path(entry.path).stem().string() : entry.file.name;
            for (auto& ch : name) if (ch == ' ' || ch == ',' || ch == ':') ch = '_';
            if (!out.empty()) out += ',';
            out += std::to_string(e) + ":asleep:" + name + ':' + format_tag(entry.file.format) + ":0";
            continue;
        }
        if (auto* h = entry.live)
            if (auto* bridged = dynamic_cast<Vst2BridgeInstance*>(h->instance.get()); bridged && bridged->bridgeDied()) status = PluginStatus::Crashed;
        std::string name = entry.file.name.empty() ? fs::path(entry.path).stem().string() : entry.file.name;
        for (auto& ch : name) if (ch == ' ' || ch == ',' || ch == ':') ch = '_';
        int load = entry.live ? int(entry.live->load.load(std::memory_order_relaxed) * 1000) : 0;
        if (!out.empty()) out += ',';
        out += std::to_string(e) + ':' + states[unsigned(status) % 5] + ':' + name + ':' + format_tag(entry.file.format) + ':' + std::to_string(load);
    }
    return out.empty() ? "none" : out;
}

PluginRack::Usage PluginRack::usage() const {
    Usage out;
    std::lock_guard<std::mutex> held(lock);
    for (const auto& entry : entries) {
        if (!entry.live || entry.status != PluginStatus::Ready) continue;
        ++out.loaded;
        out.load += entry.live->load.load(std::memory_order_relaxed);
    }
    return out;
}

void PluginRack::reload(unsigned entry) {
    if (entry >= max_plugins) return;
    std::lock_guard<std::mutex> held(lock);
    auto& e = entries[entry];
    if (e.live && e.status == PluginStatus::Ready) {
        auto* bridged = dynamic_cast<Vst2BridgeInstance*>(e.live->instance.get());
        if (!bridged || !bridged->bridgeDied()) { // a working one keeps what it is now; a dead bridge has nothing to say
            juce::MemoryBlock block;
            e.live->instance->getStateInformation(block);
            e.state.assign(static_cast<const uint8_t*>(block.getData()), static_cast<const uint8_t*>(block.getData()) + block.getSize());
        }
    }
    e.reload = true;
}

std::vector<uint8_t> PluginRack::state(unsigned entry) const {
    if (entry >= max_plugins) return {};
    std::lock_guard<std::mutex> held(lock);
    const auto& e = entries[entry];
    if (!e.live || e.status != PluginStatus::Ready) return e.state;
    juce::MemoryBlock block;
    e.live->instance->getStateInformation(block);
    return {static_cast<const uint8_t*>(block.getData()), static_cast<const uint8_t*>(block.getData()) + block.getSize()};
}

void PluginRack::restore(unsigned entry, std::vector<uint8_t> state) {
    if (entry >= max_plugins) return;
    std::lock_guard<std::mutex> held(lock);
    entries[entry].state = std::move(state);
    entries[entry].reload = true; // plan_plugin keeps this state for whichever plug-in loads
}

PluginStatus PluginRack::status(unsigned entry) const {
    if (entry >= max_plugins) return PluginStatus::None;
    std::lock_guard<std::mutex> held(lock);
    return entries[entry].status;
}

int PluginRack::instrument(unsigned entry) const {
    if (entry >= max_plugins) return -1;
    std::lock_guard<std::mutex> held(lock);
    const auto& e = entries[entry];
    if (e.live) return e.live->instrument ? 1 : 0;
    return e.file.instrument;
}

void PluginRack::drum_voices(unsigned entry, DrumVoices& out) const {
    out = {};
    if (entry >= max_plugins) return;
    out.entry = uint8_t(entry);
    std::lock_guard<std::mutex> held(lock);
    for (const auto& v : entries[entry].file.drums) {
        unsigned k = unsigned(v.key) - DrumVoices::first;
        if (v.key < DrumVoices::first || k >= DrumVoices::keys) continue;
        put(out.names[k].data(), out.names[k].size(), v.name);
    }
}

void PluginRack::panel(unsigned entry, unsigned row, PluginPanel& out) const {
    analyzer_focus->store(entry, std::memory_order_relaxed);
    out = {};
    out.entry = uint8_t(entry);
    if (entry >= max_plugins) return;
    std::lock_guard<std::mutex> held(lock);
    const auto& e = entries[entry];
    out.status = e.status;
    put(out.name, sizeof(out.name), e.file.name.empty() ? fs::path(e.path).stem().string() : e.file.name);
    put(out.format, sizeof(out.format), e.path.empty() ? "" : format_tag(e.file.format));
    put(out.error, sizeof(out.error), e.error);
    out.instrument = e.file.instrument == 1;
    auto* h = e.live;
    if (!h || e.status != PluginStatus::Ready) return;
    if (auto* bridged = dynamic_cast<Vst2BridgeInstance*>(h->instance.get()); bridged && bridged->bridgeDied()) {
        out.status = PluginStatus::Crashed;
        return;
    }
    out.instrument = h->instrument;
    out.instrument_visual = h->instrument_visual;
    out.live_analyzer = true;
    const bool sounding = !h->asleep.load(std::memory_order_relaxed);
    if (sounding) {
        const unsigned head = h->scope_head.load(std::memory_order_acquire);
        out.scope_stamp=head;
        const unsigned count = std::min<unsigned>(head, out.scope.size());
        for (unsigned i = 0; i < count; ++i) {
            const auto at = (head - count + i) % h->scope.size();
            const auto dst = out.scope.size() - count + i;
            out.scope[dst] = h->scope[at].load(std::memory_order_relaxed);
            out.scope_right[dst] = h->scope_right[at].load(std::memory_order_relaxed);
        }
    }
    out.qlinks = h->qlinks;
    configure_workshop_pages(out,unsigned(h->shown.size()),row);
    configure_workshop_meter_aliases(out,h->shown);
    if(out.bloom_ir_first) if(auto* native=dynamic_cast<Vst2Instance*>(h->instance.get())) {
        bloom_ir::Info info;
        if(native->bloomIRInfo(info)) {
            out.bloom_ir_known=true;
            std::copy(std::begin(info.filename),std::end(info.filename),std::begin(out.bloom_ir_filename));
            out.bloom_ir_status=uint8_t(info.status);
        }
    }
    if(out.prism&&out.row>=62)if(auto* native=dynamic_cast<Vst2Instance*>(h->instance.get()))out.prism_editor_known=native->prismInfo(out.prism_editor);
    out.load = uint16_t(std::clamp(h->load.load(std::memory_order_relaxed) * 1000.0f, 0.0f, 9999.0f));
    out.programs = uint16_t(std::min<size_t>(h->programs.size(), 0xffff));
    for (const auto& program : h->programs)
        if (program.index == h->program) { put(out.preset_name, sizeof(out.preset_name), program.name); break; }
    const auto& params = h->instance->getParameters();
    out.visual_count=uint16_t(h->visual_count);
    for(unsigned n=0;n<h->visual_count;++n) {
        std::copy(h->visual_names[n].begin(),h->visual_names[n].end(),out.visual_controls[n].name);
        out.visual_controls[n].value=std::clamp(params[h->shown[n]]->getValue(),0.f,1.f);
    }

    if (e.file.name == "Melody Forge" && h->shown.size() == 63) {
        out.forge_ready = true;
        for (unsigned n = 0; n < out.forge_values.size(); ++n)
            out.forge_values[n] = std::clamp(params[h->shown[n]]->getValue(), 0.f, 1.f);
    }
    if (e.file.name == "Second Spin" && params.size() == 22 && h->shown.size() == 21) {
        out.tape_deck_ready = true;
        out.tape_path = uint8_t(std::lround(4 * params[6]->getValue()));
        out.tape_speed = uint8_t(std::lround(2 * params[7]->getValue()));
        out.tape_stock = uint8_t(std::lround(3 * params[8]->getValue()));
        out.tape_vu = std::clamp(params[21]->getValue(), 0.f, 1.f);
    }
    if (e.file.name == "Vocal Tune" && params.size() == 12 && h->shown.size() == 9) {
        out.vocal_tune_ready = true;
        out.vocal_pitch = 96.f * params[9]->getValue();
        out.vocal_target = int(std::lround(96.f * params[10]->getValue()));
        out.vocal_cents = int(std::lround(400.f * params[11]->getValue())) - 200;
    }
    if (e.file.name == "Contour Comp" && params.size() == 25 && h->shown.size() == 24) {
        out.contour_ready = true;
        const bool vocal = std::lround(params[2]->getValue() * 7) == 3;
        const float ratio = 1 + std::round(params[1]->getValue() * 99);
        out.contour_curve = {-60 + 60 * params[0]->getValue(), vocal ? 3.5f : ratio >= 100 ? 10000.f : ratio,
                             vocal ? 18.f : 72 * params[6]->getValue(),
                             60 * params[7]->getValue(), 2 * params[15]->getValue()};
    }
    if (e.file.name == "Gate Keeper" && params.size() == 22 && h->shown.size() == 21) {
        out.gate_ready = true;
        const float ratio = 1 + std::round(99 * params[1]->getValue());
        out.contour_curve = {-60 + 60 * params[0]->getValue(), ratio == 100 ? 10000.f : ratio,
                             std::round(30 * params[7]->getValue()), std::round(100 * params[2]->getValue()),
                             std::round(5 * params[6]->getValue())};
    }
    if (h->compressor_history_enabled && (out.gate_ready || out.contour_ready || h->shown.size() == 12)) {
        out.compressor_history_ready = true;
        const auto now = std::chrono::steady_clock::now();
        if (now - h->compressor_history_at >= std::chrono::milliseconds(45)) {
            const unsigned peaks = h->compressor_peaks.exchange(0, std::memory_order_relaxed);
            const unsigned reduction = unsigned(1023 * std::clamp(params[out.gate_ready ? 21 : out.contour_ready ? 24 : 13]->getValue(), 0.f, 1.f));
            h->compressor_history[h->compressor_history_head++ % h->compressor_history.size()] = peaks | (reduction << 20);
            h->compressor_history_at = now;
        }
        for (unsigned i = 0; i < out.compressor_history.size(); ++i)
            out.compressor_history[i] = h->compressor_history[(h->compressor_history_head + i) % h->compressor_history.size()];
    }
    if (e.file.name == "Rack 76" && (params.size() == 13 || params.size() == 14) && h->shown.size() == 12) {
        out.rack76_ready = true;
        out.rack76_needle = std::clamp(params[12]->getValue(), 0.f, 1.f);
        out.rack76_ratio = uint8_t(std::clamp(int(std::lround(params[2]->getValue() * 4)), 0, 4));
        out.rack76_off = params[5]->getValue() < .5f;
        out.rack76_blue = params[6]->getValue() >= .5f;
        out.rack76_meter = uint8_t(std::clamp(int(std::lround(params[8]->getValue() * 2)), 0, 2));
    }
    if (e.file.name == "Afterglow Piano" && (h->shown.size() == 18 || h->shown.size() == 21 || h->shown.size() == 24 || h->shown.size() == 25)) {
        static constexpr unsigned masks[] = {0xfff, 0xab5, 0x5ad, 0x6ad, 0xad5, 0x5ab, 0x9ad, 0x295, 0x4a9, 0x4e9};
        const auto scale = std::clamp(int(std::lround(params[h->shown[10]]->getValue() * 9)), 0, 9);
        out.piano_guide = masks[scale];
        out.piano_root = uint8_t(std::clamp(int(std::lround(params[h->shown[11]]->getValue() * 11)), 0, 11));
        const bool follows_song_key = h->shown.size() >= 21 && params[h->shown[18]]->getValue() >= .5f &&
            (params[h->shown[3]]->getValue() > 0.f ||
             (h->shown.size() >= 24 && params[h->shown[22]]->getValue() >= .5f));
        if (h->shown.size() == 25 && params[h->shown[24]]->getValue() >= .5f) out.piano_guide = 0;
        if (follows_song_key)
            out.piano_root = uint8_t(std::clamp(int(std::lround(params[h->shown[19]]->getValue() * 11)), 0, 11));
    }
    out.eq_ready = e.file.name == "Prism EQ" && (h->shown.size() == 48 || h->shown.size() == 15);
    if (sounding) {
        std::array<std::array<float, prism_fft_size>, 2> samples {};
        const unsigned head = h->spectrum_head.load(std::memory_order_acquire);
        const unsigned count = std::min(head, prism_fft_size);
        for (unsigned i = 0; i < count; ++i) {
            const uint32_t pair = h->spectrum_ring[(head - count + i) % prism_fft_size].load(std::memory_order_relaxed);
            samples[0][prism_fft_size - count + i] = int16_t(pair & 65535) / 32767.f;
            samples[1][prism_fft_size - count + i] = int16_t(pair >> 16) / 32767.f;
        }
        out.signal_available=count>0;
        for(unsigned side=0;side<2;++side)
            for(unsigned n=0;n<128;++n)
                out.signal[side][n]=int16_t(std::clamp(samples[side][prism_fft_size-128+n],-1.f,1.f)*32767.f);
        out.eq_spectrum = prism_spectrum(samples, h->plugin_rate);
    }
    if (out.eq_ready) {
        const unsigned bands = h->shown.size() == 15 ? 5 : 4;
        const unsigned stride = bands == 5 ? 3 : 12;
        for (unsigned band = 0; band < bands; ++band)
            for (unsigned control = 0; control < stride; ++control)
                out.eq_bands[band][control] = std::clamp(double(params[h->shown[band * stride + control]]->getValue()), 0.0, 1.0);
    }
    if (e.file.name == "Layer House" && (h->shown.size() == 27 || h->shown.size() == 36 || h->shown.size() == 48)) {
        for (unsigned layer = 0; layer < 2; ++layer) {
            out.layer_shape[layer] = unsigned(std::clamp(int(std::lround(params[h->shown[layer]]->getValue() * 15)), 0, 15));
            out.layer_morph[layer] = std::clamp(params[h->shown[18 + layer]]->getValue(), 0.f, 1.f);
            out.layer_warp[layer] = std::clamp(params[h->shown[21 + layer]]->getValue(), 0.f, 1.f);
        }
    }
    auto read = [&](size_t at, PluginPanelParam& card) {
        auto* p = params[h->shown[at]];
        card.used = true;
        std::string name = p->getName(int(sizeof(card.name) - 1)).trim().toStdString();
        if (e.file.name == "Tape Workshop Strings" && h->shown.size() == strings_parameter_names.size())
            name = strings_parameter_names[at];
        if (e.file.name == "Tape Workshop Orchestra" && h->shown.size() == orchestra_parameter_names.size())
            name = orchestra_parameter_names[at];
        put(card.name, sizeof(card.name), h->nam ? nam_card_name(name) : name);
        float v = p->getValue();
        put(card.text, sizeof(card.text), tidy(p->getText(v, 64).trim().toStdString()));
        if(e.file.name == "Tape Workshop Orchestra" && at>=30 && at<=33) {
            const auto family=unsigned(at-30);
            put(card.text,sizeof(card.text),orchestra_instruments[orchestra_player(family,std::clamp(v,0.f,1.f))]);
        }
        if(out.bloom_ir_first && at==18)
            put(card.text,sizeof(card.text),std::lround(v*8)==0 ? "Algorithmic" : "IR "+std::to_string(int(std::lround(v*8))));
        card.value = int16_t(std::lround(std::clamp(v, 0.0f, 1.0f) * plugin_param_max));
        card.initial = int16_t(std::lround(std::clamp(p->getDefaultValue(), 0.0f, 1.0f) * plugin_param_max));
        int steps = p->getNumSteps();
        card.steps = uint16_t(steps > 1 && steps < plugin_param_max ? steps : 0);
    };
    for (unsigned k = 0; k < 3; ++k) {
        size_t at = out.parameter_index(k);
        if (at >= h->shown.size()) break;
        read(at, out.params[k]);
    }
    if(out.meter_page && e.file.name == "Second Spin" && h->shown.size() == 21) {
        put(out.params[0].name,sizeof(out.params[0].name),"Input Gain");
        put(out.params[1].name,sizeof(out.params[1].name),"Output Trim");
        put(out.params[2].name,sizeof(out.params[2].name),"Mix");
    }
    out.window_first = uint16_t((out.row > 0 ? out.row - 1u : 0u) * 3u);
    for (unsigned k = 0; k < out.window.size(); ++k) {
        size_t at = (out.bloom_ir_first||out.prism) ? out.parameter_index_at((out.window_first+k)/3,(out.window_first+k)%3) : size_t(out.window_first) + k;
        if (at >= h->shown.size()) break;
        read(at, out.window[k]);
    }
}

void PluginRack::set_param(unsigned entry, unsigned shown_index, int value) {
    if (entry >= max_plugins) return;
    std::lock_guard<std::mutex> held(lock);
    auto* h = entries[entry].live;
    if (!h || shown_index >= h->shown.size()) return;
    auto* p = h->instance->getParameters()[h->shown[shown_index]];
    float v = std::clamp(value, 0, plugin_param_max) / float(plugin_param_max);
    const int base=melody::parameter_base(entries[entry].file.name,unsigned(h->shown.size()));
    if(base>=0&&(shown_index==unsigned(base+2)||shown_index==unsigned(base+3)))
        h->instance->getParameters()[h->shown[base+12]]->setValue(0); // explicit local key edit overrides project-follow
    p->setValue(v);
    h->parameter_changed(); // changing Crackle from zero must restart a sleeping effect
}

PluginPrograms PluginRack::programs(unsigned entry) const {
    PluginPrograms out;
    out.entry = uint8_t(entry);
    if (entry >= max_plugins) return out;
    std::lock_guard<std::mutex> held(lock);
    const auto& e = entries[entry];
    if (!e.live || e.status != PluginStatus::Ready) return out;
    out.list = e.live->programs;
    out.current = e.live->program;
    out.loading = e.live->switching;
    out.finding = e.live->finding;
    return out;
}

void PluginRack::select_program(unsigned entry, int program) {
    if (entry >= max_plugins) return;
    Job job {Job::Kind::Program, entry, 0, {}, 0, program};
    {
        std::lock_guard<std::mutex> held(lock);
        auto& e = entries[entry];
        if (!e.live || e.status != PluginStatus::Ready) return;
        e.live->program = program;
        e.live->switching = true;
        for (const auto& p : e.live->programs) if (p.index == program) { e.preset = program_key(p); break; }
        job.generation = e.generation;
    }
    push(std::move(job));
    changed();
}

// Rack thread. A VST3 plug-in hears a program as its program parameter's
// value, and a JUCE plug-in ignores the value it already holds, so the one it
// is on (a freshly opened TONE3000 sits on 0 with nothing loaded) only loads
// after another has gone through first: the controller takes the change from
// JUCE's message thread (60 times a second) and the processor at its next
// block, hence the wait.
void PluginRack::switch_program(unsigned entry, uint32_t generation, int program) {
    juce::AudioPluginInstance* instance = nullptr;
    {
        std::lock_guard<std::mutex> held(lock);
        auto& e = entries[entry];
        if (e.generation != generation || !e.live) return; // changed since: the plug-in it was for is gone
        instance = e.live->instance.get(); // freed only on this thread, so it outlives the switch
    }
    if (program >= 0 && program < instance->getNumPrograms()) {
        if (instance->getCurrentProgram() == program && instance->getNumPrograms() > 1 && !dynamic_cast<ClapInstance*>(instance)) {
            instance->setCurrentProgram(program == 0 ? 1 : 0);
            std::this_thread::sleep_for(std::chrono::milliseconds(150));
        }
        instance->setCurrentProgram(program);
    }
    {
        std::lock_guard<std::mutex> held(lock);
        auto& e = entries[entry];
        if (e.generation == generation && e.live && e.live->instance.get() == instance) e.live->switching = false;
    }
    changed();
}

// Rack thread, before a plug-in's library opens: $HOME on the card, made if
// missing. Set only when it moves, as other threads may
// read the environment.
std::string PluginRack::use_plugin_home() {
    std::string top;
    {
        std::lock_guard<std::mutex> held(lock);
        top = card_top;
    }
    fs::path home = plugin_home(top);
    if (home.empty()) return {};
    std::error_code e;
    fs::create_directories(home, e);
    if (!fs::is_directory(home, e)) return {};
    const char* now = std::getenv("HOME");
    if (!now || home != fs::path(now)) setenv("HOME", home.c_str(), 1);
    return home.string();
}

void PluginRack::set_card(const std::string& top) {
    std::string wanted_root = plugin_folder(top);
    {
        std::lock_guard<std::mutex> held(lock);
        if (top == card_top) return;
        card_top = top;
        root = wanted_root;
        // Entries named from the card's top (Melodee/Plugins/...) that could not open try again on this card at the next sync().
        for (auto& entry : entries)
            if (!entry.path.empty() && fs::path(entry.path).is_relative() && entry.status == PluginStatus::Failed) entry.reload = true;
    }
    browse("");
}

void PluginRack::browse(const std::string& where) { push({Job::Kind::Browse, 0, 0, where, 0}); }

void PluginRack::browse_up() {
    std::string up;
    {
        std::lock_guard<std::mutex> held(lock);
        if (shown.top) return;
        up = fs::path(shown.folder).parent_path().string();
    }
    Job job {Job::Kind::Browse, 1, 0, up, 0}; // entry 1: going up (the row it came out of is found)
    push(std::move(job));
}

PluginRack::View PluginRack::view(int instrument) const {
    std::lock_guard<std::mutex> held(lock);
    if (instrument < 0) return shown;
    View filtered {shown.root, shown.folder, shown.top, shown.home, -1, {}};
    for (size_t n = 0; n < shown.files.size(); ++n) {
        const auto& file = shown.files[n];
        if (!file.accepts_role(instrument != 0)) continue;
        if (file.folder) {
            const auto name = juce::String(file.name).toLowerCase();
            if (instrument ? (name == "effects" || name == "fx") : (name == "instruments" || name == "synths")) continue;
        }
        if (int(n) == shown.came_from) filtered.came_from = int(filtered.files.size());
        filtered.files.push_back(file);
    }
    return filtered;
}

void PluginRack::run() {
    for (;;) {
        Job job;
        {
            std::unique_lock<std::mutex> held(lock);
            wake.wait_for(held, std::chrono::milliseconds(50), [&] { return stopping || !jobs.empty(); });
            if (stopping) return;
            if (jobs.empty()) {
                held.unlock();
                free_retired();
                idle_plugins();
                continue;
            }
            job = std::move(jobs.front());
            jobs.pop_front();
        }
        switch (job.kind) {
        case Job::Kind::Load: load(job); break;
        case Job::Kind::Unload: unload(job.entry, job.generation); break;
        case Job::Kind::Sleep: sleep(job.entry, job.generation); break;
        case Job::Kind::Browse: {
            std::string from;
            {
                std::lock_guard<std::mutex> held(lock);
                from = shown.folder;
            }
            std::string at = job.path.empty() ? root : job.path;
            list(at, job.entry == 1 ? 0 : -1);
            if (job.entry == 1) { // the row of the folder it came out of
                std::lock_guard<std::mutex> held(lock);
                for (size_t n = 0; n < shown.files.size(); ++n)
                    if (shown.files[n].path == from) shown.came_from = int(n);
            }
            probe_listed();
            break;
        }
        case Job::Kind::Probe: probe_listed(); break;
        case Job::Kind::Program: switch_program(job.entry, job.generation, job.id); break;
        case Job::Kind::Presets: find_presets(job.entry, job.generation); break;
        }
        free_retired();
    }
}

void PluginRack::list(const std::string& at, int) {
    std::string top, card;
    {
        std::lock_guard<std::mutex> held(lock);
        top = root;
        card = card_top;
    }
    View v;
    v.root = top;
    if (!top.empty()) {
        // Anywhere on the card; a folder off it lists the Plugins folder.
        std::error_code e;
        auto canonical_card = fs::weakly_canonical(card, e), canonical_top = fs::weakly_canonical(top, e),
             canonical_at = fs::weakly_canonical(at.empty() ? top : at, e);
        v.folder = (under(canonical_card, canonical_at) ? canonical_at : canonical_top).string();
        v.top = v.folder == canonical_card.string();
        v.home = v.folder == canonical_top.string();
        auto here = describe_plugin(v.folder);
        if (!here.folder && here.loadable()) { // a bundle of several, opened: a row for each plug-in in it
            Known found;
            {
                std::lock_guard<std::mutex> held(lock);
                for (const auto& k : known) if (k.path == here.path) found = k;
            }
            if (found.path.empty()) { // not opened yet: once now, to see what it holds
                found = probe(here);
                std::lock_guard<std::mutex> held(lock);
                known.push_back(found);
            }
            for (const auto& cl : found.classes) {
                PluginFile f = here;
                f.name = cl.name; f.instrument = cl.instrument; f.id = cl.id; f.plugins = unsigned(found.classes.size());
                v.files.push_back(f);
            }
            std::sort(v.files.begin(), v.files.end(), [](const PluginFile& a, const PluginFile& b) {
                return juce::String(a.name).compareNatural(juce::String(b.name)) < 0;
            });
        } else {
            // A release zip copied as it came into the Plugins folder: its plug-in folder takes its place. A zip
            // elsewhere on the card is someone's own, left as it is and not listed.
            bool plugins_here = under(canonical_top, v.folder);
            if (plugins_here) unzip_plugins(v.folder);
            v.files = list_plugins(v.folder, plugins_here);
            if (v.top) // what starts the app and the base's own files: no plug-ins, and libraries not to open
                v.files.erase(std::remove_if(v.files.begin(), v.files.end(), [](const PluginFile& f) {
                    auto name = fs::path(f.path).filename().string();
                    return name == "autorun" || name == "sample-base";
                }), v.files.end());
        }
    }
    {
        std::lock_guard<std::mutex> held(lock);
        for (auto& f : v.files)
            if (f.id == 0)
                for (const auto& k : known)
                    if (k.path == f.path) {
                        f.instrument = k.instrument; f.plugins = unsigned(k.classes.size());
                        f.roles = 0;
                        for (const auto& item : k.classes) f.roles |= uint8_t(1u << unsigned(item.instrument == 1));
                        if (!k.name.empty() && f.plugins <= 1) f.name = k.name;
                    }
        shown = std::move(v);
    }
    changed();
}

PluginRack::Known PluginRack::probe(const PluginFile& file) {
    Known found;
    found.path = file.path;
    int8_t kind = -1;
    std::string error;
    fs::path stage = stage_root() / (stage_tag + "probe-" + std::to_string(++stage_count));
    use_plugin_home();
    if (ensure_plugin_support() && stage_copy(file, stage, error)) {
        std::string library = staged_library(file, stage);
        juce::String why;
        juce::PluginDescription d;
        bool described = false;
        if (juce_hosted(file.format)) {
            juce::OwnedArray<juce::PluginDescription> types;
            auto host = juce_types(file.format, staged_path(file, stage), types);
            free_juce_host(host);
            for (auto* t : types) found.classes.push_back({t->uniqueId, t->name.toStdString(), int8_t(described_instrument(*t) ? 1 : 0)});
            // An LV2 bundle of one whose .ttl says lv2:InstrumentPlugin (plugin_files.cpp): an instrument whatever its ports.
            if (file.format == PluginFormat::Lv2 && file.instrument == 1 && types.size() == 1) { types[0]->isInstrument = true; found.classes[0].instrument = 1; }
            if (!types.isEmpty()) { d = *types[0]; described = true; }
        } else if (file.format == PluginFormat::Clap) {
            auto list = ClapInstance::list(juce::File(library), why);
            for (const auto& c : list) found.classes.push_back({clap_id_hash(c.id), c.name, int8_t(c.instrument ? 1 : 0)});
            if (!list.empty()) { d.name = list[0].name; d.isInstrument = list[0].instrument; described = true; }
        } else if (file.format == PluginFormat::Vst2) {
            if (auto p = Vst2Instance::load(juce::File(library), 44100, 128, why)) { p->fillInPluginDescription(d); described = true; }
        } else if (auto p = Vst2BridgeInstance::load(juce::File(library), juce::File(plugin_support_folder() + "/bridge32"), 44100, 128, why)) {
            p->fillInPluginDescription(d);
            described = true;
        }
        if (described) { kind = described_instrument(d) ? 1 : 0; if (named_inside(file.format)) found.name = d.name.toStdString(); }
    }
    std::error_code e;
    fs::remove_all(stage, e);
    found.instrument = kind < 0 ? file.instrument : kind;
    return found;
}

// Opens each listed plug-in whose kind is not known yet just long enough to ask, one at a time, so the picker can
// say INSTRUMENT or EFFECT, or how many plug-ins a bundle holds. Stops when other work comes in (it is picked up
// again with the next listing).
void PluginRack::probe_listed() {
    for (;;) {
        PluginFile file;
        {
            std::lock_guard<std::mutex> held(lock);
            if (stopping || !jobs.empty()) return;
            auto it = std::find_if(shown.files.begin(), shown.files.end(), [&](const PluginFile& f) {
                // A VST3 bundle or a CLAP is opened once even when its kind is known: it may hold several.
                if (!f.loadable() || f.id != 0 || (f.instrument >= 0 && !named_inside(f.format))) return false;
                return std::none_of(known.begin(), known.end(), [&](const Known& k) { return k.path == f.path; });
            });
            if (it == shown.files.end()) return;
            file = *it;
        }
        Known found = probe(file);
        {
            std::lock_guard<std::mutex> held(lock);
            known.push_back(found);
            for (auto& f : shown.files)
                if (f.path == file.path && f.id == 0) {
                    f.instrument = found.instrument; f.plugins = unsigned(found.classes.size());
                        f.roles = 0;
                        for (const auto& item : found.classes) f.roles |= uint8_t(1u << unsigned(item.instrument == 1));
                    if (!found.name.empty() && f.plugins <= 1) f.name = found.name;
                }
        }
        changed();
    }
}

void PluginRack::load(const Job& job) {
    std::string top;
    {
        std::lock_guard<std::mutex> held(lock);
        top = card_top;
    }
    // A path relative to the card's top (a track Melodee's own synth was), or one in the card's old top-level
    // Plugins folder: on the card in now, in Melodee/Plugins.
    std::string path = card_plugin_path(top, job.path);
    auto file = describe_plugin(path);
    std::vector<uint8_t> state;
    {
        std::lock_guard<std::mutex> held(lock);
        auto& entry = entries[job.entry];
        if (entry.generation != job.generation) return; // changed again since
        entry.file = file;
        state = entry.state;
    }
    auto fail = [&](const std::string& why) {
        {
            std::lock_guard<std::mutex> held(lock);
            auto& entry = entries[job.entry];
            if (entry.generation != job.generation) return;
            entry.status = PluginStatus::Failed;
            entry.error = why;
        }
        changed();
    };
    std::error_code missing;
    if (!fs::exists(path, missing)) { fail("Not on the card"); return; }
    if (!file.loadable()) { fail(file.folder ? "Not a plug-in" : file.why); return; }
    if (!ensure_plugin_support()) { fail("Plug-in support missing"); return; }
    std::string home = use_plugin_home();
    fs::path stage = stage_root() / (stage_tag + "e" + std::to_string(job.entry) + "-" + std::to_string(++stage_count));
    std::string error;
    if (!stage_copy(file, stage, error)) { std::error_code e; fs::remove_all(stage, e); fail(error); return; }
    std::string library = staged_library(file, stage);

    std::unique_ptr<juce::AudioPluginInstance> instance;
    juce::String why;
    double device_rate = job.rate > 0 ? job.rate : 44100.0;
    double rate = file.fixed_rate ? double(file.fixed_rate) : device_rate; // what the plug-in itself runs at
    int block = int(EngineHost::block);
    bool nam = false;      // Neural Amp Modeler: its folders made, its page ordered (plugin/nam.h)
    if (juce_hosted(file.format)) {
        juce::OwnedArray<juce::PluginDescription> types;
        auto host = juce_types(file.format, staged_path(file, stage), types);
        const juce::PluginDescription* chosen = types.isEmpty() ? nullptr : types[0];
        if (job.id != 0) { // one of a bundle's several, by its id
            chosen = nullptr;
            for (auto* t : types) if (t->uniqueId == job.id) chosen = t;
        }
        if (!chosen) why = types.isEmpty() ? "No plug-in in the bundle" : "No longer in its bundle";
        else {
            nam = is_nam(chosen->name.toStdString());
            if (nam) nam_folders(home); // before it lists them
            auto make = [&] { instance = host->createInstanceFromDescription(*chosen, rate, block, why); };
            if (file.format == PluginFormat::Lv2) message_thread().run(make); // where its lilv world was made
            else make();
        }
        free_juce_host(host);
    } else if (file.format == PluginFormat::Clap) {
        instance = ClapInstance::load(juce::File(library), job.id, rate, block, why);
    } else if (file.format == PluginFormat::Vst2) {
        instance = Vst2Instance::load(juce::File(library), rate, block, why);
    } else {
        auto bridged = Vst2BridgeInstance::load(juce::File(library), juce::File(plugin_support_folder() + "/bridge32"), rate, block, why);
        if (bridged) bridged->setProcessTimeout(bridge_block_ms);
        instance = std::move(bridged);
    }
    if (!instance) { std::error_code e; fs::remove_all(stage, e); fail(why.isEmpty() ? "Could not open it" : why.toStdString()); return; }

    instance->enableAllBuses();
    // Only the main buses: a side chain or extra outputs stay off.
    for (bool input : {true, false})
        for (int b = 1; b < instance->getBusCount(input); ++b) instance->getBus(input, b)->enable(false);
    instance->setNonRealtime(false);
    instance->prepareToPlay(rate, block);
    if (!state.empty()) instance->setStateInformation(state.data(), int(state.size()));
    juce::PluginDescription description;
    instance->fillInPluginDescription(description);
    bool is_instrument = described_instrument(description) || (instance->getTotalNumInputChannels() == 0 && instance->getTotalNumOutputChannels() > 0);

    auto handle = std::make_unique<PluginHandle>(std::move(instance), is_instrument, device_rate, rate);
    handle->stage = stage.string();
    handle->format = file.format;
    handle->programs = named_programs(*handle->instance, file.name == "Melody Forge" || file.name == "Astral Loom" || file.name == "Sub Foundry");
    handle->finding = file.format == PluginFormat::Clap; // looked for once it plays: find_presets()
    if (file.format == PluginFormat::Vst2 || file.format == PluginFormat::Vst2Arm32) { // an Open MPC skin's Q-Link pages first, then the rest
        auto order = qlink_order(file.path);
        if (!order.empty()) {
            std::vector<int> ordered;
            for (int i : order) if (std::find(handle->shown.begin(), handle->shown.end(), i) != handle->shown.end()) ordered.push_back(i);
            for (int i : handle->shown) if (std::find(ordered.begin(), ordered.end(), i) == ordered.end()) ordered.push_back(i);
            handle->shown = std::move(ordered);
            handle->qlinks = true;
        }
    }
    if (nam) {
        std::vector<std::string> names;
        for (int i : handle->shown) names.push_back(handle->instance->getParameters()[i]->getName(64).toStdString());
        std::vector<int> ordered;
        for (size_t at : nam_page_order(names)) ordered.push_back(handle->shown[at]);
        handle->shown = std::move(ordered);
        handle->nam = true;
    }
    const auto parameter_count = handle->instance->getParameters().size();
    handle->compressor_history_enabled = (file.name == "Rack 76" && parameter_count == 14) ||
                                         (file.name == "Contour Comp" && parameter_count == 25) ||
                                         (file.name == "Gate Keeper" && parameter_count == 22);
    static constexpr const char* move_names[] = {"Aphex Move", "Braids Move", "Dexed Move", "Hera Move", "Plaits Move"};
    if (is_instrument) {
        for (unsigned n = 0; n < std::size(move_names); ++n) {
            const std::string_view name(move_names[n]);
            if (file.name == name || (file.rhythmer && file.name == name.substr(0, name.size() - 5))) {
                handle->instrument_visual = uint8_t(n + 1);
                break;
            }
        }
        if (file.rhythmer && !handle->instrument_visual) handle->instrument_visual = file.drums.empty() ? 6 : 7;
    }
    handle->visual_count=unsigned(std::min(handle->shown.size(),handle->visual_names.size()));
    for(unsigned n=0;n<handle->visual_count;++n)
        put(handle->visual_names[n].data(),handle->visual_names[n].size(),
            handle->instance->getParameters()[handle->shown[n]]->getName(23).toStdString());
    handle->analyzer_focus = analyzer_focus;
    handle->analyzer_entry = job.entry;
    // The piano scopes use a longer rolling envelope on their dedicated pages.
    const bool slow_scope = file.name == "Stillwater" || file.name == "Afterglow Piano" || file.name == "Room Grand";
    handle->waveform_scope = !slow_scope;
    handle->warm_up(); // before the audio thread first runs it

    PluginHandle* raw = handle.get();
    bool stale = false;
    {
        std::lock_guard<std::mutex> held(lock);
        auto& entry = entries[job.entry];
        if (entry.generation != job.generation) stale = true;
        else {
            handles.push_back(std::move(handle));
            if (entry.live) retiring.push_back(entry.live);
            raw->transport.store(entry.transport, std::memory_order_relaxed); // before the audio thread first runs it
            raw->program = program_keyed(raw->programs, entry.preset); // its state already plays it: the name only
            follow_melody_key(raw,file.name,melody_root,melody_scale);
            entry.live = raw;
            entry.status = PluginStatus::Ready;
            entry.file.instrument = is_instrument ? 1 : 0;
            if (description.name.isNotEmpty() && named_inside(file.format)) entry.file.name = description.name.toStdString();
        }
    }
    if (stale) { destroy(handle.release()); return; }
    if (!offer(job.entry, raw)) {
        std::lock_guard<std::mutex> held(lock);
        unoffered.emplace_back(job.entry, raw);
    }
    changed();
    if (file.format == PluginFormat::Clap) push({Job::Kind::Presets, job.entry, job.generation, {}, 0, 0});
}

// Rack thread: a CLAP plug-in's presets, looked for once it plays (the first time, Surge XT's on the card take a
// while: thousands of files), then PRESETS' programs.
void PluginRack::find_presets(unsigned entry, uint32_t generation) {
    ClapInstance* clap = nullptr;
    {
        std::lock_guard<std::mutex> held(lock);
        auto& e = entries[entry];
        if (e.generation != generation || !e.live) return; // changed since: the plug-in it was for is gone
        clap = dynamic_cast<ClapInstance*>(e.live->instance.get()); // freed only on this thread, so it outlives this
    }
    std::vector<PluginProgram> list;
    if (clap) {
        auto found = clap->findPresets(clap_preset_cache(use_plugin_home(), clap->clapId()));
        list.reserve(found.size());
        for (size_t n = 0; n < found.size(); ++n) list.push_back({int(n), found[n].name, found[n].folder});
        clap->setPresets(std::move(found));
    }
    {
        std::lock_guard<std::mutex> held(lock);
        auto& e = entries[entry];
        if (e.generation == generation && e.live && e.live->instance.get() == clap) {
            e.live->programs = PluginProgramList(std::move(list));
            e.live->finding = false;
            if (e.live->program < 0) e.live->program = program_keyed(e.live->programs, e.preset); // as at opening

        }
    }
    changed();
}

void PluginRack::unload(unsigned entry, uint32_t generation) {
    PluginHandle* old = nullptr;
    {
        std::lock_guard<std::mutex> held(lock);
        auto& e = entries[entry];
        if (e.generation != generation) return;
        old = e.live;
        e.live = nullptr;
        e.file = {};
        if (old) retiring.push_back(old);
    }
    if (old && !offer(entry, nullptr)) {
        std::lock_guard<std::mutex> held(lock);
        unoffered.emplace_back(entry, nullptr);
    }
    changed();
}

// Freeze plan F2d: the plug-in's state as it is now kept for when it wakes (one still opening keeps the state it was
// to open with), then let go. The audio thread hands it back and free_retired() frees it here, never on the MIDI or
// audio thread.
void PluginRack::sleep(unsigned entry, uint32_t generation) {
    PluginHandle* old = nullptr;
    {
        std::lock_guard<std::mutex> held(lock);
        auto& e = entries[entry];
        if (e.generation != generation || !e.asleep) return;
        old = e.live;
        e.live = nullptr;
        if (old) {
            juce::MemoryBlock block;
            old->instance->getStateInformation(block);
            e.state.assign(static_cast<const uint8_t*>(block.getData()), static_cast<const uint8_t*>(block.getData()) + block.getSize());
            retiring.push_back(old);
        }
    }
    if (old && !offer(entry, nullptr)) {
        std::lock_guard<std::mutex> held(lock);
        unoffered.emplace_back(entry, nullptr);
    }
    changed();
}

bool PluginRack::offer(unsigned entry, PluginHandle* handle) { return host.offer_plugin(entry, handle); }

void PluginRack::free_retired() {
    std::vector<std::pair<unsigned, PluginHandle*>> again;
    {
        std::lock_guard<std::mutex> held(lock);
        again.swap(unoffered);
    }
    for (auto& [entry, handle] : again)
        if (!offer(entry, handle)) {
            std::lock_guard<std::mutex> held(lock);
            unoffered.emplace_back(entry, handle);
        }
    PluginRunner* runner = nullptr;
    while (host.take_retired_plugin(runner)) {
        auto* handle = static_cast<PluginHandle*>(runner);
        {
            std::lock_guard<std::mutex> held(lock);
            auto it = std::find(retiring.begin(), retiring.end(), handle);
            if (it == retiring.end()) continue; // not one of ours to free (should not happen)
            retiring.erase(it);
        }
        destroy(handle);
    }
}

void PluginRack::destroy(PluginHandle* handle) {
    std::unique_ptr<PluginHandle> owned;
    {
        std::lock_guard<std::mutex> held(lock);
        auto it = std::find_if(handles.begin(), handles.end(), [&](const auto& h) { return h.get() == handle; });
        if (it != handles.end()) { owned = std::move(*it); handles.erase(it); }
        else owned.reset(handle); // never made it into the list (a stale load)
    }
    std::string stage = owned->stage;
    if (juce_hosted(owned->format)) message_thread().run([&] { owned.reset(); });
    else owned.reset();
    std::error_code e;
    if (!stage.empty()) fs::remove_all(stage, e);
    give_back_memory();
}

// What CLAP plug-ins asked of their main thread (plugin/clap_instance.h), done on this one. Handles are freed only on
// this thread, so they outlive the calls.
void PluginRack::idle_plugins() {
    std::vector<ClapInstance*> clap;
    {
        std::lock_guard<std::mutex> held(lock);
        for (const auto& h : handles)
            if (h->format == PluginFormat::Clap)
                if (auto* c = dynamic_cast<ClapInstance*>(h->instance.get())) clap.push_back(c);
    }
    for (auto* c : clap) c->idle();
}

// Freeze plan F2d: what a plug-in freed goes back to the system (glibc keeps freed heap for the process otherwise,
// so a deep freeze would save no RAM). The rack's thread: the audio thread never allocates, so it never waits here.
void start_plugin_messages() { message_thread().start(); }

void give_back_memory() {
#if defined(__GLIBC__)
    malloc_trim(0);
#endif
}

} // namespace melodee

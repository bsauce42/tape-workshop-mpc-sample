// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 Kerem Kilic (Ellic Studio)
#pragma once
#include <algorithm>
#include <array>
#include <cstdint>

// The arpeggiator: the keys held, played in turn at a rate, across octaves.
// Note Repeat is apart (engine/note_repeat.h) and shares only the clock. It counts its own
// clock ticks (24 a quarter), so it plays whether the song runs or not.
// Audio thread only; no allocation.
namespace melodee {

enum class ArpMode : uint8_t { Up, Down, UpDown, Random, Order, Count };
inline const char* arp_mode_name(ArpMode m) {
    static const char* names[] {"Up", "Down", "Up-down", "Random", "Order"};
    return names[unsigned(m) % unsigned(ArpMode::Count)];
}
// Rates in ticks, slowest first, each straight rate followed by its triplet:
// 1/4, 1/4T, 1/8, 1/8T, 1/16, 1/16T, 1/32, 1/32T, 1/64, 1/64T. Note Repeat's
// B1-B3 pick 1/8, 1/16, 1/32 (B1 again 1/4, B3 again 1/64) and, with Shift,
// their triplets (MELODEE_PARITY.md, roadmap P1).
constexpr unsigned arp_rates = 10;
constexpr unsigned arp_ticks_per_quarter = 96; // the arp's own clock, as fine as the sequencer's (1/64T is 4 of it)
inline unsigned arp_rate_ticks(unsigned rate) { static const unsigned t[] {96, 64, 48, 32, 24, 16, 12, 8, 6, 4}; return t[rate % arp_rates]; }
inline const char* arp_rate_name(unsigned rate) {
    static const char* n[] {"1/4", "1/4T", "1/8", "1/8T", "1/16", "1/16T", "1/32", "1/32T", "1/64", "1/64T"};
    return n[rate % arp_rates];
}
inline bool arp_rate_triplet(unsigned rate) { return rate % 2 == 1; }
constexpr unsigned arp_default_rate = 4; // 1/16
// Swing on the repeats, as the project's swing moves the sequencer's off
// sixteenths: every second note of a straight rate comes late by this many
// ticks (fractional), so a pair of notes splits swing : 100 - swing. Triplets
// stay even. `step` counts the rate's notes from the bar.
inline double arp_swing_ticks(unsigned rate, unsigned step, unsigned swing) {
    if (arp_rate_triplet(rate) || step % 2 == 0 || swing <= 50) return 0;
    return arp_rate_ticks(rate) * (double(swing) - 50) / 50;
}

// A key as the arp holds it: a note, or a kit pad's key with its semitones over it (bits 8-15) and a 16 Levels
// cutoff over those (bits 16+, model/sampler.h pad_note). A release or pressure names the key without the cutoff.
inline int arp_named(int key) { return key & 0xffff; }
// Lowest first: by the key and the semitones over it.
inline bool arp_lower(int a, int b) {
    int pa = (a & 0xff) + int8_t(uint8_t(a >> 8)), pb = (b & 0xff) + int8_t(uint8_t(b >> 8));
    return pa != pb ? pa < pb : a < b;
}

struct Arp {
    bool on = false;
    ArpMode mode = ArpMode::Up;
    unsigned rate = arp_default_rate, octaves = 1, gate = 60; // gate: percent of a step
    int top = 127;                             // the highest key: a kit's run past 127 (model/sampler.h)
    std::array<int, 16> held {}, order {};     // held sorted by pitch; order as pressed
    std::array<int, 16> velocity {};
    std::array<float, 16> pressure {};         // each held key's pad pressure, 0..1, as order
    unsigned count = 0, position = 0;
    int sounding = -1;
    int from = -1;                             // the held key next() played last (before octaves)
    uint32_t seed = 7;
    bool pressure_velocity = false;            // a held key's pressure as its notes' velocity

    // How hard the next note of `key` plays: as the pad's pressure while it reports one, else as it was struck.
    int velocity_of(int key, int struck) const {
        float p = pressure_velocity ? pressure_of(key) : 0.0f;
        return p > 0 ? std::clamp(int(p * 127.0f + 0.5f), 1, 127) : struck;
    }

    void press(int key, int vel) {
        for (unsigned n = 0; n < count; ++n) if (arp_named(order[n]) == arp_named(key)) return;
        if (count == held.size()) return;
        order[count] = key; velocity[count] = vel; pressure[count] = 0; held[count] = key; ++count;
        std::sort(held.begin(), held.begin() + count, arp_lower);
    }
    void release(int key) {
        unsigned w = 0;
        for (unsigned n = 0; n < count; ++n)
            if (arp_named(order[n]) != arp_named(key)) { order[w] = order[n]; velocity[w] = velocity[n]; pressure[w] = pressure[n]; ++w; }
        count = w;
        for (unsigned n = 0; n < count; ++n) held[n] = order[n];
        std::sort(held.begin(), held.begin() + count, arp_lower);
    }
    void clear() { count = 0; position = 0; from = -1; }
    // Pressure follows the pad that holds a key: the arp's notes from it hear it.
    void press_harder(int key, float value) { for (unsigned n = 0; n < count; ++n) if (arp_named(order[n]) == arp_named(key)) pressure[n] = value; }
    float pressure_of(int key) const { for (unsigned n = 0; n < count; ++n) if (arp_named(order[n]) == arp_named(key)) return pressure[n]; return 0; }
    // The next key to play, or -1 with nothing held.
    int next(int& vel) {
        if (!count) return -1;
        unsigned span = count * std::max(1u, octaves), at = 0;
        switch (mode) {
        case ArpMode::Down: at = span - 1 - position % span; break;
        case ArpMode::UpDown: { unsigned cycle = span > 1 ? 2 * span - 2 : 1, p = position % cycle; at = p < span ? p : cycle - p; break; }
        case ArpMode::Random: seed = seed * 1664525u + 1013904223u; at = (seed >> 8) % span; break;
        default: at = position % span; break;
        }
        ++position;
        unsigned note = at % count, octave = at / count;
        from = mode == ArpMode::Order ? order[note] : held[note];
        vel = velocity[0];
        for (unsigned n = 0; n < count; ++n) if (order[n] == from) vel = velocity[n];
        return std::min((from & 0xff) + 12 * int(octave), top) | (from & ~0xff); // the octaves on the key, its semitones and cutoff kept
    }
};

} // namespace melodee

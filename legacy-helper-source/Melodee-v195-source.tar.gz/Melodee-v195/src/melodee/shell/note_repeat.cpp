// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 Kerem Kilic (Ellic Studio)
#include "melodee/shell/note_repeat.h"
#include "melodee/engine/arp.h"
#include "melodee/shell/context.h"

namespace melodee {

void repeat_button(Context& c, bool pressed) {
    auto& ui = c.ui;
    auto& t = c.track();
    if (pressed) {
        if (ui.shift) ui.shift_used = true; // nothing printed for Shift + Note Repeat: it acts as Note Repeat
        bool was = t.repeat;
        if (!was) c.set_repeat(true);
        ui.repeat_held = true; ui.repeat_turned_on = !was; ui.repeat_down = c.now;
        ui.repeat_track = ui.track; // its release acts there, should the track change meanwhile
        return;
    }
    if (!ui.repeat_held) return;
    ui.repeat_held = false;
    if (c.now - ui.repeat_down > repeat_hold_ms) { // held: only for as long
        if (ui.repeat_turned_on) c.set_repeat(ui.repeat_track, false);
        return;
    }
    if (!ui.repeat_turned_on) c.set_repeat(ui.repeat_track, false); // a tap: it stays as the press left it, or a tap while on turns it off
}

bool repeat_soft(Context& c, int key) {
    if (!repeat_keys(c.project, c.ui)) return false;
    auto& t = c.track();
    t.repeat_rate = uint8_t(repeat_next(t.repeat_rate, key, c.ui.shift)); // the lit key again: 1/4 or 1/64
    c.send({Command::Type::Repeat, c.ui.track, 0, 2, int16_t(t.repeat_rate)});
    c.notice(std::string("Repeat ") + arp_rate_name(t.repeat_rate));
    return true;
}

} // namespace melodee

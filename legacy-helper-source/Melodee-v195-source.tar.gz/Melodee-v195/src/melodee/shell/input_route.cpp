// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 Kerem Kilic (Ellic Studio)
#include "melodee/shell/input_route.h"
#include "drivers/mixer.h"
#include "runtime/app.h"
#include <algorithm>

namespace melodee {

void InputRoute::service(Hardware& hardware, bool plugged) {
    uint16_t want_now = wanted.load(std::memory_order_relaxed);
    auto source = InputSource((want_now & 0x7f) % unsigned(InputSource::Count));
    bool mute = want_now & 0x80;
    unsigned loops = want_now >> 8 & 7u;
    const bool voice_mic = voice.route_wanted();
    mute = mute || voice_mic;
    const int key = int(source) | int(loops) << 8 | (voice_mic ? 0x1000 : 0);
    bool route_ok = true;
    if (key != routed) {
        bool usb_wanted = from_usb(source) || (loops & need_usb);
        const char* adc = voice_mic ? "mic" : adc_route(source, loops);
        // USB-C first off (the audio thread stops taking blocks), then the ADC route, then USB-C on.
        if (!usb_wanted) { usb_live.store(false, std::memory_order_release); usb.stop(); }
        if (voice_mic) voice_adc.store(true, std::memory_order_release);
        route_ok = hardware.mixer.available() && hardware.mixer.input(adc);
        if (!route_ok && hardware.mixer.available()) hardware.mixer.input("off");
        if (usb_wanted) {
            if (usb.state() == UsbStreamState::Stopped) usb.start("auto");
            usb_live.store(true, std::memory_order_release);
        }
        routed = key;
        if (!voice_mic) voice_adc.store(false, std::memory_order_release);
    }
    // The speaker: off with headphones or line out in, and while the mic is heard through it.
    int on = !plugged && !mute ? 1 : 0;
    plugged_now.store(plugged, std::memory_order_relaxed);
    quieted.store(!plugged && mute, std::memory_order_relaxed);
    if (on != speaker.load(std::memory_order_relaxed) && hardware.mixer.available() && hardware.mixer.speaker(on != 0))
        speaker.store(on, std::memory_order_relaxed);
    voice.routed(voice_mic, route_ok);
}

const float* InputRoute::usb_block(unsigned frames) {
    if (!usb_live.load(std::memory_order_acquire)) return nullptr;
    frames = std::min(frames, 128u);
    if (!usb.pull(block, frames)) std::fill(block, block + 2 * frames, 0.0f); // silent until enough is buffered
    return block;
}

} // namespace melodee

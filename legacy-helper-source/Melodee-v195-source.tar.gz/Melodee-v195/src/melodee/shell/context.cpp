// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 Kerem Kilic (Ellic Studio)
#include "melodee/shell/browser_search.h"
#include "melodee/shell/harmony_tool.h"
#include "melodee/shell/note_jobs.h"
#include "melodee/shell/levels_keys.h"
#include "melodee/shell/mod_jobs.h"
#include "melodee/shell/midi_track_jobs.h"
#include "melodee/shell/context.h"
#include "melodee/web/control_feed.h"
#include "melodee/shell/free_length.h"
#include "melodee/model/pad_params.h"
#include "melodee/shell/input_choices.h"
#include "melodee/shell/step_edit.h"
#include "melodee/shell/step_lane.h"
#include "melodee/engine/engine_host.h"
#include "melodee/engine/engine_info.h"
#include "melodee/engine/midi_engine.h"
#include "melodee/engine/sampler.h"
#include <cmath>
#include "melodee/engine/take_recorder.h"
#include "melodee/model/chords.h"
#include "melodee/shell/progression_jobs.h"
#include "melodee/model/scales.h"
#include "melodee/model/project_file.h"
#include "melodee/plugin/plugin_rack.h"
#include "melodee/shell/project_store.h"
#include "melodee/shell/record_place.h"
#include "melodee/shell/roll.h"
#include "melodee/shell/sample_library.h"
#include "melodee/shell/shell.h"
#include "melodee/shell/sound_list.h"
#include "melodee/shell/stage_map.h"
#include "melodee/shell/pad_gap.h"
#include "melodee/shell/track_copy.h"
#include "melodee/shell/zoom_view.h"
#include "melodee/shell/name_suggest.h"
#include "melodee/shell/looper_jobs.h"
#include "melodee/shell/page_stack.h"
#include "melodee/shell/pad_colour.h"
#include "melodee/shell/mpc_wav_slices.h"
#include "melodee/shell/update.h"
#include <ctime>
#include <filesystem>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <algorithm>
#if defined(__GLIBC__)
#include <malloc.h>
#endif

namespace melodee {
using Type = Command::Type;

void Context::send(const Command& command) {
    if(web_feedback&&command.value>0){
        if(command.type==Type::PadNote)web_feedback->live_note(command.track,sampler_first_note+command.index,unsigned(command.value));
        else if(command.type==Type::NoteOn||command.type==Type::ArpKey||command.type==Type::RepeatKey)web_feedback->live_note(command.track,command.index&255,unsigned(command.value));
    }
    ++sent;
    // Anything but playing changes the project (the metronome is Melodee's setting, not the project's).
    switch (command.type) {
    case Type::NoteOn: case Type::NoteOff: case Type::AllNotesOff: case Type::Wheel: case Type::Bend: case Type::Pressure:
    case Type::Control: case Type::Audition: case Type::PadNote: case Type::Play: case Type::Stop: case Type::Reload:
    case Type::RecordArm: case Type::RecordNow: case Type::RecordStop: case Type::RecordAutoEnd: case Type::Locate: case Type::Recorded:
    case Type::Click: case Type::BrowserPiano: break;
    default: dirty = true;
    }
    // A note played by hand or by MIDI in plays at the frame it came in, a block late, not at the next block's start.
    switch (command.type) {
    case Type::NoteOn: case Type::NoteOff: case Type::PadNote: case Type::ArpKey: case Type::RepeatKey: case Type::Pressure: case Type::Control: case Type::Audition:
        host.send_at(command, hit_ns);
        break;
    default: host.send(command);
    }
}

void Context::save_project_to(const std::string& path) {
    if (!store || path.empty()) return;
    auto name = std::filesystem::path(path).stem().string();
    std::snprintf(project.name, sizeof(project.name), "%s", name.c_str());
    save_loop_files(*this, path); // the loops' lengths into the project, their audio beside it (docs/LOOPER.md)
    keep_chop();                  // Chop's slices into their WAV files (and older projects' chops)
    free_unused_samples();        // and no slot nothing uses (roadmap P3)
    PluginStates states;
    if (plugins) states = plugins->states(); // each plug-in's state as it is now, beside the project
    // Save As: its prints copied (F2d); an imported project's first save: its takes copied in (F3)
    const std::string from = project_path.empty() ? audio_staging_from : project_path;
    store->save(path, melodee::save_project(project, patterns, &states, &prints), from);
    if (project_path.empty() && !audio_staging_from.empty()) audio_sent_path = path; // its takes play on from where they are
    project_path = path;
    dirty = false;
    import_unsaved = false;
}

// Roadmap P3: a sample slot no pad's layer plays, no undo or redo could bring back onto one, no file being made
// holds and Chop is not on is freed as the project is saved, its chop with it, and let go of by the library: the file
// keeps only what plays. Nothing is deleted from the card.
unsigned Context::free_unused_samples() {
    auto used = samples_in_use(project, edits);
    for (const auto& f : pending_files) if (f.slot >= 0) used[size_t(f.slot) % sample_slots] = true;
    if (browser_load.slot >= 0) used[size_t(browser_load.slot)] = true;
    if (ui.chop_sample < sample_slots) used[ui.chop_sample] = true;
    unsigned freed = 0;
    for (unsigned n = 0; n < sample_slots; ++n) {
        if (!project.samples[n].used() || used[n]) continue;
        project.samples.edit(n) = SampleRef {};
        if (project.chops[n].used()) project.chops.edit(n) = SampleChop {};
        if (library) library->load(n, ""); // its audio let go (a full queue: replaced when the slot is next used)
        ++freed;
    }
    return freed;
}

void Context::save_project() { save_project_to(project_path.empty() && store ? store->free_path("") : project_path); }

// Background save (shell/autosave.h): into its own file; with none yet, a new one named after the project
// (an imported project keeps its name), else Project N. False when there is no card to save to.
bool Context::autosave() {
    if (!store) return false;
    std::string path = project_path;
    if (path.empty()) {
        const std::string name = project.name;
        path = name.empty() || name == "Untitled" ? store->free_path("") : store->named_path(name);
    }
    if (path.empty()) return false;
    save_project_to(path);
    return true;
}

void Context::new_project(bool kit) {
    auto fresh = std::make_unique<Project>();
    auto bank = std::make_unique<PatternBank>();
    starting_project(*fresh, *bank);
    const Settings defaults;
    auto& settings = ui.settings;
    if (settings.count_in != defaults.count_in || settings.click != defaults.click) {
        settings.count_in = defaults.count_in;
        settings.click = defaults.click;
        if (store) store->save_settings(settings.text());
    }
    if (kit) melodee::load_sound(fresh->tracks[0], EngineKind::Sampler, 0); // an empty kit on track 1, for a kit on its way
    switch_to(*fresh, *bank, {});
}

void Context::switch_to(const Project& next, const PatternBank& bank, const std::string& path,
                        const std::array<std::vector<uint8_t>, max_plugins>* plugin_states, const PrintTable* next_prints) {
    ++project_generation;
    if (ui.midi_import) stop_preview();
    send({Type::AllNotesOff, 255});
    import_unsaved = false; // an MPC project's load sets it again once this is done (Shell::lights)
    prints = next_prints ? *next_prints : PrintTable {}; // a print still under way for the last project is dropped (print_tick)
    freeze_waiting = 0; // freeze plan F2b: its frozen tracks play live until their prints are checked and mapped again
    deep_hold = thawing = 0; // freeze plan F2d: its deep-frozen tracks' plug-ins are never loaded (plugins_asleep())
    deep_sent.fill(0);
    for (unsigned t = 0; t < track_count; ++t) { ++freeze_serial[t]; if (frozen(t)) freeze_waiting |= 1u << t; }
    audio_stale = 0xffff; // freeze plan F3: its audio tracks' regions mapped again (the audio thread lets the last go)
    audio_peaks.reset();  // and their takes' overviews read again (another folder's)
    audio_prune = true;   // and its takes no pattern plays removed (nothing in its history can bring them back)
    audio_staging_from.clear(); // an import's own are set by its loader
    for (auto& serial : audio_serial) ++serial;
    if (plugins) plugins->set_states(plugin_states ? *plugin_states : PluginStates {});
    project = next;
    patterns = bank;
    remember_sample_select();
    auto keep = ui.pots;
    auto settings = ui.settings; // Melodee's own: they belong to no project
    auto pads_down = ui.held_pads; // the hand on the pads stays where it is
    ui = UiState {};
    ui.pots = keep;
    ui.held_pads = pads_down;
    ui.settings = settings;
    for (auto& pot : ui.pots) pot.bound = 0; // pick the new values up again
    edits.clear();                            // its edits were made to another project
    chain_lead = -1;                          // and its chain of sequences
    take_edit.reset(); take_track = -1;
    free_take = {}; // a Free pattern growing in the project before
    for (auto& h : held_notes) h.key = -1;
    ui.lead_pattern = project.tracks[0].pattern; // as the audio thread starts it
    free_retired();
    send_reload(new ProjectPack(project, patterns), false);
    ui.loading = true; // the Loading sheet until it is built and its samples are in (reload_tick)
    ui.loading_since = loading_moved = now;
    loading_instruments.reset();
    for (unsigned n = 0; n < sample_slots; ++n) {
        const auto& ref = project.samples[n];
        if (!ref.used() || ref.path[0] != '/') continue;
        if (SampleLibrary::instrument_path(ref.path)) { loading_instruments.set(n); ++ui.loading_instruments; ++ui.loading_files; }
        else ++ui.loading_samples;
    }
    ui.loading_total = ui.loading_left = uint16_t(ui.loading_samples + ui.loading_files);
    send_click(); // the metronome is Melodee's, and no take is running now
    send_repeat_velocity();
    project_path = path;
    if (store) store->opened(path); // a file of its own: the one the next start resumes
    dirty = false;
    samples_to_load = 0; // every sample slot again, a few each tick
    slots_waiting.clear();
    browser_load = {};
    load_loop_files(*this, path); // its loops, from beside its file (docs/LOOPER.md)
    midi_audio_sent.fill(0);      // roadmap P4 (M5): the MIDI tracks' inputs told again
    sysex_on_load(*this);         // and their SysEx sent where ON LOAD says (M4)
}

bool Context::reformat() {
    send({Type::AllNotesOff, 255});
    free_retired();
    return send_reload(new ProjectPack(project, patterns), true); // the same project: its loops stay
}

bool Context::send_reload(ProjectPack* pack, bool keep_loops) {
    if (reloading.pack) { // the audio thread is still on its way to park: this pack instead of the one waiting
        delete reloading.pack;
        reloading.pack = pack;
        reloading.keep_loops = reloading.keep_loops && keep_loops; // a new project's loops win over keeping the last
        return true;
    }
    if (host.parking())
        if (uint32_t serial = host.park()) {
            reloading = {pack, keep_loops, serial, now, host.blocks_rendered()};
            return true;
        }
    Command c {Type::Reload};
    c.pack = pack;
    c.value = keep_loops;
    if (host.send(c)) return true;
    delete pack;
    return false;
}

void Context::reload_tick() {
    if (reloading.pack) {
        if (host.parked(reloading.serial)) {
            // The audio thread is still: the project is built here, the time it takes costing no block its deadline.
            auto t0 = std::chrono::steady_clock::now();
            host.reload(*reloading.pack, reloading.keep_loops);
            host.resume(reloading.serial); // and it plays on, faded in from silence
            load_us = uint32_t(std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - t0).count());
            delete reloading.pack; // the last project's patterns go with it
            reloading = {};
            free_retired();
        } else {
            // Not parked yet. The audio thread not running (no block since the park was asked for: the device closing
            // or reopening), or not parking in time: the park called off and a Reload sent, built where it always was.
            uint32_t waited = now - reloading.since;
            bool stalled = waited >= park_stalled_ms && host.blocks_rendered() == reloading.blocks;
            if (!stalled && waited < park_patience_ms) return;
            host.resume(reloading.serial);
            Command c {Type::Reload};
            c.pack = reloading.pack;
            c.value = reloading.keep_loops;
            if (!host.send(c)) delete reloading.pack;
            reloading = {};
        }
    }
    if (!ui.loading) return;
    // Built: the Loading sheet stays until every sample slot has been asked for again and read, its instruments'
    // files landed with them (or nothing has come in for 20 s). What is in is counted for its rows and its bar.
    // (No library, no samples to wait for: the host tests' and the monkey's shells.)
    unsigned waiting = library ? library->loads_waiting() : 0;
    unsigned asked = library ? std::min<unsigned>(samples_to_load, sample_slots) : sample_slots;
    unsigned unasked = sample_slots - asked;
    unsigned samples_in = 0, files = 0, files_in = 0;
    for (unsigned n = 0, span = unsigned(project.samples.span()); n < span; ++n) {
        const auto& ref = project.samples[n];
        if (!ref.used() || ref.path[0] != '/') continue;
        const SampleLibrary::SlotLoad load = library && n < asked ? library->slot_load(n) : SampleLibrary::SlotLoad {};
        if (!loading_instruments.test(n)) { samples_in += load.settled; continue; }
        if (load.parts) { files += load.parts; files_in += load.parts_in; } // its own file read: its files counted
        else { files += 1; files_in += load.settled; }                      // not read yet, or it could not be
    }
    if (!library) { samples_in = ui.loading_samples; files_in = files; }
    if (samples_in != ui.loading_samples_in || files_in != ui.loading_files_in || files != ui.loading_files) loading_moved = now;
    ui.loading_samples_in = uint16_t(samples_in);
    ui.loading_files = uint16_t(files);
    ui.loading_files_in = uint16_t(files_in);
    ui.loading_total = uint16_t(ui.loading_samples + files);
    ui.loading_left = uint16_t(ui.loading_total - std::min<unsigned>(samples_in + files_in, ui.loading_total));
    if (ui.loading_total) ui.loading_bar = std::max<uint16_t>(ui.loading_bar, uint16_t(1000u * (ui.loading_total - ui.loading_left) / ui.loading_total));
    ui.loading_slot = library ? int16_t(library->loading_now()) : int16_t(-1);
    bool in = !reloading.pack && !unasked && slots_waiting.empty() && !waiting;
    if (!in && now - loading_moved < loading_most_ms) return;
    ui.loading = false;
    ui.loading_left = 0;
#if defined(__GLIBC__)
    malloc_trim(0); // what the last project's samples and patterns held, given back to the system
#endif
}

void Context::open(PageId page) {
    if (page != ui.page && (page == PageId::Samples || page == PageId::Plugins || page == PageId::Project || page == PageId::PluginPresets)) {
        ui.browser_queries[browser_query_slot(page)].clear();
        if (page == PageId::Samples && library) library->filter_folder("");
    }
    if (page != ui.page && ui.page == PageId::Roll) {
        ui.roll_tools.fine = false;
        roll_unmark(ui);
    }
    if (page != PageId::Scenes) ui.scene_capture = false; // CAPTURE waits for a pad on Scenes only
    // A PLUGIN track's sounds are the plug-ins on the card (Sample Select, or Sounds from anywhere).
    if (page == PageId::Sounds && track().engine == EngineKind::Plugin && plugins) { open_plugin_picker(UiState::PluginTarget::Instrument); return; }
    if (page == PageId::Trim) { // Trim lives on Stage now: a kit's B1 TRIM (the sampler pages' B1 and Chop come here)
        if (track().engine == EngineKind::Sampler) stage_go(ui, 0, 0);
        page = PageId::Stage;
    }
    if (page != ui.page) punch_release(); // a pad held over a page change would never let go
    if (page != ui.page && page == PageId::Sends) ui.sends_pads = false; // SENDS opens on the tracks (B2 again: a kit's pads)
    if (page != PageId::Stage && page != PageId::Plugins && page != PageId::Samples && page != PageId::Record)
        ui.new_for = -1; // an empty track's Stage left: no going back to where it was picked
    if (page != PageId::Samples) {
        remember_sample_select();
        if (ui.midi_import) stop_preview();
        ui.new_kit = -1;
        ui.midi_import = false;
        ui.sample_folder_pick = false;
        ui.sample_key_pick = false;
        ui.expansions = ui.expansion_home = false;
    }
    if (ui.import_tempo.slot >= 0) stop_preview();
    ui.import_tempo = {};
    ui.sheet_open = false;
    ui.move_open = false;
    ui.map_open = false;
    ui.loop_sheet = false;
    ui.layer_load = -1; // Layers' LOAD sets it after opening Samples
    ui.fx_loop = -1; // FX Select on a loop track is set by its caller after this
    ui.picker_open = false;
    ui.song_export = false;
    if (ui.page == PageId::Sounds && page != PageId::Sounds) audition(-1);
    if (page != ui.page) {
        push_back_stack(ui, page);
        ui.page = page;
    }
    remember_editor(ui, page); // Seq on Patterns comes back to it (shell/page_stack.h)
    if (melodee_roll_page(page)) { // a kit's Roll opens on its pads' rows: the bank in view, the last pad's row
        const auto& t = track();
        if (t.engine == EngineKind::Sampler && !t.levels) {
            unsigned low = sampler_first_note + t.bank % sampler_banks * 16;
            if (ui.roll_key < low || ui.roll_key >= low + 16) ui.roll_key = uint8_t(sampler_first_note + t.last_pad % sampler_pads);
        } else {
            roll_open(pattern(), ui, roll_lane(t)); // a line whose notes lie outside the rows in view (16 Levels: its pitches): the view onto them
        }
    }
    if (page == PageId::Sounds) {
        // The cursor starts on the loaded sound.
        ui.sounds_filter = 0;
        ui.sounds_cursor = track().preset;
    }
}

void Context::back() {
    if (ui.page == PageId::Samples && ui.import_tempo.slot >= 0) {
        finish_import_tempo(false, true);
        return;
    }
    if (ui.sheet_open || ui.map_open || ui.picker_open || ui.move_open) { // a sheet, map or picker first
        ui.sheet_open = ui.map_open = ui.picker_open = ui.move_open = false;
        return;
    }
    open(back_target(ui)); // open() finds it on the stack and drops it and what came after
}

void Context::select_track(unsigned t) {
    if (ui.page == PageId::Sounds) audition(-1);
    stage_tick(UINT32_MAX); // a sound still waiting to load lands on the track it was turned on
    if (ui.track != t % track_count && ui.import_tempo.slot >= 0) {
        stop_preview();
        ui.import_tempo = {};
    }
    ui.track = uint8_t(t % track_count);
    ui.held_step = -1;
    if (ui.page == PageId::Sounds) ui.sounds_cursor = track().preset;
}

void Context::note(unsigned t, int key, int velocity) {
    int top = project.tracks[t % track_count].engine == EngineKind::Sampler ? int(sampler_last_key) : 127; // kit pads in banks F-H
    if (key < 0 || (key & 0xff) > top) return;
    bool quiet = from_midi && !((midi_echo >> (t % track_count)) & 1); // a MIDI track echoes what came in (roadmap P4, M3)
    Command c {velocity ? Type::NoteOn : Type::NoteOff, uint8_t(t), uint8_t(quiet ? 1 : 0), uint16_t(key), int16_t(velocity)};
    send(c);
    if (velocity && t % track_count == ui.track && project.tracks[ui.track].engine == EngineKind::Sampler && (key & 0xff) >= int(sampler_first_note))
        follow_zone(unsigned((key & 0xff) - int(sampler_first_note)), int8_t(uint8_t(key >> 8)), velocity);
}

void Context::follow_zone(unsigned kit, int semitones, int velocity) {
    const auto& sound = track().pads[kit % sampler_pads];
    if (!library || !sound.used() || !project.samples[sound.sample % sample_slots].instrument()) return;
    int zone = library->zone_at(sound.sample, std::clamp(60 + int(sound.pitch) + semitones, 0, 127), velocity);
    if (zone >= 0) ui.zone = uint16_t(zone);
}

// One key of a pad press: to Note Repeat when it is on, else to the arp when
// that is on, else straight to the engine; every press also goes into the ring
// Capture reads (roadmap P5).
void Context::key(int k, int velocity, bool down, int cutoff) {
    auto& t = track();
    if (t.repeat) {
        Command c {Type::RepeatKey, ui.track, 0, uint16_t(k), int16_t(down ? velocity : 0)};
        c.position = uint32_t(cutoff + 1); // a 16 Levels Filter pad's cutoff, kept on its repeats
        send(c);
    } else if (t.arp) {
        Command c {Type::ArpKey, ui.track, 0, uint16_t(k), int16_t(down ? velocity : 0)};
        c.position = uint32_t(cutoff + 1); // a 16 Levels Filter pad's cutoff, kept on its repeats
        if (down || !t.arp_latch) send(c);
    } else {
        note(ui.track, k, down ? velocity : 0);
    }
    if (!down) record_release(k);
    if (down && !t.repeat && !t.arp) record(k, velocity); // repeated or arpeggiated, the press is not heard: its notes are written as they play (take_arp_notes)
    keep_played(ui.track, k, velocity, down); // roadmap P5: always, for Capture
}

// Let go of whatever this pad started, on the track it played (as record_key() plays its source track).
// A latched arp plays on, without the pad's pressure.
void Context::release_pad(unsigned pad) {
    pad %= 16;
    auto& keys = pad_keys[pad];
    if (std::none_of(keys.begin(), keys.end(), [](int32_t k) { return k >= 0; })) return;
    uint8_t selected = ui.track;
    ui.track = uint8_t(pad_track[pad] % track_count);
    auto& t = track();
    for (auto& k : keys)
        if (k >= 0) {
            if (!t.repeat && t.arp && t.arp_latch && t.engine != EngineKind::Sampler) send({Type::Pressure, ui.track, 0, uint16_t(k), 0});
            key(k, 0, false); k = -1;
        }
    ui.track = selected;
}

void Context::play_pad(unsigned pad, uint8_t velocity, bool down) {
    pad %= 16;
    release_pad(pad);
    if (!down) return;
    pad_track[pad] = ui.track;
    auto& t = track();
    if (!t.repeat && t.arp && t.arp_latch && !held_pads()) { // a fresh latch: the old keys go
        send({Type::Arp, ui.track, 0, 0, 0}); send({Type::Arp, ui.track, 0, 0, 1});
    }
    if (t.engine == EngineKind::Sampler) { // the pads are the kit's, in the bank in view
        if (t.levels) { // 16 Levels: one kit pad, soft to loud, its filter swept, or in pitch
            auto level = levels_of(project, t, pad);
            ui.levels_hit = int8_t(pad); ui.levels_value = int16_t(level.shown);
            if (level.none) return; // Zones: a pad past the instrument's last key; Chords: a pad with no chord
            if (LevelsKind(t.levels_kind % unsigned(LevelsKind::Count)) == LevelsKind::Chords && !drum_pads(t)) {
                // Chords: the pad's sample at each note of the progression's chord, as so many notes of the pad
                std::array<int, notes_per_step> chord {};
                unsigned count = levels_chord(t, pad, chord);
                for (unsigned n = 0; n < count; ++n) {
                    pad_keys[pad][n] = pad_note(int(sampler_first_note + t.levels_pad), levels_chord_semitones(chord[n], levels_root_shift(project, t)));
                    key(pad_keys[pad][n], velocity, true); // played, recorded and kept as any pad's note
                }
                follow_zone(t.levels_pad, level.semitones, velocity);
                return;
            }
            pad_keys[pad][0] = pad_note(int(sampler_first_note + t.levels_pad), level.semitones); // what it plays, so Seq Record keeps it
            int v = level.velocity ? level.velocity : velocity;
            if (t.repeat || t.arp) { // Note Repeat or the arp: the level repeats, its release lets go of it (a Note On pad too)
                key(pad_keys[pad][0], v, true, level.cutoff);
                follow_zone(t.levels_pad, level.semitones, v);
                return;
            }
            keep_played(ui.track, pad_keys[pad][0], v, true); // roadmap P5: Capture keeps it (its release goes through key())
            Command c {Type::PadNote, ui.track, uint8_t(level.semitones + 64), t.levels_pad, int16_t(v)};
            c.position = uint32_t(level.cutoff + 1);
            send(c);
            follow_zone(t.levels_pad, level.semitones, v);
            record(pad_keys[pad][0], v, level.cutoff); // with its cutoff (roadmap P3)
            return;
        }
        unsigned kit = t.bank % sampler_banks * 16 + pad;
        t.last_pad = uint8_t(kit);
        pad_keys[pad][0] = int16_t(sampler_first_note + kit);
        key(pad_keys[pad][0], velocity, true);
        return;
    }
    if (!t.used()) return;
    if (ui.prog_storing) prog_store_pad(*this, pad); // Keys storing a chord: it goes on this pad, then the pad plays it
    if (t.levels) { // 16 Levels on a synth: the last note on all sixteen, soft to loud or in pitch; Scale the key's notes
        auto level = levels_of(project, t, pad);
        ui.levels_hit = int8_t(pad); ui.levels_value = int16_t(level.shown);
        if (level.none) return; // Chords: a pad with no chord
        if (LevelsKind(t.levels_kind % unsigned(LevelsKind::Count)) == LevelsKind::Chords && !drum_pads(t)) { // the progression's chord
            std::array<int, notes_per_step> chord {};
            unsigned count = levels_chord(t, pad, chord);
            for (unsigned n = 0; n < count; ++n) {
                pad_keys[pad][n] = int16_t(std::clamp(chord[n], 0, 127));
                key(pad_keys[pad][n], velocity, true);
            }
            return;
        }
        pad_keys[pad][0] = int16_t(level.key >= 0 ? level.key : std::clamp(int(t.last_note) + level.semitones, 0, 127));
        key(pad_keys[pad][0], level.velocity ? level.velocity : velocity, true);
        return;
    }
    int v = t.layout == PadLayout::Levels ? level_velocity(pad) : velocity;
    if (ui.page == PageId::Sounds) v = ui.audition_velocity;
    std::array<int, notes_per_step> keys {};
    unsigned count = 1;
    keys[0] = pad_note(project, t, pad).key;
    if (drum_pads(t) && t.engine == EngineKind::Midi) t.last_pad = uint8_t(16 * drum_bank(t) + pad % 16); // the drum PADS' K2 maps (roadmap P4)
    if ((t.chord || (t.layout == PadLayout::Prog || t.layout == PadLayout::Chords)) && t.layout != PadLayout::Levels) count = chord_notes(project, t, pad, keys); // Prog: the pad's chord
    if (!count) return; // a Prog pad with no chord on it
    if (t.layout != PadLayout::Levels) t.last_note = uint8_t(std::clamp(keys[0], 0, 127));
    for (unsigned n = 0; n < count; ++n) {
        pad_keys[pad][n] = int16_t(std::clamp(keys[n], 0, 127));
        key(pad_keys[pad][n], v, true);
    }
    ui.chord_pad = int8_t(pad);
}

// Seq Record while playing: the note lands where it was heard (its pad's or MIDI
// message's stamp less the output latency, on the nearest tick: by the time the
// MIDI thread sees it the playhead has moved on), or with Rec Quantize on
// (Shift + Pad 10) on the nearest step of the pattern's Q. A note moved ahead of the playhead is skipped
// once by the audio thread, as it was heard live.
void Context::record(int key, int velocity, int cutoff) {
    if (!ui.recording || !host.playing()) return;
    // The count-in's last sixteenth: a hit meant for the first beat, a little early (or seen before the count-in's
    // end reached this thread), goes on the take's first tick, and is not played again there.
    const bool early = host.count_in() != 0;
    if (early && (host.song_playing() || host.count_in_ticks() > sixteenth_ticks)) return;
    if (frozen(ui.track)) return; // freeze plan F2b: a frozen track takes no recording (for now)
    auto& p = pattern();
    int position = 0;
    uint32_t ticks = 0;
    if (early) { // no tick played yet: where the pattern starts
        Speed sp = speed_of(track().speed);
        position = int(uint64_t(host.count_in_from() % std::max<uint32_t>(p.length, 1)) * sp.num / sp.den);
        ticks = host.count_in_from() + 1; // as ticks() reads just after the first tick played (place_at)
    } else if (!host.heard_place(ui.track, hit_ns, position, ticks)) { position = host.position_of(ui.track); ticks = host.ticks(); }
    int playhead = early ? position : host.position_of(ui.track);
    if (playhead < 0) return;
    // A kit lane of its own length: the hit lands where its lane was, as the lane plays (shell/record_place.h).
    const uint32_t loop = p.lane_length(uint8_t(key)), pass = early ? 0 : host.pass_of(ui.track);
    const bool lane = loop < p.length;
    uint32_t at = lane_tick(position, pass, p.length, loop);
    bool ahead = early;
    if (ui.settings.rec_quantize) {
        uint32_t snapped = quantise_tick(p, at); // past the last step: the first, next time round
        if (snapped >= loop) snapped = 0;              // its lane's last step too
        ahead = early || still_ahead(at, snapped, lane ? int(lane_tick(playhead, pass, p.length, loop)) : playhead, lane ? loop : p.length);
        at = snapped;
    }
    Event e;
    e.tick = at; e.length = uint16_t(p.q()); e.key = uint8_t(key); e.pitch = int8_t(key >> 8); e.velocity = uint8_t(std::clamp(velocity, 1, 127));
    if (cutoff >= 0 && track().engine == EngineKind::Sampler) e.cutoff = uint8_t(std::min(cutoff, 100) + 1); // roadmap P3
    if (!p.add(e)) { notice("Pattern full"); return; }
    sync_pattern(ui.track, track().pattern);
    if (ahead) { Command c {Type::Recorded, ui.track, track().pattern, uint16_t(key)}; c.position = at; send(c); }
    for (auto& h : held_notes)
        if (h.key < 0) { h = {key, ui.track, track().pattern, at, ticks}; break; }
}

// A recorded note let go: it is as long as it was held (from its press to its release, both as heard).
void Context::record_release(int key) {
    for (auto& h : held_notes) {
        if (h.key != key || h.track % track_count != ui.track % track_count) continue; // the same key on another track is its own
        h.key = -1;
        auto& p = patterns.at[h.track % track_count][h.pattern % pattern_count];
        int position = 0;
        uint32_t ticks = 0;
        if (!host.heard_place(h.track, hit_ns, position, ticks)) ticks = host.ticks();
        int32_t held = int32_t(ticks - h.since); // let go before the first tick (an early hit): the shortest
        for (size_t n = p.lower(h.tick); n < p.events.size() && p.events[n].tick == h.tick; ++n)
            if (p.events[n].key == uint8_t(key) && p.events[n].pitch == int8_t(key >> 8)) {
                p.events[n].length = uint16_t(std::clamp<int32_t>(held, 1, 65535));
                sync_pattern(h.track, h.pattern);
                break;
            }
        return;
    }
}

void Context::set_param(unsigned t, int id, int value) {
    auto& tr = project.tracks[t % track_count];
    if (id < 0 || unsigned(id) >= max_params) return;
    tr.params[size_t(id)] = int16_t(value);
    send({Type::Param, uint8_t(t), 0, uint16_t(id), int16_t(value)});
}

void Context::load_sound(unsigned t, EngineKind kind, unsigned sound) {
    auto& tr = project.tracks[t % track_count];
    bool engine_changed = tr.engine != kind;
    const auto& info = engine_info(kind);
    const UserSound* own = sound >= info.sound_count ? user_sound(kind, sound - info.sound_count) : nullptr;
    if (own) { // a sound of one's own: its values and routes, as saved
        tr.engine = kind; tr.preset = uint16_t(sound); tr.params = own->params; tr.mods = own->mods; tr.set_name(own->name);
        if (engine_changed) send({Type::Engine, uint8_t(t), 0, uint16_t(kind), 0});
        for (unsigned p = 0; p < info.param_count; ++p) send({Type::Param, uint8_t(t), 0, uint16_t(p), tr.params[p]});
        for (unsigned r = 0; r < mod_routes; ++r) { Command c {Type::Mod, uint8_t(t), 0, uint16_t(r)}; c.route = tr.mods[r]; send(c); }
    } else {
        melodee::load_sound(tr, kind, sound);
        if (engine_changed) send({Type::Engine, uint8_t(t), 0, uint16_t(kind), 0});
        send({Type::Sound, uint8_t(t), 0, uint16_t(tr.preset), 0});
    }
    if (t == ui.track) {
        // Keep it at the top of the recent list.
        unsigned w = 1;
        std::array<uint16_t, 8> recent {};
        recent[0] = tr.preset;
        for (unsigned r = 0; r < ui.recent_count && w < recent.size(); ++r) if (ui.recent[r] != tr.preset) recent[w++] = ui.recent[r];
        ui.recent = recent; ui.recent_count = uint8_t(w);
        ui.auditioning = -1;
    }
}

void Context::audition(int sound) {
    auto& t = track();
    if (sound == ui.auditioning) return;
    if (sound < 0 || sound == t.preset) {
        // Back to the sound the track holds, edits included.
        const auto& info = engine_info(t.engine);
        for (unsigned p = 0; p < info.param_count; ++p) send({Type::Param, ui.track, 0, uint16_t(p), t.params[p]});
        ui.auditioning = -1;
        return;
    }
    const auto& info = engine_info(t.engine);
    if (unsigned(sound) >= info.sound_count) { // one's own: its values
        const UserSound* own = user_sound(t.engine, unsigned(sound) - info.sound_count);
        if (!own) return;
        for (unsigned p = 0; p < info.param_count; ++p) send({Type::Param, ui.track, 0, uint16_t(p), own->params[p]});
    } else {
        send({Type::Sound, ui.track, 0, uint16_t(sound), 0});
    }
    ui.auditioning = int16_t(sound);
}

void Context::apply(const Binding& b, int value) {
    using Kind = Binding::Kind;
    value = std::clamp(value, b.min, b.max);
    if (frozen_edit(freeze_scope(project, ui, b))) return; // freeze plan F2c: what a frozen track's prints hold asks "Unfreeze track N?" first
    touch_gesture(b); // one undo step per control's turns (shell/undo_scope.cpp)
    learn_lane(*this, b); // roadmap P4: what ADD on the MOD page takes
    if (mod_binding(*this, b, value)) return;
    if (midi_binding(*this, b, value)) return; // roadmap P4: a MIDI track's device and SysEx file
    auto& t = track();
    switch (b.kind) {
    case Kind::Param:
        set_param(ui.track, b.id, value);
        if (t.engine != EngineKind::Midi || midi_track::is_cc(b.id) || b.id == midi_track::Bend) record_motion(b.id, value); // of a MIDI track's own, its slots and bend are lanes
        if (t.engine == EngineKind::Sampler && b.id == sampler::Follow && value) follow_tempos();
        break;
    case Kind::Level: t.mix.level = uint8_t(value); send({Type::Level, ui.track, 0, 0, int16_t(value)}); record_motion(int(motion_level), value); break;
    case Kind::Pan: t.mix.pan = int8_t(value); send({Type::Pan, ui.track, 0, 0, int16_t(value)}); record_motion(int(motion_pan), value); break;
    case Kind::Send: { // a track's send into bus b.id (round 2: one into each bus)
        unsigned bus = unsigned(b.id) % bus_count;
        t.mix.sends[bus] = uint8_t(std::clamp(value, 0, 100));
        send({Type::Send, ui.track, 0, uint16_t(bus), int16_t(t.mix.sends[bus])});
        record_motion(int(motion_send(bus)), t.mix.sends[bus]); // roadmap P4: the mix's lanes
        break;
    }
    case Kind::Root: project.root = uint8_t(value); break;
    case Kind::Scale: project.scale = uint8_t(value); break;
    case Kind::Layout:
        if (PadLayout(value) == PadLayout::Drums) use_drum_pads(t);
        else {
            t.layout = PadLayout(value);
            if (t.layout == PadLayout::Scale || t.layout == PadLayout::Chords) {
                t.levels = false;
                ui.levels_hit = -1;
            }
        }
        ui.prog_storing = false;
        if (t.layout == PadLayout::Prog) prog_layout_on(*this);
        break;
    case Kind::ProgKey: t.prog_shift = int8_t(((value - int(t.prog.root)) % 12 + 12 + 6) % 12 - 6); break; // the nearest way: -6..5
    case Kind::ProgVoicing: t.prog_voicing = uint8_t(value % int(ProgVoicing::Count)); break;
    case Kind::BuildRoot: levels_chord_card(*this, 0, value); break; // 16 Levels' SET (shell/levels_keys.h)
    case Kind::BuildChord: levels_chord_card(*this, 1, value); break;
    case Kind::BuildInvert: levels_chord_card(*this, 2, value); break;
    case Kind::Transpose: t.transpose = int8_t(std::clamp(value, -12, 12)); break;
    case Kind::Engine: {
        std::array<EngineKind, size_t(EngineKind::Count)> engines {};
        unsigned count = available_engines(engines);
        if (unsigned(value) < count && engines[size_t(value)] != t.engine) {
            // PLUGIN: which plug-in first; the track changes only when one is picked (choose_plugin)
            if (engines[size_t(value)] == EngineKind::Plugin) open_plugin_picker(UiState::PluginTarget::Instrument);
            else load_sound(ui.track, engines[size_t(value)], 0);
        }
        break;
    }
    case Kind::Jump: ui.sounds_cursor = uint16_t(value); break;
    case Kind::Audition: ui.audition_velocity = uint8_t(value); break;
    case Kind::StepLength:
    case Kind::StepVelocity:
    case Kind::StepChance:
    case Kind::StepRatchet:
    case Kind::StepRamp:
    case Kind::StepPitchRamp:
    case Kind::StepCondition: { // the step in hand's notes, on a kit its lane's (the last pad's)
        auto& p = pattern();
        unsigned at = unsigned(std::max<int>(ui.step_cursor, 0)) % p.steps();
        uint32_t q = p.q();
        bool any = edit_lane(p, at, steps_lane(t), [&](Event& e) {
            switch (b.kind) {
            case Kind::StepLength: e.length = uint16_t(std::clamp<uint32_t>(uint32_t(std::max(value, 1)) * q, 1, 0xffff)); break;
            case Kind::StepVelocity: e.velocity = uint8_t(std::clamp(value, 1, 127)); break;
            case Kind::StepChance: e.chance = uint8_t(std::clamp(value, 0, 100)); break;
            case Kind::StepRatchet: e.ratchet = uint8_t(std::clamp<int>(value, 1, int(max_ratchet))); break;
            case Kind::StepPitchRamp: e.pitch_ramp = int8_t(std::clamp(value, -max_pitch_ramp, max_pitch_ramp)); break;
            case Kind::StepCondition: e.condition = uint8_t(std::clamp(value, 0, int(trig_count) - 1)); break;
            default: e.ramp = int8_t(std::clamp(value, -100, 100)); break;
            }
        });
        if (!any) break;
        sync_pattern(ui.track, t.pattern);
        ui.held_edited = true;
        break;
    }
    case Kind::ModSource:
    case Kind::ModDest:
    case Kind::ModAmount: {
        auto route = t.mods[size_t(b.id) % mod_routes];
        if (b.kind == Kind::ModSource) route.source = uint8_t(value);
        else if (b.kind == Kind::ModDest) { // past the destinations this engine has none of, the way it turned
            const auto& info = engine_info(t.engine);
            int way = value < route.destination ? -1 : 1, last = int(ModDest::Count) - 1;
            while (value >= 1 && value <= last && !mod_dest_label(info, ModDest(value))) value += way;
            if (value < 1 || value > last) break;
            route.destination = uint8_t(value);
        }
        else route.amount = int8_t(value);
        set_route(unsigned(b.id), route);
        break;
    }
    case Kind::PatternBars: set_length(uint32_t(value) * project.bar_ticks()); break;
    case Kind::PatternLength: // below 1 bar: Free (shell/free_length.h)
        if (value < 0) set_free();
        else set_length(pattern_lengths[unsigned(value) % pattern_length_count] * project.bar_ticks());
        break;
    case Kind::TimeSignature: set_signature(unsigned(value)); break;
    case Kind::TcShift: ui.tc_shift = int16_t(value); break;
    case Kind::TcSwing: ui.tc_swing = uint8_t(value); break;
    case Kind::Division: set_division(Division(value)); break;
    case Kind::Swing:
        project.swing = uint8_t(value);
        send({Type::Swing, 0, 0, 0, int16_t(value)});
        break;
    case Kind::SongZoom: ui.song_zoom = uint8_t(value); break;
    case Kind::RegionGain: case Kind::RegionStart: case Kind::RegionEnd: case Kind::RegionFadeIn: case Kind::RegionFadeOut:
    case Kind::RegionReverse: case Kind::RegionWarp: case Kind::RegionBpm: case Kind::RegionSemi: case Kind::RegionFine:
        set_region_value(b, value); // freeze plan F3 (shell/audio_jobs.cpp)
        break;
    case Kind::SongPattern:
    case Kind::SongLength:
        if (b.id >= 0) { // the clip under the cursor
            auto& clip = project.song.clips[size_t(b.id)];
            if (b.kind == Kind::SongPattern) clip.pattern = uint8_t(value);
            else { Clip changed = clip; changed.bars = uint16_t(value); project.song.erase(unsigned(b.id)); project.song.place(changed); }
            sync_song();
        } else if (b.kind == Kind::SongPattern) ui.song_pattern = uint8_t(value);
        else ui.song_length = uint8_t(value);
        break;
    case Kind::FxParam: {
        unsigned chain = unsigned(b.id) / 64, slot = (unsigned(b.id) / 8) % 8, q = unsigned(b.id) % 8;
        set_effect_param(chain, slot, q, value);
        if (chain == ui.track) record_motion(int(motion_fx_param(slot, q)), value); // the track's own effects land in Motion
        else if (chain == master_chain) record_motion(int(motion_master_fx(slot, q)), value); // and the master's (roadmap P4)
        break;
    }
    case Kind::FxKey: set_effect_key(unsigned(b.id) / 64, (unsigned(b.id) / 8) % 8, unsigned(value)); break; // roadmap P4
    case Kind::MidiDrumNote: t.midi.drum_note[unsigned(b.id) % sampler_pads] = uint8_t(std::clamp(value, 0, 127)); dirty = true; break; // roadmap P4 (M3)
    case Kind::ModPick: case Kind::ModKind: case Kind::ModShape: case Kind::ModSync: case Kind::ModRate: case Kind::ModInput:
    case Kind::ModAttack: case Kind::ModRelease: case Kind::ModDepth: case Kind::MacroPick: case Kind::MacroValue: case Kind::MacroLow:
    case Kind::MacroHigh: case Kind::MidiPort: case Kind::MidiSysexFile: break; // roadmap P4: mod_binding() and midi_binding() took them, above
    case Kind::PluginParam: set_plugin_param(b.id, value); break;
    case Kind::SendBus: ui.sends_bus = uint8_t(unsigned(value) % bus_count); break; // the bus in view on Sends
    case Kind::BusReturn: set_return(unsigned(b.id), value); record_motion(int(motion_return(unsigned(b.id))), value); break; // roadmap P4
    case Kind::PadPitch: pad().pitch = int8_t(value); send_pad(ui.track, t.last_pad); record_pad_motion(PadParam::Pitch, value); break;
    case Kind::PadLevel: pad().level = uint8_t(value); send_pad(ui.track, t.last_pad); record_pad_motion(PadParam::Level, value); break;
    case Kind::PadPan: pad().pan = int8_t(value); send_pad(ui.track, t.last_pad); record_pad_motion(PadParam::Pan, value); break;
    case Kind::PadSend: {
        unsigned bus = unsigned(b.id) % bus_count;
        pad().sends[bus] = uint8_t(std::clamp(value, 0, 100));
        send_pad(ui.track, t.last_pad);
        record_pad_motion(PadParam(unsigned(PadParam::SendA) + bus), pad().sends[bus]); // its lane on the pad
        break;
    }
    case Kind::PadCloud: { // the pad's cloud: on or off, or a value Motion records as a lane of the pad
        if (!b.id) { pad().cloud = value != 0; send_pad(ui.track, t.last_pad); break; }
        auto which = PadParam(int(PadParam::CloudPosition) + std::clamp(b.id, 1, 5) - 1);
        set_pad_param(pad(), which, value);
        send_pad(ui.track, t.last_pad);
        record_pad_motion(which, pad_param_value(pad(), which));
        break;
    }
    case Kind::PadStart: { // Trim's handles, in frames
        auto was = trim_view(project, ui);
        pad().start = uint32_t(value); send_pad(ui.track, t.last_pad);
        trim_moved(was);
        break;
    }
    case Kind::PadEnd: {
        auto was = trim_view(project, ui);
        uint32_t frames = project.samples[pad().sample % sample_slots].frames, at = uint32_t(value);
        pad().end = at >= frames ? 0 : at; // the sample's end is kept as 0, so it follows a longer reload
        send_pad(ui.track, t.last_pad);
        trim_moved(was);
        break;
    }
    case Kind::TrimZoom: ui.trim_zoom = uint8_t(value); ui.trim_focus = uint8_t(b.id % 3); ui.trim_view = {}; break;
    case Kind::PadLoopPoint: { // turning it lets go of Loop Lock, as the point moves off the start
        auto was = trim_view(project, ui);
        pad().loop_start = uint32_t(value);
        if (pad().loop_lock) { pad().loop_lock = false; notice("Loop Lock off"); }
        send_pad(ui.track, t.last_pad);
        trim_moved(was);
        break;
    }
    case Kind::PadLoop: pad().loop = value != 0; send_pad(ui.track, t.last_pad); break;
    case Kind::PadMono: pad().mono = value != 0; send_pad(ui.track, t.last_pad); break;
    case Kind::PadLink: pad().link = uint8_t(value); send_pad(ui.track, t.last_pad); break;
    case Kind::PadDecayFrom: pad().decay_from_start = value == 0; send_pad(ui.track, t.last_pad); break;
    case Kind::PadFilterType: pad().filter = PadFilter(value); send_pad(ui.track, t.last_pad); break;
    case Kind::PadWarp:
        if (!(pad().warp == warp_seq_stretch && value == warp_card_seq))
            pad().warp = warp_of_card(value);
        if (pad().warp == warp_seq && !pad().beats && !pad().own_tempo) follow_tempos(); // Seq needs the pad's own tempo
        send_pad(ui.track, t.last_pad);
        break;
    case Kind::PadBeats: pad().beats = uint8_t(value); send_pad(ui.track, t.last_pad); break;
    case Kind::PadLoopXfade: pad().loop_xfade = uint8_t(std::clamp(value, 0, int(max_loop_xfade))); send_pad(ui.track, t.last_pad); break;
    case Kind::PadColour: pad().colour = colour_at(value, pad().colour); break; // lights and screens only: the engine plays on
    case Kind::LayerPick: ui.pad_layer = uint8_t(unsigned(value) % pad_layers); break;
    case Kind::ZonePick: ui.zone = uint16_t(std::max(value, 0)); break;
    case Kind::ZoneTune: case Kind::ZoneLevel: { // round 3 "instrument C": the zone in hand's trim on the last pad
        const unsigned kit = t.last_pad % sampler_pads, zone = unsigned(std::max(b.id, 0)), slot = pad().sample;
        t.drop_stale_trims();
        const ZoneTrim* now = find_trim(t.zone_trims, kit, zone, slot);
        int tune = now ? now->tune : 0, level = now ? now->level : 0;
        (b.kind == Kind::ZoneTune ? tune : level) = value;
        if (!set_trim(t.zone_trims, kit, zone, slot, tune, level)) { notice("Zone trims full"); break; }
        ZoneTrim sent;
        sent.pad = uint8_t(kit); sent.zone = uint16_t(zone); sent.slot = uint16_t(slot);
        if (const ZoneTrim* kept = find_trim(t.zone_trims, kit, zone, slot)) sent = *kept;
        else { sent.tune = 0; sent.level = 0; } // none left: the engine lets it go
        send(zone_trim_command(ui.track, sent));
        dirty = true;
        break;
    }
    case Kind::LayerLow: case Kind::LayerHigh: { // a layer's velocities: the other end moves along rather than cross
        unsigned n = unsigned(b.id) % pad_layers;
        uint8_t& low = n ? pad().layers[n - 1].low : pad().low_velocity;
        uint8_t& high = n ? pad().layers[n - 1].high : pad().high_velocity;
        uint8_t v = uint8_t(std::clamp(value, 1, 127));
        if (b.kind == Kind::LayerLow) { low = v; high = std::max(high, v); }
        else { high = v; low = std::min(low, v); }
        send_pad(ui.track, t.last_pad);
        break;
    }
    case Kind::LayerPitch: if (b.id > 0) pad().layers[size_t(b.id - 1) % (pad_layers - 1)].pitch = int8_t(value); send_pad(ui.track, t.last_pad); break;
    case Kind::LayerGain: if (b.id > 0) pad().layers[size_t(b.id - 1) % (pad_layers - 1)].gain = int16_t(value * 10); send_pad(ui.track, t.last_pad); break;
    case Kind::LayerPlayMode: pad().layer_play = LayerPlay(std::clamp(value, 0, int(LayerPlay::Count) - 1)); send_pad(ui.track, t.last_pad); break;
    case Kind::PadOffset: case Kind::PadVelSense: case Kind::PadCutoff: case Kind::PadResonance:
    case Kind::PadFAttack: case Kind::PadFDecay: case Kind::PadFSustain: case Kind::PadFRelease: case Kind::PadFAmount: {
        // values Motion records as lanes of the pad
        PadParam which = b.kind == Kind::PadOffset ? PadParam::Offset : b.kind == Kind::PadVelSense ? PadParam::VelocitySense
                       : b.kind == Kind::PadCutoff ? PadParam::FilterCutoff : b.kind == Kind::PadResonance ? PadParam::FilterResonance
                       : b.kind == Kind::PadFAttack ? PadParam::FilterAttack : b.kind == Kind::PadFDecay ? PadParam::FilterDecay
                       : b.kind == Kind::PadFSustain ? PadParam::FilterSustain : b.kind == Kind::PadFRelease ? PadParam::FilterRelease
                       : PadParam::FilterAmount;
        set_pad_param(pad(), which, value);
        send_pad(ui.track, t.last_pad);
        record_pad_motion(which, value);
        break;
    }
    case Kind::ChopMode: // the same type again (a pot's noise): nothing, the cuts as they are
        if (ChopMode(value) == ui.chop_mode) break;
        ui.chop_mode = ChopMode(value); rechop();
        ui.settings.chop_mode = uint8_t(value); // the next sample with no chop of its own opens on it
        settings_save_at = std::max<uint32_t>(now, 1) + 1000; // K3 turns in steps: the card gets the last
        break;
    case Kind::ChopAmount:
        if (ui.chop_amount[size_t(ui.chop_mode) % ui.chop_amount.size()] == value) break;
        ui.chop_amount[size_t(ui.chop_mode) % ui.chop_amount.size()] = value; rechop(); break;
    case Kind::ChopStart: case Kind::ChopEnd: { // a cut moved by hand: it stays through a new chop by type or amount (in frames)
        auto was = chop_view(project, ui);
        uint32_t frames = chop_frames(project, ui), at = std::min(uint32_t(value), frames);
        if (!exact_cut) at = zero_cut(at); // onto a zero crossing near where the pot is
        auto& sl = ui.slices;
        const unsigned n = unsigned(b.id);
        const bool start = b.kind == Kind::ChopStart;
        // A cut inside the region (not its first start or its last end, which the pad's region sets).
        const bool inside = n < sl.count && (start ? n > 0 : n + 1 < sl.count);
        const uint32_t before = !inside ? 0 : start ? sl.start[n] : sl.end(n, frames);
        if (start) sl.move_start(n, at, frames);
        else sl.move_end(n, at, frames);
        if (inside) ui.chop_hand.move(before, start ? sl.start[n] : sl.end(n, frames));
        chop_moved(was);
        ui.chop_heard_at = std::max<uint32_t>(1, now + chop_heard_ms); // heard once the cut is still (chop_tick)
        break;
    }
    case Kind::ChopZoom: ui.chop_zoom = uint8_t(value); ui.chop_zoom_auto = false; ui.chop_focus = uint8_t(b.id % 2); ui.chop_view = {}; break;
    case Kind::AutoImportBpm: set_auto_import_bpm(value != 0); break;
    case Kind::SearchScan:
        if (library) library->set_search_paused(value == 0);
        break;
    case Kind::ExpansionBank: ui.expansion_source_bank = uint8_t(value); break;
    case Kind::ExpansionPad: ui.expansion_source_pad = uint8_t(value); break;
    case Kind::FileJump:
        if (ui.files_cursor != value) {
            ui.files_cursor = uint16_t(value);
            if (ui.midi_import) preview_cursor();
        }
        break;
    case Kind::PluginJump: ui.plugins_cursor = uint16_t(value); break;
    case Kind::ProjectJump: ui.project_cursor = uint16_t(value); break;
    case Kind::ProjectSort: ui.project_sort = uint8_t(value); break;
    case Kind::PadFine: pad().fine = int8_t(value); send_pad(ui.track, t.last_pad); record_pad_motion(PadParam::Fine, value); break;
    case Kind::PadPlayMode: pad().play = PadPlay(value); send_pad(ui.track, t.last_pad); break;
    case Kind::PadGroup: pad().group = uint8_t(value); send_pad(ui.track, t.last_pad); break; // 0 none, 1..16
    case Kind::PadReverse: pad().reverse = value != 0; send_pad(ui.track, t.last_pad); break;
    case Kind::PadAttack: pad().attack = uint8_t(value); send_pad(ui.track, t.last_pad); record_pad_motion(PadParam::Attack, value); break;
    case Kind::PadDecay: pad().decay = uint8_t(value); send_pad(ui.track, t.last_pad); record_pad_motion(PadParam::Decay, value); break;
    case Kind::PadRelease: pad().release = uint8_t(value); send_pad(ui.track, t.last_pad); record_pad_motion(PadParam::Release, value); break;
    case Kind::PadSustain: pad().sustain = uint8_t(value); send_pad(ui.track, t.last_pad); record_pad_motion(PadParam::Sustain, value); break;
    case Kind::ModWheel: // the fader's mod wheel, recorded as its own lane
        t.wheel = uint8_t(value);
        send({Type::Wheel, ui.track, 0, 0, int16_t(value * 1000 / 127)});
        record_motion(motion_wheel, value);
        break;
    case Kind::PitchBend: // a plug-in track's pitch bend from the fader, its own lane too (a MIDI track's is its BEND)
        t.bend = int8_t(std::clamp(value, -64, 63));
        send({Type::Bend, ui.track, 0, 0, int16_t(t.bend * 128)});
        record_motion(motion_bend, t.bend);
        break;
    case Kind::Tempo: set_tempo(value * 10); break;
    case Kind::NameSuggest: {
        std::array<const char*, max_suggestions> names {};
        unsigned count = name_suggestions(ui.name, names);
        if (unsigned(value) < count) { ui.name.suggestion = uint8_t(value); ui.name.set(names[value]); }
        break;
    }
    case Kind::NameChar: ui.name.set_char(unsigned(value)); break;
    case Kind::PunchDepth:
        project.punch_depth = uint8_t(value);
        for (unsigned n = 0; n < ui.engaged_count; ++n) ui.engaged[n].depth = uint8_t(value);
        if (ui.engaged_count) send({Type::PunchDepth, 254, 0, 0, int16_t(value)}); // every live slot
        break;
    case Kind::PunchSnap: project.punch_snap = uint8_t(value); break;
    case Kind::PunchTail: project.punch_tail = uint8_t(value); break;
    case Kind::Features: // Settings' K1: Basic or Full; nothing in the project changes
        if (ui.settings.full_features == (value != 0)) break;
        ui.settings.full_features = value != 0;
        notice(value ? "Full: every page" : "Basic: the stock app's pages");
        settings_save_at = std::max<uint32_t>(now, 1) + 1000;
        break;
    case Kind::UsageLog: // Settings' K2 on the doors: the usage log on or off (shell/usage_log.h)
        if (ui.settings.usage_log == (value != 0)) break;
        ui.settings.usage_log = value != 0;
        if (value) usage.start(now, (long long)std::time(nullptr), melodee_version(), ui.settings.full_features);
        else { flush_usage(); usage.stop(); }
        notice(value ? "Usage log on: Melodee/Usage" : "Usage log off");
        settings_save_at = std::max<uint32_t>(now, 1) + 1000;
        break;
    case Kind::SettingRow: set_setting(unsigned(b.id), unsigned(value)); break;
    case Kind::MidiRow: set_midi(unsigned(b.id), unsigned(value)); break;
    case Kind::ClickLevel:
        ui.settings.click_level = uint8_t(value);
        send_click();
        settings_save_at = std::max<uint32_t>(now, 1) + 1000; // pots move in many steps: the card gets the last
        break;
    case Kind::ArpMode: t.arp_mode = uint8_t(value); send({Type::Arp, ui.track, 0, 1, int16_t(value)}); break;
    case Kind::ArpRate: t.arp_rate = uint8_t(value); send({Type::Arp, ui.track, 0, 2, int16_t(value)}); break;
    case Kind::ArpOctaves: t.arp_octaves = uint8_t(value); send({Type::Arp, ui.track, 0, 3, int16_t(value)}); break;
    case Kind::ChordType: t.chord_type = uint8_t(value); break;
    case Kind::ChordVoicing: t.chord_voicing = uint8_t(value); break;
    case Kind::ChordInvert: t.chord_invert = uint8_t(value); break;
    case Kind::RecSource: {
        unsigned code = input_choices(project, ui.track, ui.settings.input).code_at(value);
        if (code >= input_track_code) set_input_source(InputSource::Track, code - input_track_code);
        else set_input_source(InputSource(code), ui.settings.input.track);
        break;
    }
    case Kind::RecTap: set_input_tap(value != 0); break;
    case Kind::AudioSource: t.audio.source = audio_sources[unsigned(value) % audio_source_count]; dirty = true; break; // freeze plan F3
    case Kind::AudioMonitorMode: t.audio.monitor = TrackMonitor(unsigned(value) % unsigned(TrackMonitor::Count)); dirty = true; break;
    case Kind::KnobParam: knob_fx_param(unsigned(b.id), value); break;
    case Kind::PadFxParam: set_pad_fx_param(unsigned(b.id) / 4, unsigned(b.id) % 4, value); break;
    case Kind::FlexMode: set_flex(1, value); break;
    case Kind::FlexMix: set_flex(2, value); break;
    case Kind::CompAttack: set_compressor(2, value); break;
    case Kind::CompRelease: set_compressor(3, value); break;
    case Kind::CompAmount: set_compressor(4, value); break;
    case Kind::CompBoost: set_compressor(5, value); break;
    case Kind::RecThreshold: ui.settings.input.threshold = int8_t(value); input_changed(); break;
    case Kind::RecLength: ui.settings.input.length = uint8_t(value); input_changed(); break;
    case Kind::RecGain: ui.settings.input.gain = int8_t(value); input_changed(); break;
    case Kind::EventVelocity: set_event_velocity(*this, value); break;
    case Kind::EventLength: set_event_length(*this, value); break;
    case Kind::EventChance: set_event_chance(*this, value); break;
    case Kind::EventRatchet: set_event_ratchet(*this, value); break;
    case Kind::EventRamp: set_event_ramp(*this, value); break;
    case Kind::EventPitchRamp: set_event_pitch_ramp(*this, value); break;
    case Kind::EventCondition: set_event_condition(*this, value); break;
    case Kind::EntryLength: ui.entry_length = uint8_t(std::clamp(value, 1, 16)); break;     // step entry: what a pad writes
    case Kind::EntryVelocity: ui.entry_velocity = uint8_t(std::clamp(value, 0, 127)); break;
    case Kind::EntryChance: ui.entry_chance = uint8_t(std::clamp(value, 0, 100)); break;
    case Kind::EventNudge: set_event_nudge(*this, value); break;
    case Kind::MarksVelocity: // Roll's K2, marked notes: their velocities moved together
        if (ui.page == PageId::Roll && roll_selected(ui, t.pattern) && roll_marks_velocity(pattern(), ui, value)) sync_pattern(ui.track, t.pattern);
        break;
    case Kind::MarksRamp: roll_marks_ramp(*this, value); break;                              // Roll's Shift + K2, marked notes                             // Roll's Shift + K1
    case Kind::EuclidHits: case Kind::EuclidSteps: case Kind::EuclidRotate: set_euclid(b.kind, value); break;
    case Kind::TrackSpeed: set_speed(unsigned(b.id), value); break;
    case Kind::VaryAmount: ui.vary_amount = uint8_t(std::clamp(value, 0, 100)); break;
    case Kind::FollowAction: case Kind::FollowOther: case Kind::FollowAfter: case Kind::FollowChance: set_follow(b.kind, value); break; // roadmap P5
    case Kind::SceneTempo: set_scene_tempo(unsigned(b.id), value * 10); break; // Patterns' SCENE: below 30, none of its own
    case Kind::AutoLow: case Kind::AutoHigh: case Kind::AutoStep: case Kind::AutoLayers: case Kind::AutoHold: case Kind::AutoTail:
    case Kind::AutoTap: case Kind::AutoLoop: case Kind::AutoLevel: auto_sheet_set(b.kind, value); break; // shell/auto_sample.cpp
    case Kind::PrintTapPick: ui.print_sheet.tap = value ? PrintTap::PreFx : PrintTap::PostFx; break; // freeze plan F2c
    case Kind::PrintTailPick: ui.print_sheet.tail = PrintTail(std::clamp(value, 0, 2)); break;
    case Kind::PatternProgram:
        if (pattern().program != std::clamp(value, 0, 128)) { pattern().program = uint8_t(std::clamp(value, 0, 128)); sync_pattern(ui.track, track().pattern); }
        break;
    case Kind::SongTempo: set_song_tempo(ui.song_cursor, value < 30 ? 0 : value * 10); break; // roadmap P5: under 30 BPM, none
    case Kind::SongTempoShape: set_song_tempo_shape(ui.song_cursor, value != 0); break;
    case Kind::FeelStrength: case Kind::FeelSwing: case Kind::FeelHumanize: case Kind::FeelVelocity: case Kind::GrooveFrom:
    case Kind::GrooveAmount:
        set_feel(b.kind, value);
        break;
    case Kind::LaneLength: { // Steps on a kit: the last pad's lane loops over so many steps of Q (all of them: with the pattern)
        auto& p = pattern();
        uint32_t ticks = uint32_t(std::clamp(value, 1, int(p.steps()))) * p.q();
        if (p.lane_length(unsigned(b.id)) == std::min(ticks, p.length)) break;
        p.set_lane_length(unsigned(b.id), ticks);
        sync_pattern(ui.track, t.pattern);
        break;
    }
    case Kind::Lock: { // a step or a note held: the lane locked there (roadmap P1)
        uint32_t tick = 0, hold = 0;
        if (!lock_place(project, ui, pattern(), tick, hold)) break;
        write_lock(int(b.id), tick, uint16_t(std::min<uint32_t>(hold, 0xffff)), value);
        ui.held_edited = true; // Steps: letting the step go keeps it
        break;
    }
    case Kind::StageSound: preset_turn(value); break;
    case Kind::SoundList: ui.sounds_filter = uint8_t(value); ui.preset_due = 0; break;
    case Kind::ArpGate: t.arp_gate = uint8_t(value); send({Type::Arp, ui.track, 0, 4, int16_t(value)}); break;
    case Kind::ArpHold: // Hold, as Arp's B3: let go of it and the held keys go
        t.arp_latch = value != 0;
        if (!t.arp_latch) { send({Type::Arp, ui.track, 0, 0, 0}); if (t.arp) send({Type::Arp, ui.track, 0, 0, 1}); }
        break;
    case Kind::ArpOn: set_arp(value != 0); break; // Shift + K2 on Stage's ARP
    case Kind::ChordOn: t.chord = value != 0; break; // Shift + K1 on Stage's CHORD
    case Kind::LevelsType: { // K1 on 16 Levels: Scale, Tune, Velocity (and Filter on a kit, Zones on an instrument's pad)
        std::array<LevelsKind, 6> types {};
        unsigned count = levels_types(project, t, types);
        t.levels_kind = uint8_t(types[unsigned(std::clamp(value, 0, int(count) - 1))]);
        ui.levels_hit = -1;
        break;
    }
    case Kind::LevelsLow: case Kind::LevelsHigh: { // K2 / K3: pad 1's end, pad 16's
        auto kind = LevelsKind(t.levels_kind % unsigned(LevelsKind::Count));
        if (unsigned(kind) >= 4) break;
        auto range = levels_range(kind);
        t.levels_ends[unsigned(kind)][b.kind == Kind::LevelsHigh ? 1 : 0] = int8_t(std::clamp(value, range.low, range.high));
        break;
    }
    case Kind::NewEngine: ui.new_engine = uint8_t(value); ui.new_sound = 0; break;
    case Kind::NewSound: ui.new_sound = uint8_t(value); break;
    case Kind::NewSource: ui.new_source = uint8_t(value); break;
    case Kind::NewPort: ui.new_port = uint8_t(value); break;
    case Kind::NewChannel: ui.new_channel = uint8_t(value); break;
    case Kind::TrackPick: select_track(unsigned(value)); break;
    case Kind::TrackPattern: launch(ui.track, unsigned(value)); break;
    // The Looper (docs/LOOPER.md, shell/looper_jobs.cpp).
    case Kind::LoopPick: ui.loop = uint8_t(value % loop_tracks); break;
    case Kind::LoopLength: looper_do(*this, looper::Do::Length, ui.loop, looper::lengths[size_t(value) % looper::lengths.size()]); break;
    case Kind::LoopFeedback: looper_do(*this, looper::Do::Feedback, ui.loop, value); break;
    case Kind::LoopQuantize: looper_do(*this, looper::Do::Quantize, ui.loop, value); break;
    case Kind::LoopThen: looper_do(*this, looper::Do::Then, ui.loop, value); break;
    case Kind::LoopSource: { // the loop's sheet, K1: one of the sources it can take (shell/loop_sheet.h)
        std::array<uint8_t, looper::source_count> sources {};
        unsigned at = 0, count = loop_sources(project, ui.loop, sources, at);
        if (value >= 0 && unsigned(value) < count && unsigned(value) != at) looper_do(*this, looper::Do::Source, ui.loop, sources[size_t(value)]);
        break;
    }
    case Kind::LoopLevel: case Kind::LoopPan: case Kind::LoopSend: case Kind::LoopBus: set_loop_mix(*this, ui.loop, b.kind, value); break;
    case Kind::None: break;
    }
}

void Context::set_route(unsigned r, const ModRoute& value) {
    if (r >= mod_routes) return;
    track().mods[r] = value;
    Command c {Type::Mod, ui.track, 0, uint16_t(r)};
    c.route = value;
    send(c);
}

void Context::change_setting(unsigned row, int way) {
    ui.settings.step(row, way);
    if (row == Settings::RepeatVelocity || row == Settings::PadResponse || row == Settings::PadPressure) send_repeat_velocity();
    if (store) store->save_settings(ui.settings.text());
}

// K1 on a Settings row. A row that reopens the audio device or the USB camera keeps the value until the knob rests,
// so a turn past 48 kHz to 96 kHz opens the device once (record_tick).
void Context::set_setting(unsigned row, unsigned value) {
    if (Settings::reopens(row)) {
        ui.settings_wait_row = int8_t(row);
        ui.settings_wait_value = uint8_t(value);
        settings_wait_at = std::max<uint32_t>(now, 1);
        return;
    }
    if (ui.settings.choice(row) == value) return;
    ui.settings.set_choice(row, value);
    if (row == Settings::RepeatVelocity || row == Settings::PadResponse || row == Settings::PadPressure) send_repeat_velocity();
    settings_save_at = std::max<uint32_t>(now, 1) + 1000; // pots move in many steps: the card gets the last
}

void Context::set_look(unsigned row, unsigned value) {
    if (row == Settings::Palette) ui.settings.palette = uint8_t(value % ui::palettes.size());
    else if (row == Settings::Font) ui.settings.font = uint8_t(value % ui::face_choices);
    else return;
    if (store) store->save_settings(ui.settings.text());
}

const UserSound* Context::user_sound(EngineKind engine, unsigned k) const {
    for (const auto& s : user_sounds) if (s.engine == engine && k-- == 0) return &s;
    return nullptr;
}
unsigned Context::user_sound_count(EngineKind engine) const {
    unsigned n = 0;
    for (const auto& s : user_sounds) n += s.engine == engine;
    return n;
}

void Context::cancel_name() {
    if (ui.name.target == NameTarget::BrowserSearch) { ui.browser_queries[browser_query_slot(ui.page)] = browser_query(ui); if (ui.page == PageId::Samples && library) library->filter_folder(browser_query(ui)); }
    // BACK on live search keeps even an edit made just before the next tick.
    if (ui.name.target == NameTarget::SampleSearch)
        search_samples(std::string(ui.name.text, ui.name.length), true);
    ui.name.target = NameTarget::None;
}

void Context::open_name(NameTarget target, const std::string& initial, unsigned limit, bool capitals) {
    ui.name.start(target, initial.c_str(), limit, capitals);
    ui.sheet_open = false;
}

void Context::name_project(bool as_new) {
    if (!store) return;
    std::string suggestion = as_new ? std::string(project.name) : std::filesystem::path(store->free_path("")).stem().string();
    open_name(as_new ? NameTarget::ProjectSaveAs : NameTarget::ProjectSave, suggestion, sizeof(project.name) - 1, false);
}

void Context::rename_project(const std::string& path, const std::string& name) {
    name_path = path;
    open_name(NameTarget::ProjectRename, name, sizeof(project.name) - 1, false);
}

void Context::name_marker(unsigned bar) {
    int at = project.song.marker_at(bar);
    if (at < 0) return;
    name_bar = bar;
    open_name(NameTarget::Marker, project.song.markers[size_t(at)].name, sizeof(Marker::name) - 1, true);
}

void Context::save_sound() {
    auto& t = track();
    if (t.engine == EngineKind::None || t.sampled() || !store) return; // a kit's or keygroup's sounds are files
    open_name(NameTarget::Sound, t.name, name_length - 1, true);
}

// Shift + Sample Select on a sampler track: the last pad's region as a WAV
// file under the card's Samples, named on the Name sheet (save_sample_as()).
// Jobs that cut or read one region of one file have nothing to do on an instrument.
bool Context::refuse_instrument(const char* job) {
    const auto& sound = pad();
    if (track().engine != EngineKind::Sampler || !sound.used() || !project.samples[sound.sample % sample_slots].instrument()) return false;
    notice(std::string(job) + ": not on an instrument");
    return true;
}


void Context::save_sample() {
    auto& t = track();
    const auto& sound = pad();
    if (t.engine != EngineKind::Sampler || !sound.used()) { notice("Save Sample: no sample"); return; }
    if (refuse_instrument("Save Sample")) return;
    const auto& ref = project.samples[sound.sample % sample_slots];
    open_name(NameTarget::Sample, ref.name, sizeof(project.name) - 1, false); // a file's name may run as long as a project's
}

// Shift + Sample Select on the Samples browser: the kit's bank in view as a
// bank file, named on the Name sheet (finish_name()).
void Context::save_bank() {
    auto& t = track();
    if (t.engine != EngineKind::Sampler || !library) return;
    char letter = char('A' + t.bank % sampler_banks);
    if (!bank_of(project, ui.track, t.bank, "").used()) { notice(std::string("Save Bank: bank ") + letter + " is empty"); return; }
    std::string name = t.name[0] ? std::string(t.name) + " " + letter : std::string("BANK ") + letter;
    open_name(NameTarget::Bank, name, name_length - 1, true);
}

void Context::finish_name() {
    auto& e = ui.name;
    std::string text(e.text, e.length);
    while (!text.empty() && text.back() == ' ') text.pop_back();
    while (!text.empty() && text.front() == ' ') text.erase(text.begin());
    NameTarget target = e.target;
    e.target = NameTarget::None;
    if (target == NameTarget::BrowserSearch) { ui.browser_queries[browser_query_slot(ui.page)] = text; if (ui.page == PageId::Samples && library) library->filter_folder(text); return; }
    if (target == NameTarget::SampleSearch) { search_samples(text, true); return; }
    if (text.empty()) return; // an empty name changes nothing
    switch (target) {
    case NameTarget::ProjectSave: case NameTarget::ProjectSaveAs:
        if (store) { save_project_to(store->named_path(text)); store->list(project_folder); }
        break;
    case NameTarget::ProjectRename:
        if (name_path.empty() || name_path == project_path) std::snprintf(project.name, sizeof(project.name), "%s", text.c_str());
        if (!name_path.empty() && store) {
            store->rename(name_path, text);
            if (name_path == project_path) {
                auto p = std::filesystem::path(name_path);
                project_path = (p.parent_path() / (text + p.extension().string())).string();
            }
            store->list(project_folder);
        }
        break;
    case NameTarget::Marker: {
        int at = project.song.marker_at(name_bar);
        if (at >= 0) {
            auto& m = project.song.markers[size_t(at)];
            std::memset(m.name, 0, sizeof(m.name));
            std::strncpy(m.name, text.c_str(), sizeof(m.name) - 1);
            dirty = true;
        }
        break;
    }
    case NameTarget::Sound: {
        auto& t = track();
        if (!store || t.engine == EngineKind::None || t.sampled()) break;
        t.set_name(text.c_str());
        store->save_sound(text, melodee::save_sound(sound_of(t, text.c_str())));
        break;
    }
    case NameTarget::Sample: save_sample_as(text); break;
    case NameTarget::Bank: {
        auto& t = track();
        if (!library || t.engine != EngineKind::Sampler) break;
        library->write_bank(text, melodee::save_bank(bank_of(project, ui.track, t.bank, text.c_str())));
        break;
    }
    case NameTarget::Mixdown: mixdown(text); break;
    case NameTarget::Scene: project.scenes[name_scene_at % pattern_count].set_name(text.c_str()); dirty = true; break; // roadmap P5
    case NameTarget::BrowserSearch: case NameTarget::SampleSearch: case NameTarget::None: break;
    }
}

void Context::toggle_favourite() {
    auto& t = track();
    if (t.sampled() || t.engine == EngineKind::None) return;
    unsigned sound = t.preset;
    if (ui.page == PageId::Sounds) {
        std::array<uint16_t, max_listed> list {};
        unsigned count = sound_list(t, ui, list);
        if (!count) return;
        sound = list[std::min<unsigned>(ui.sounds_cursor, count - 1)];
    }
    ui.settings.toggle_favourite(unsigned(t.engine), sound);
    if (store) store->save_settings(ui.settings.text());
}

void Context::pressure(unsigned pad, uint8_t value) {
    if (pad >= 16 || !ui.settings.pressure) return; // Settings: Pad pressure off
    if (punch_pressure(pad, value)) return;         // Pad FX: a held punch's depth
    // Every note of a chord, on the track the pad played (a Record take's source track presses that track's notes).
    unsigned to = pad_track[pad] % track_count;
    for (auto k : pad_keys[pad]) if (k >= 0) send({Type::Pressure, uint8_t(to), 0, uint16_t(k & 0xff), int16_t(value)});
}

void Context::set_mute(unsigned t, bool on) {
    project.tracks[t % track_count].mix.mute = on;
    send({Type::Mute, uint8_t(t), 0, 0, int16_t(on)});
}
void Context::set_solo(unsigned t, bool on) {
    project.tracks[t % track_count].mix.solo = on;
    send({Type::Solo, uint8_t(t), 0, 0, int16_t(on)});
}

void Context::set_step(unsigned t, unsigned at, const Step& value) {
    auto& tr = project.tracks[t % track_count];
    auto& p = patterns.at[t % track_count][tr.pattern];
    if (at >= p.steps()) return;
    p.set_step(at, value);
    sync_pattern(t, tr.pattern);
}

void Context::free_retired() {
    Pattern* old = nullptr;
    while (host.take_retired_pattern(old)) delete old;
}

void Context::sync_pattern(unsigned t, unsigned p) {
    if(web_feedback)web_feedback->pattern_changed();
    free_retired();
    Command c {Type::PatternData, uint8_t(t % track_count), uint8_t(p % pattern_count)};
    c.data = new Pattern(played_pattern(patterns.at[t % track_count][p % pattern_count], project.tracks[t % track_count].speed)); // as it plays: its feel, its track's speed (roadmap P1)
    if (!host.send(c)) delete c.data;
    dirty = true;
}

// Seq Record + a pot: a point of the playing pattern's Motion at the tick playing (roadmap P1: tick resolution).
void Context::record_motion(int lane, int value) {
    if (!ui.recording || !host.playing() || host.count_in() || lane < 0) return;
    if (frozen(ui.track)) return; // freeze plan F2b
    auto& t = track();
    auto& p = pattern();
    MotionPoint m;
    m.tick = uint32_t(std::max(host.position_of(ui.track), 0)) % std::max<uint32_t>(p.length, 1);
    m.param = uint8_t(lane_param(lane)); m.pad = uint8_t(lane_pad(lane) % sampler_pads); m.value = int16_t(value);
    if (!p.write_motion(m)) return; // full: the move still sounds, it is just not kept
    sync_motion(ui.track, t.pattern);
}

void Context::write_lock(int lane, uint32_t tick, uint16_t hold, int value) {
    if (lane < 0) return;
    auto& t = track();
    auto& p = pattern();
    MotionPoint m;
    m.tick = tick % std::max<uint32_t>(p.length, 1); m.hold = std::max<uint16_t>(hold, 1);
    m.param = uint8_t(lane_param(lane)); m.pad = uint8_t(lane_pad(lane) % sampler_pads); m.value = int16_t(value);
    if (!p.write_motion(m)) { notice("Motion full"); return; }
    sync_motion(ui.track, t.pattern);
}

void Context::sync_motion(unsigned t, unsigned p) {
    int which = int((t % track_count) << 8 | (p % pattern_count));
    if (motion_waiting >= 0 && motion_waiting != which) sync_pattern(unsigned(motion_waiting) >> 8, unsigned(motion_waiting) & 0xff);
    motion_waiting = which;
    dirty = true;
    flush_motion();
}

// Seq Record with the arp on (Note Repeat): each note it played goes into the pattern it fell in, where it fell, as
// long as the arp held it (roadmap P1); one pattern copy for the audio thread for all that came.
void Context::take_arp_notes() {
    EngineHost::ArpWritten w;
    int synced = -1;
    while (host.take_arp_written(w)) {
        if (!ui.recording) continue;
        auto& p = patterns.at[w.track % track_count][w.pattern % pattern_count];
        Event e;
        e.tick = w.tick % std::max<uint32_t>(p.length, 1); e.length = std::max<uint16_t>(w.length, 1);
        e.key = uint8_t(w.key & 0xff); e.pitch = int8_t(w.key >> 8); e.velocity = uint8_t(std::clamp<int>(w.velocity, 1, 127));
        e.cutoff = w.cutoff; // a 16 Levels Filter repeat's cutoff + 1 (roadmap P3)
        if (!p.add(e)) { notice("Pattern full"); continue; }
        int which = int(w.track % track_count) << 8 | int(w.pattern % pattern_count);
        if (synced >= 0 && synced != which) sync_pattern(unsigned(synced) >> 8, unsigned(synced) & 0xff);
        synced = which;
    }
    if (synced >= 0) sync_pattern(unsigned(synced) >> 8, unsigned(synced) & 0xff);
}

void Context::flush_motion() {
    if (motion_waiting < 0 || now - motion_synced < motion_sync_ms) return;
    sync_pattern(unsigned(motion_waiting) >> 8, unsigned(motion_waiting) & 0xff);
    motion_waiting = -1;
    motion_synced = now;
}

// A kit pad's own value turned while recording: a lane of that pad (the last hit).
void Context::record_pad_motion(PadParam which, int value) {
    if (!track().sampled()) return;
    record_motion(motion_lane(motion_pad_param(which), track().last_pad % sampler_pads), value);
}

void Context::clear_lane(int lane) {
    if (lane < 0) return;
    auto& t = track();
    std::string what = "Erase " + lane_name(t, lane, &project) + " motion";
    edit_pattern(ui.track, t.pattern, what.c_str(), [&] { // one undo (the pattern holds its motion), or part of a take
        if (pattern().clear_lane(lane_param(lane), lane_pad(lane) % sampler_pads)) sync_pattern(ui.track, t.pattern);
    });
    notice(what);
}

void Context::launch(unsigned t, unsigned p) {
    auto& tr = project.tracks[t % track_count];
    if (!chaining) { // a pattern launched by hand: the chain ends
        tr.chain_count = 0; chain_queued[t % track_count] = false;
        if (chain_lead == int(t % track_count)) chain_lead = -1;
    }
    tr.pattern = uint8_t(p % pattern_count);
    ui.lead_pattern = tr.pattern; // BPM per pattern: the one launched last leads
    send({Type::Pattern, uint8_t(t), 0, 0, int16_t(tr.pattern)});
    if (ui.recording && host.song_playing()) record_launch(t % track_count, tr.pattern);
}

unsigned Context::song_sixteenth() const { return host.song_bar() * 16 + (host.ticks() % project.bar_ticks()) / sixteenth_ticks; }

void Context::record_launch(unsigned t, unsigned p) {
    unsigned bar = host.song_bar() + 1; // like a launch, on the next bar
    if (bar >= song_bars) return;
    project.song.place({uint8_t(t), uint8_t(p), uint16_t(bar), 1, false});
    recording_from[t] = uint16_t(bar);
    recording_tracks |= uint16_t(1u << t);
    seen_song_bar = host.song_bar();
    sync_song();
}

// Each bar the clips being written grow by one, so the song always holds the
// bar after the one playing; past 16 bars a new clip carries on.
void Context::song_tick() {
    bool on = ui.recording && host.song_playing();
    if (!on) {
        if (recording_tracks) finish_launches();
        if (recording_punch >= 0) end_punch();
        seen_song_bar = ~0u;
        return;
    }
    unsigned bar = host.song_bar();
    if (bar == seen_song_bar) return;
    if (seen_song_bar != ~0u && bar < seen_song_bar) { finish_launches(); seen_song_bar = bar; return; } // the loop came round
    seen_song_bar = bar;
    if (!recording_tracks) return;
    auto& song = project.song;
    for (unsigned t = 0; t < track_count; ++t) {
        if (!(recording_tracks & (1u << t))) continue;
        int index = -1;
        for (unsigned n = 0; n < song.count; ++n) if (song.clips[n].track == t && song.clips[n].bar == recording_from[t]) index = int(n);
        if (index < 0) { recording_tracks &= uint16_t(~(1u << t)); continue; }
        Clip clip = song.clips[size_t(index)];
        if (clip.end() != bar + 1 || bar + 1 >= song_bars) continue;
        if (clip.bars >= 16) { // a new clip carries on
            song.place({clip.track, clip.pattern, uint16_t(bar + 1), 1, false});
            recording_from[t] = uint16_t(bar + 1);
            continue;
        }
        song.cut(t, bar + 1, bar + 2); // what was written after it gives way
        for (unsigned n = 0; n < song.count; ++n)
            if (song.clips[n].track == t && song.clips[n].bar == recording_from[t]) { ++song.clips[n].bars; break; }
    }
    sync_song();
}

// Seq Record off or the song stopped: each clip ends with the bar that was playing.
void Context::finish_launches() {
    auto& song = project.song;
    unsigned bar = seen_song_bar == ~0u ? 0 : seen_song_bar;
    for (unsigned t = 0; t < track_count; ++t) {
        if (!(recording_tracks & (1u << t))) continue;
        for (unsigned n = 0; n < song.count; ++n) {
            auto& c = song.clips[n];
            if (c.track != t || c.bar != recording_from[t]) continue;
            unsigned end = std::max<unsigned>(bar + 1, c.bar + 1u);
            if (c.end() > end) c.bars = uint16_t(end - c.bar);
            break;
        }
    }
    recording_tracks = 0;
    sync_song();
}

void Context::begin_punch(unsigned kind, uint8_t target, uint8_t depth) {
    if (recording_punch >= 0) end_punch();
    if (!(ui.recording && host.song_playing())) return;
    unsigned at = song_sixteenth();
    punch_take = SongPunch {uint16_t(at / 16), uint8_t(at % 16), 1, uint8_t(kind), target, depth};
    recording_punch = int(at);
}

void Context::end_punch() {
    if (recording_punch < 0) return;
    unsigned now = host.song_playing() ? song_sixteenth() : unsigned(recording_punch) + 1;
    int length = int(now) - recording_punch;
    punch_take.length = uint8_t(std::clamp(length, 1, 255));
    recording_punch = -1;
    if (project.song.add_punch(punch_take)) sync_punches();
}

void Context::sync_punches() {
    const auto& song = project.song;
    for (unsigned n = 0; n < song.punch_count; ++n) {
        Command c {Type::SongPunchSet, 0, 0, uint16_t(n)};
        c.song_punch = song.punches[n];
        send(c);
    }
    send({Type::SongPunchCount, 0, 0, 0, int16_t(song.punch_count)});
}

void Context::clear_pattern(unsigned t, unsigned p) {
    auto& pattern = patterns.at[t % track_count][p % pattern_count];
    if (!pattern.clear_notes_and_motion()) return; // its Motion too, as the question says
    sync_pattern(t, p);
}

void Context::copy_pattern(unsigned t, unsigned from, unsigned to, int from_track) {
    unsigned source_track = from_track < 0 ? t % track_count : unsigned(from_track) % track_count;
    if (from == to && source_track == t % track_count) return;
    patterns.at[t % track_count][to % pattern_count] = patterns.at[source_track][from % pattern_count];
    sync_pattern(t, to);
}

// Undo and redo. ----------------------------------------------------------

void Context::notice(const std::string& text) {
    std::snprintf(ui.notice, sizeof(ui.notice), "%s", text.c_str());
    ui.notice_at = now;
}

void Context::restore_pattern(unsigned t, unsigned p, const Pattern& value) {
    t %= track_count; p %= pattern_count;
    if (patterns.at[t][p] == value) return;
    patterns.at[t][p] = value;
    sync_pattern(t, p);
}

void Context::restore_pad(unsigned t, unsigned kit, const PadState& value) {
    t %= track_count; kit %= sampler_pads;
    set_pad_state(project.tracks[t], kit, value);
    send_pad(t, kit);
    send_trims(t, kit);
    sync_chain(pad_chain(t, kit));
}

// Round 3 "instrument C": kit pad `kit`'s zone trims to the audio thread, afresh (the pad's first let go).
void Context::send_trims(unsigned t, unsigned kit) {
    t %= track_count; kit %= sampler_pads;
    Command clear {Type::ZoneTrim, uint8_t(t), 0, uint16_t(kit)};
    clear.position = UINT32_MAX;
    send(clear);
    for (const auto& z : project.tracks[t].zone_trims)
        if (z.used() && z.pad == kit) send(zone_trim_command(t, z));
}

void Context::delete_pad(unsigned kit) {
    kit %= sampler_pads;
    auto& t = track();
    if (!t.pads[kit].used()) { close_pad_gap(kit); return; } // an empty pad: the pads after it move down one (shell/pad_gap.h)
    Edit edit;
    edit.what = pad_text("Delete", kit); edit.track = ui.track; edit.pad = int16_t(kit);
    edit.pad_before = pad_state(t, kit);
    edit.pad_after = PadState {};
    edit.pad_after.chain.size = pad_slots;
    restore_pad(ui.track, kit, edit.pad_after);
    // Pads after it to move down: say that Erase + this pad again does it (31 bytes at most, the notice's room).
    notice(gap_closes(t, kit) ? pad_text("Deleted", kit) + " \xc2\xb7 again closes gap" : edit.what);
    edits.push(std::move(edit));
}

// Erase + an empty kit pad, stopped (shell/pad_gap.h): the gap closed, as one undo.
void Context::close_pad_gap(unsigned kit) {
    kit %= sampler_pads;
    if (!gap_closes(track(), kit)) { notice(pad_text("Empty", kit)); return; }
    unsigned last = kit + 1; // the last pad with a sample that moves
    for (unsigned n = kit + 1; n < gap_end(kit); ++n) if (track().pads[n].used()) last = n;
    char first_label[4], last_label[4];
    pad_label(kit + 1, first_label); pad_label(last, last_label);
    std::string what = last == kit + 1 ? std::string(first_label) + " moved down one" : std::string(first_label) + "-" + last_label + " moved down one";
    Edit edit = begin_edit(what.c_str(), ui.track, -1, false);
    edit.track_before = std::make_unique<TrackState>(track_state(*this, ui.track));
    edit.master_before = std::make_unique<MasterState>(master_of(project));
    auto next = std::make_unique<TrackState>(*edit.track_before);
    melodee::close_pad_gap(next->track, next->patterns, kit);
    restore_track(*this, ui.track, *next);
    close_pad_gap_names(project, ui.track, kit);
    edit.master_after = std::make_unique<MasterState>(master_of(project));
    if (*edit.master_after == *edit.master_before) { edit.master_before.reset(); edit.master_after.reset(); }
    else restore_master(*edit.master_after);
    edit.track_after = std::move(next);
    edits.push(std::move(edit));
    dirty = true;
    notice(what);
}

void Context::erase_pad_notes(unsigned kit) {
    kit %= sampler_pads;
    const int key = int(sampler_first_note + kit);
    std::string what = pad_text("Erase", kit) + " notes";
    bool found = false;
    auto erase = [&] {
        auto& p = pattern();
        auto before = p.events.size();
        p.events.erase(std::remove_if(p.events.begin(), p.events.end(), [&](const Event& e) { return e.key == key; }), p.events.end());
        if (p.events.size() == before) return;
        sync_pattern(ui.track, track().pattern);
        found = true;
    };
    edit_pattern(ui.track, track().pattern, what.c_str(), erase); // inside a take, part of it
    notice(found ? what : pad_text("No notes on", kit));
}

void Context::copy_pad(unsigned from, unsigned to) {
    from %= sampler_pads; to %= sampler_pads;
    if (from == to) return;
    auto& t = track();
    Edit edit;
    char a[4], b[4]; pad_label(from, a); pad_label(to, b);
    edit.what = std::string("Copy ") + a + " to " + b; edit.track = ui.track; edit.pad = int16_t(to);
    edit.pad_before = pad_state(t, to);
    edit.pad_after = pad_state(t, from);
    restore_pad(ui.track, to, edit.pad_after);
    notice(edit.what);
    edits.push(std::move(edit));
}

Edit Context::begin_edit(const char* what, unsigned t, int p, bool song) {
    close_gesture(); // kept before this edit, as it came first
    Edit edit;
    edit.what = what; edit.track = uint8_t(t % track_count);
    if (p >= 0) { edit.pattern = int16_t(unsigned(p) % pattern_count); edit.pattern_before = std::make_unique<Pattern>(patterns.at[edit.track][edit.pattern]); }
    if (song) edit.song_before = std::make_unique<Song>(project.song);
    return edit;
}

// Keeps what changed since begin_edit(); an edit that changed nothing is dropped.
void Context::commit_edit(Edit&& edit) {
    bool changed = false;
    if (edit.pattern_before) {
        const auto& now = patterns.at[edit.track][unsigned(edit.pattern)];
        bool differs = now != *edit.pattern_before;
        if (differs) edit.pattern_after = std::make_unique<Pattern>(now);
        else { edit.pattern_before.reset(); edit.pattern = -1; }
        changed |= differs;
    }
    // Byte compares: a stray difference only keeps a part that did not change.
    if (edit.song_before) {
        if (std::memcmp(edit.song_before.get(), &project.song, sizeof(Song)) != 0) { edit.song_after = std::make_unique<Song>(project.song); changed = true; }
        else edit.song_before.reset();
    }
    if (edit.motion_before) {
        auto now_motion = track_motion(edit.motion_before->track);
        if (!(now_motion == *edit.motion_before)) { edit.motion_after = std::make_unique<TrackMotion>(std::move(now_motion)); changed = true; }
        else edit.motion_before.reset();
    }
    if (changed) edits.push(std::move(edit));
}

void Context::restore_song(const Song& value) {
    project.song = value;
    sync_song();
    sync_punches();
}

TrackMotion Context::track_motion(unsigned t) const {
    TrackMotion m;
    m.track = uint8_t(t % track_count);
    for (unsigned p = 0; p < pattern_count; ++p) m.lanes[p] = patterns.at[m.track][p].motion;
    return m;
}

void Context::restore_motion(const TrackMotion& value) {
    for (unsigned p = 0; p < pattern_count; ++p) {
        auto& pattern = patterns.at[value.track % track_count][p];
        if (pattern.motion == value.lanes[p]) continue;
        pattern.motion = value.lanes[p];
        sync_pattern(value.track, p);
    }
}

void Context::apply_edit(const Edit& e, bool after) {
    if (e.pad >= 0) restore_pad(e.track, unsigned(e.pad), after ? e.pad_after : e.pad_before);
    if (after) for (const auto& [kit, value] : e.pads_after) restore_pad(e.track, kit, value);
    else for (auto p = e.pads_before.rbegin(); p != e.pads_before.rend(); ++p) restore_pad(e.track, p->first, p->second);
    const auto& pattern = after ? e.pattern_after : e.pattern_before;
    if (e.pattern >= 0 && pattern) restore_pattern(e.track, unsigned(e.pattern), *pattern);
    const auto& song = after ? e.song_after : e.song_before;
    if (song) restore_song(*song);
    const auto& motion = after ? e.motion_after : e.motion_before;
    if (motion) restore_motion(*motion);
    const auto& whole = after ? e.track_after : e.track_before;
    if (whole) restore_track(*this, e.track, *whole); // last: its pack carries the motion as restored
    if (e.swap_a >= 0) trade_tracks(*this, unsigned(e.swap_a), unsigned(e.swap_b)); // a move: the same swap again
    if (e.column >= 0)
        for (const auto& [t, value] : after ? e.column_after : e.column_before) restore_pattern(t, unsigned(e.column), value);
    for (const auto& p : after ? e.patterns_after : e.patterns_before) restore_pattern(p.track, p.pattern, p.value); // roadmap P5
    const auto& chain = after ? e.chain_after : e.chain_before;
    if (e.chain >= 0 && chain) restore_chain(unsigned(e.chain), *chain);
    if (const auto& m = after ? e.mix_after : e.mix_before) restore_mix(*m);
    if (const auto& m = after ? e.sound_after : e.sound_before) restore_sound(e.track, *m);
    if (const auto& m = after ? e.master_after : e.master_before) restore_master(*m);
    if (const auto& m = after ? e.chop_after : e.chop_before) restore_chop(*m);
    if (e.pattern_was >= 0 && e.pattern >= 0) { // the pattern it played before, or the one the edit made it play
        auto& tr = project.tracks[e.track % track_count];
        tr.pattern = uint8_t(unsigned(after ? e.pattern : e.pattern_was) % pattern_count);
        send({Type::Pattern, uint8_t(e.track % track_count), 0, 0, int16_t(tr.pattern)});
    }
    if (const auto& m = after ? e.tempo_after : e.tempo_before) {
        for (unsigned n = 0; n < pattern_count; ++n)
            if (project.pattern_tempo[n] != m->patterns[n]) { project.pattern_tempo[n] = m->patterns[n]; send({Type::PatternTempo, 0, 0, uint16_t(n), int16_t(m->patterns[n])}); }
        if (project.tempo != m->tempo) { project.tempo = m->tempo; send({Type::Tempo, 0, 0, 0, int16_t(project.tempo)}); }
        if (project.seq_tempo != m->per_pattern) { project.seq_tempo = m->per_pattern; send({Type::SeqTempo, 0, 0, ui.lead_pattern, int16_t(m->per_pattern)}); }
    }
    dirty = true;
    take_track = -1;
}

void Context::flush_usage() {
    if (!store || !usage.on()) return;
    auto text = usage.take(now);
    if (!text.empty()) store->append_usage(usage.file(), text);
}

void Context::undo() {
    if (ui.page == PageId::Roll) roll_unmark(ui);
    end_take();                             // a Chop take is the step undone, whole
    close_gesture();                        // a pot's turns just made are the step undone
    close_hold(hold.pad);                   // so is a held pad's note
    if (ui.recording) set_recording(false); // a take in progress ends, and is the edit undone
    if (const Edit* last = edits.last(); last && last->swap_a >= 0) // a track move waits for a take that hears it
        if (auto why = swap_waits(*this, unsigned(last->swap_a), unsigned(last->swap_b)); !why.empty()) { notice("Undo: " + why); return; }
    if (const Edit* last = edits.last(); last && edit_covers(*last)) { ask_unfreeze(edit_track(*last)); return; } // freeze plan F2c
    Edit* e = edits.undo();
    if (!e) { notice("Nothing to undo"); return; }
    apply_edit(*e, false);
    swap_plugin(*e, false);
    usage.undo(now, false, e->what, ui.page);
    notice("Undo " + e->what);
}

void Context::redo() {
    if (ui.page == PageId::Roll) roll_unmark(ui);
    close_gesture();
    close_hold(hold.pad);
    if (ui.recording) return; // a take in progress would be lost under it
    if (const Edit* next = edits.next(); next && next->swap_a >= 0)
        if (auto why = swap_waits(*this, unsigned(next->swap_a), unsigned(next->swap_b)); !why.empty()) { notice("Redo: " + why); return; }
    if (const Edit* next = edits.next(); next && edit_covers(*next)) { ask_unfreeze(edit_track(*next)); return; } // freeze plan F2c
    Edit* e = edits.redo();
    if (!e) { notice("Nothing to redo"); return; }
    apply_edit(*e, true);
    swap_plugin(*e, true);
    usage.undo(now, true, e->what, ui.page);
    notice("Redo " + e->what);
}

void Context::set_length(uint32_t ticks) {
    auto& p = pattern();
    ticks = std::clamp<uint32_t>(ticks, 1, project.max_length());
    stop_growing(ui.track, track().pattern);
    if (p.length == ticks && !p.free) return;
    p.length = ticks;
    p.free = false;
    sync_pattern(ui.track, track().pattern);
}

// K1 turned below 1 bar: an empty pattern with no notes on another track in its sequence is Free again, a bar long
// until a take sets its length (shell/free_length.h).
void Context::set_free() {
    auto& p = pattern();
    unsigned bar = std::max(project.bar_ticks(), 1u);
    if (!free_offered(p, column_fit(project, patterns, ui.track, track().pattern).length)) return;
    if (p.free && p.length == bar) return;
    p.free = true;
    p.length = bar;
    p.fit_lanes();
    sync_pattern(ui.track, track().pattern);
}

void Context::stop_growing(unsigned t, unsigned p) {
    if (free_take.track == int(t % track_count) && free_take.pattern == int(p % pattern_count)) free_take = {};
}

// Seq Record on an empty Free pattern. With notes on another track in its sequence, it takes the longest of them
// and counts with that track; else it grows a bar at a time from the bar playing (free_tick()).
void Context::start_free(unsigned t, unsigned p, bool song) {
    free_take = {};
    t %= track_count; p %= pattern_count;
    auto& pat = patterns.at[t][p];
    if (!pat.is_free() || song) return;
    ColumnFit fit = column_fit(project, patterns, t, p);
    pat.free = false;
    if (fit.length) {
        pat.length = fit.length;
        pat.fit_lanes();
        sync_pattern(t, p);
        if (host.playing()) send({Type::Rebase, uint8_t(t), uint8_t(p), uint16_t(fit.track)});
        return;
    }
    pat.length = std::max(project.bar_ticks(), 1u);
    pat.fit_lanes();
    sync_pattern(t, p);
    free_take.track = int(t); free_take.pattern = int(p);
    free_tick();
    notice("P" + std::to_string(p + 1) + " Free: Seq Record ends it");
}

// The take on a Free pattern ends: at the end of the bar playing, or in a bar's first eighth at that bar line,
// with what was played since moved to the top. Nothing taken: Free again.
void Context::end_free() {
    if (free_take.track < 0) return;
    FreeTake take = free_take;
    free_take = {};
    unsigned t = unsigned(take.track) % track_count, p = unsigned(take.pattern) % pattern_count;
    auto& pat = patterns.at[t][p];
    unsigned bar = std::max(project.bar_ticks(), 1u);
    if (pat.empty() && pat.motion.empty()) {
        pat.free = true;
        pat.length = bar;
        sync_pattern(t, p);
        return;
    }
    if (!take.full) {
        uint32_t position = take.seen;
        if (take.rebased && host.playing() && !host.count_in() && host.pattern_of(t) % pattern_count == p) {
            int at = host.position_of(t);
            if (at >= 0) position = uint32_t(at);
        }
        free_close(pat, free_end(position, bar, ticks_per_quarter / 2, project.max_length()));
        sync_pattern(t, p);
    }
    unsigned bars = pattern_bars(project, pat);
    notice("P" + std::to_string(p + 1) + ": " + std::to_string(bars) + (bars == 1 ? " bar" : " bars"));
}

// Often (shell/lights.cpp): the growing take keeps the bar playing and the next in its pattern; K1's card learns
// what the selected pattern's sequence holds.
void Context::free_tick() {
    unsigned selected = ui.track % track_count, shown = track().pattern % pattern_count;
    ui.column_ticks = column_fit(project, patterns, selected, shown).length;
    ui.free_growing = free_take.track == int(selected) && free_take.pattern == int(shown);
    if (free_take.track < 0 || free_take.full) return;
    unsigned t = unsigned(free_take.track) % track_count, p = unsigned(free_take.pattern) % pattern_count;
    if (!host.playing() || host.count_in() || host.song_playing() || host.pattern_of(t) % pattern_count != p) return;
    int at = host.position_of(t);
    if (at < 0) return;
    auto& pat = patterns.at[t][p];
    uint32_t bar = std::max(project.bar_ticks(), 1u), most = project.max_length(), position = uint32_t(at);
    if (!free_take.rebased) { // from the top of the bar playing, then its pattern grows ahead of it
        send({Type::Rebase, uint8_t(t), uint8_t(p), uint16_t(0xffff)});
        free_take.rebased = true;
        position %= bar;
    }
    free_take.seen = position;
    uint32_t want = free_grown(position, bar, most);
    if (want > pat.length) { pat.length = want; sync_pattern(t, p); }
    if (pat.length >= most && position + bar >= most) {
        free_take.full = true;
        notice("P" + std::to_string(p + 1) + ": " + std::to_string(max_bars) + " bars, the most");
    }
}

void Context::set_division(Division division) {
    if (pattern().division == division) return;
    pattern().division = division;
    sync_pattern(ui.track, track().pattern);
}

// Every pattern shares the time signature; one of whole bars keeps its bar count.
void Context::set_signature(unsigned index) {
    index %= time_signature_count;
    if (index == project.signature) return;
    unsigned before = project.bar_ticks();
    project.signature = uint8_t(index);
    unsigned after = project.bar_ticks();
    for (unsigned t = 0; t < track_count; ++t)
        for (unsigned p = 0; p < pattern_count; ++p) {
            auto& pattern = patterns.at[t][p];
            if (pattern.length % before) continue;
            pattern.length = std::min<uint32_t>(pattern.length / before * after, project.max_length());
            sync_pattern(t, p);
        }
    send({Type::Signature, 0, 0, uint16_t(project.beat_ticks()), int16_t(after)});
    auto sig = project.time_signature();
    notice("Time signature " + std::to_string(sig.beats) + "/" + std::to_string(sig.unit));
}

// A tempo change is one undo step: the wheel's and K1's turns join it until a press or two seconds still.
static void touch_tempo(Context& c) {
    auto& g = c.gesture;
    if (g.edit && g.scope.kind == UndoScope::Kind::Tempo && c.now - g.last < gesture_quiet_ms) { g.last = c.now; return; }
    c.touch_scope({UndoScope::Kind::Tempo, uint8_t(c.ui.track % track_count), 0}, uint32_t(UndoScope::Kind::Tempo) << 24);
}

void Context::set_seq_tempo(bool on) {
    touch_tempo(*this);
    project.seq_tempo = on;
    send({Type::SeqTempo, 0, 0, ui.lead_pattern, int16_t(on)});
    notice(on ? "BPM per pattern" : "BPM global");
}

// The wheel on Patterns: the playhead by a beat, or with Shift by Q. Stopped,
// it sets where Shift + Play carries on from. ui.locate is a place in the
// selected track's pattern as written; the transport's tick is that place as
// the track plays it, at its speed.
void Context::locate(int way) {
    const auto& p = pattern();
    unsigned step = ui.shift ? p.q() : project.beat_ticks();
    uint32_t from = host.playing() ? uint32_t(written_ticks(host.ticks(), track().speed)) : ui.locate;
    int64_t at = int64_t(from / step * step) + int64_t(way) * step;
    ui.locate = uint32_t(std::max<int64_t>(at, 0)) % std::max<uint32_t>(p.length, 1);
    if (host.playing() && !host.song_playing()) { Command c {Type::Locate}; c.position = uint32_t(played_ticks(ui.locate, track().speed)); send(c); }
}

void Context::send_pad(unsigned t, unsigned n) {
    Command c {Type::Pad, uint8_t(t), 0, uint16_t(n % sampler_pads)};
    c.pad = project.tracks[t % track_count].pads[n % sampler_pads];
    send(c);
}

int Context::sample_slot(const std::string& path, const std::string& name) {
    if (path.size() >= sizeof(SampleRef::path)) return -1;
    int free = -1;
    for (unsigned n = 0; n < sample_slots; ++n) {
        if (project.samples[n].used() && path == project.samples[n].path) return int(n); // already in the project
        if (free < 0 && !project.samples[n].used()) free = int(n);
    }
    if (free < 0 || !library || path.size() >= sizeof(SampleRef::path)) return -1; // a path cut short opens nothing
    auto& ref = project.samples.edit(size_t(free));
    project.chops.edit(size_t(free)) = read_mpc_slices(path); // the file's own slices (an MPC's), not the slot's last file's
    std::strncpy(ref.path, path.c_str(), sizeof(ref.path) - 1);
    std::strncpy(ref.name, name.c_str(), sizeof(ref.name) - 1);
    ref.frames = 0; // known once loaded
    if (!library->load(unsigned(free), path)) slots_waiting.push_back(uint16_t(free)); // a kit of many: the rest as the queue drains
    return free;
}

// Chop's slices of the region it holds, by its type. Manual starts as one
// slice, the whole region, armed: pad 1 plays it and the pads tapped
// meanwhile cut it (chop_tap()).
// What Chop's type and amount cut of the region now, without the hand's cuts.
Slices Context::type_chop(bool* capped) const {
    if (!library || ui.chop_sample >= sample_slots) return {};
    auto loaded = library->slot(ui.chop_sample);
    int amount = ui.chop_amount[size_t(ui.chop_mode) % ui.chop_amount.size()];
    if (ui.chop_mode == ChopMode::Beats) amount = int(division_sixteenths(unsigned(std::max(amount, 0)), project.bar_ticks() / sixteenth_ticks)); // in 16ths
    if (ui.chop_mode == ChopMode::Auto) { // engine/auto_chop.h: by what the sample is (with CLEAN, its DRUMS stem)
        const auto read = chop_cut_slot() == ui.chop_sample ? loaded : library->slot(chop_cut_slot());
        return auto_chop(read.autos, auto_slice_count(amount), ui.chop_from, ui.chop_to, loaded.frames, read.hits, read.hit_count, read.beats, capped);
    }
    return chop(ui.chop_mode, amount, ui.chop_from, ui.chop_to, loaded.frames, loaded.hits, loaded.hit_count, project.tempo, &loaded.beats, capped);
}

void Context::rechop() {
    end_take(); ui.chop_more = false; ui.chop_take_from = 0; // a take in progress is kept as it was; no red left over
    if (!library || ui.chop_sample >= sample_slots) { ui.slices = {}; return; }
    bool capped = false, full = false;
    const uint32_t frames = chop_frames(project, ui);
    uint32_t clear = 0; // Auto keeps an eighth note (or 150 ms) clear of a hand cut: no sliver beside one
    if (ui.chop_mode == ChopMode::Auto) { const auto read = library->slot(chop_cut_slot()); clear = auto_keep_clear(read.autos, read.beats); }
    ui.slices = with_hand(type_chop(&capped), ui.chop_hand, frames, &full, clear); // the cuts made by hand stay
    if (capped || full) notice("64 slices, the most: the last runs to the end");
    snap_slices();
    ui.chop_slice = uint8_t(std::min<unsigned>(ui.chop_slice, ui.slices.count ? ui.slices.count - 1 : 0));
    ui.chop_take_at = 0;
}

void Context::follow_tempos() {
    auto& t = track();
    for (unsigned n = 0; n < sampler_pads; ++n) {
        auto& pad = t.pads[n];
        uint32_t frames = pad.used() ? project.samples[pad.sample % sample_slots].frames : 0;
        if (!frames || pad.warp == warp_seq_stretch) continue;
        uint32_t end = pad.end ? pad.end : frames, length = end > pad.start ? end - pad.start : 0;
        if (length < 4410) continue; // a hit, not a loop: it keeps its speed
        // The number of bars that puts it nearest the project's tempo, between 70 and 180 BPM.
        double best = 0, target = project.tempo / 10.0;
        for (double bars : {0.25, 0.5, 1.0, 2.0, 4.0, 8.0}) {
            double bpm = bars * 4 * 60 * 44100.0 / length;
            if (bpm >= 70 && bpm <= 180 && (best == 0 || std::fabs(bpm - target) < std::fabs(best - target))) best = bpm;
        }
        pad.own_tempo = uint16_t(best * 10);
        send_pad(ui.track, n);
    }
}

bool Context::host_recording() const { return host.recorder().state() != TakeRecorder::State::Idle; }

void Context::chop_to_pads(SlicePlay play, bool with_pattern) {
    auto& t = track();
    uint32_t frames = ui.chop_sample < sample_slots ? project.samples[ui.chop_sample].frames : 0;
    if (!frames || (play == SlicePlay::Kit && !library)) return;
    // The pad chopped (the last pad, a region of the sample inside the chop's or the region itself; else the first
    // holding the region): each slice takes its values.
    auto chopped = [&](const PadSound& p) { return p.sample == ui.chop_sample && p.start == ui.chop_from && p.end == ui.chop_to; };
    PadSound parent;
    parent.sample = ui.chop_sample;
    const auto& last = t.pads[t.last_pad % sampler_pads];
    if (last.used() && last.sample == ui.chop_sample) parent = last;
    else for (const auto& p : t.pads) if (chopped(p)) { parent = p; break; }
    const uint8_t group = slice_group(parent, t.pads); // MONO and THRU: one at a time; KIT: the hats
    std::array<int, max_slices> keys; // each slice's note, for the pattern
    keys.fill(-1);
    Edit edit = begin_edit("Slices to pads", ui.track, -1, false); // one undo: the pads, the pattern and which plays
    auto lay = [&](unsigned pad, const PadSound& one) {
        edit.pads_before.emplace_back(uint8_t(pad), pad_state(t, pad));
        t.pads[pad] = one;
        send_pad(ui.track, pad);
        edit.pads_after.emplace_back(uint8_t(pad), pad_state(t, pad));
    };
    unsigned pad = 0, laid = 0;
    std::string said;
    if (play == SlicePlay::Kit) { // one pad a sound, kicks first; the hats in one mute group
        const unsigned from = chop_cut_slot(); // with CLEAN on: the sounds and the pads from the DRUMS stem
        const auto loaded = library->slot(from);
        bool hats = false;
        std::array<int, max_slices> sound_of; // each slice's sound, so the pattern plays its pad
        const auto sounds = kit_sounds(ui.slices, frames, loaded.hits, loaded.hit_count, loaded.autos, &sound_of);
        std::vector<int> note(sounds.size(), -1);
        for (size_t k = 0; k < sounds.size(); ++k) {
            while (pad < sampler_pads && t.pads[pad].used()) ++pad;
            if (pad >= sampler_pads) break;
            const auto& sound = sounds[k];
            PadSound one = slice_pad(parent, ui.slices, sound.slice, frames, SlicePlay::Poly, group);
            one.sample = uint16_t(from);
            if (sound.kind == KitKind::Hat || sound.kind == KitKind::OpenHat) { one.group = group; hats = true; }
            lay(pad, one);
            note[k] = int(sampler_first_note + pad);
            ++laid;
        }
        for (unsigned n = 0; n < ui.slices.count && n < max_slices; ++n)
            if (sound_of[n] >= 0) keys[n] = note[size_t(sound_of[n])];
        if (laid) said = "Kit: " + std::to_string(laid) + (laid == 1 ? " sound" : " sounds") + (hats ? ", hats in mute group " + std::to_string(group) : "");
    } else {
        for (unsigned n = 0; n < ui.slices.count && n < max_slices; ++n) {
            while (pad < sampler_pads && t.pads[pad].used()) ++pad; // from the first free pad on
            if (pad >= sampler_pads) break;
            lay(pad, slice_pad(parent, ui.slices, n, frames, play, group));
            keys[n] = int(sampler_first_note + pad);
            ++laid;
        }
        if (play != SlicePlay::Poly && laid) said = std::string(play == SlicePlay::Thru ? "Thru" : "Mono") + ": mute group " + std::to_string(group);
    }
    // The pattern (Live's Slice to New MIDI Track): into the track's pattern when it holds nothing, else the first that
    // holds nothing, which then plays; none free, none written. The pattern's own settings (Q, feel, what follows) stay.
    if (with_pattern && laid) {
        auto& slots = patterns.at[ui.track % track_count];
        auto blank = [&](unsigned p) { const auto& x = slots[p]; return x.empty() && x.motion.empty() && x.punches.empty() && x.euclids.empty(); };
        unsigned target = t.pattern % pattern_count;
        if (!blank(target)) for (target = 0; target < pattern_count && !blank(target); ++target) {}
        if (target < pattern_count) {
            const uint32_t region = ui.slices.end(ui.slices.count - 1, frames) - ui.slices.start[0];
            const double per_frame = slice_ticks_per_frame(parent, t.params[sampler::Follow] != 0, region, project.tempo_of(target));
            const Pattern made = slice_pattern(ui.slices, frames, keys, per_frame, project.bar_ticks(), project.max_length());
            edit.pattern = int16_t(target);
            edit.pattern_before = std::make_unique<Pattern>(slots[target]);
            slots[target].length = made.length;
            slots[target].events = made.events;
            slots[target].free = false;
            edit.pattern_after = std::make_unique<Pattern>(slots[target]);
            sync_pattern(ui.track, target);
            if (target != t.pattern % pattern_count) { edit.pattern_was = int16_t(t.pattern % pattern_count); launch(ui.track, target); }
            const unsigned bars = made.length / std::max(1u, project.bar_ticks());
            said += (said.empty() ? "" : "; ") + std::string("P") + std::to_string(target + 1) + ": " + std::to_string(made.events.size()) +
                    (made.events.size() == 1 ? " note, " : " notes, ") + std::to_string(bars) + (bars == 1 ? " bar" : " bars");
        } else said += (said.empty() ? "" : "; ") + std::string("No empty pattern for the slices");
    }
    if (laid) edits.push(std::move(edit));
    if (!said.empty()) notice(said);
}

// A track chain changed shape: motion on its effects named slots that now
// hold something else, so it goes.
void Context::clear_fx_motion(unsigned n) {
    if (n >= track_count) return;
    for (unsigned p = 0; p < pattern_count; ++p) {
        auto& motion = patterns.at[n][p].motion;
        auto before = motion.size();
        motion.erase(std::remove_if(motion.begin(), motion.end(), [](const MotionPoint& m) { // pad lanes stay
            return m.param >= motion_fx_base && m.param < motion_pad_base; }), motion.end());
        if (motion.size() != before) sync_pattern(n, p);
    }
}

void Context::set_effect(unsigned n, unsigned slot, EffectKind kind) {
    auto& chain = project.chain(n);
    if (slot >= chain.size) return;
    clear_fx_motion(n);
    auto& s = chain.slots[slot];
    if (kind == EffectKind::None) { // remove: the rest close up
        for (unsigned k = slot + 1; k < chain.size; ++k) chain.slots[k - 1] = chain.slots[k];
        chain.slots[chain.size - 1] = EffectSlot {};
        sync_chain(n);
        return;
    }
    s.kind = uint8_t(kind); s.bypass = false; s.key = 0;
    const auto& info = effect_info(kind);
    for (unsigned q = 0; q < effect_params; ++q) s.params[q] = info.params[q].label ? info.params[q].initial : 0;
    send_fx(Type::FxKind, n, slot, 0, int16_t(kind)); // the host takes the same initial values
    send_fx(Type::FxBypass, n, slot, 0, 0);
}

void Context::set_effect_param(unsigned n, unsigned slot, unsigned param, int value) {
    auto& chain = project.chain(n);
    if (slot >= chain.size || param >= effect_params) return;
    chain.slots[slot].params[param] = int16_t(value);
    send_fx(Type::FxParam, n, slot, param, int16_t(value));
}

void Context::set_effect_key(unsigned n, unsigned slot, unsigned key) {
    auto& chain = project.chain(n);
    if (n >= chain_count || slot >= chain.size || !fx_keyable(chain.slots[slot].kind)) return;
    if (key >= fx_keys || (fx_key_is_track(key) && n < track_count && key - 1 == n)) key = 0; // a track keyed by itself hears itself
    chain.slots[slot].key = uint8_t(key);
    send({Type::FxKey, uint8_t(n), 0, uint16_t(slot), int16_t(key)});
}

void Context::toggle_bypass(unsigned n, unsigned slot) {
    auto& s = project.chain(n).slots[slot % max_slots];
    if (slot >= project.chain(n).size) return;
    s.bypass = !s.bypass;
    send_fx(Type::FxBypass, n, slot, 0, int16_t(s.bypass));
}

void Context::move_effect(unsigned n, unsigned slot, int way) {
    auto& chain = project.chain(n);
    int to = int(slot) + way;
    if (to < 0 || unsigned(to) >= chain.count() || slot >= chain.count()) return;
    clear_fx_motion(n);
    std::swap(chain.slots[slot], chain.slots[size_t(to)]);
    sync_chain(n);
}

// Copy (Shift + Erase on a chain page): slot `slot` again right after it, the rest one along; a full chain keeps as it is.
void Context::copy_effect(unsigned n, unsigned slot) {
    auto& chain = project.chain(n);
    unsigned count = chain.count();
    if (slot >= count || count >= chain.size) return;
    clear_fx_motion(n);
    for (unsigned k = count; k > slot + 1; --k) chain.slots[k] = chain.slots[k - 1];
    chain.slots[slot + 1] = chain.slots[slot];
    sync_chain(n);
}

void Context::sync_chain(unsigned n) {
    const auto& chain = project.chain(n);
    for (unsigned k = 0; k < chain.size; ++k) {
        const auto& s = chain.slots[k];
        send_fx(Type::FxKind, n, k, 0, int16_t(s.kind));
        for (unsigned q = 0; q < effect_params; ++q) send_fx(Type::FxParam, n, k, q, s.params[q]);
        send_fx(Type::FxBypass, n, k, 0, int16_t(s.bypass));
        if (n < chain_count) send({Type::FxKey, uint8_t(n), 0, uint16_t(k), int16_t(s.key)}); // roadmap P4
    }
}

// A chain's command: a track, bus or master chain by number; a pad's chain
// as PadFx*, with the track, the pad and the slot and parameter together.
void Context::send_fx(Command::Type type, unsigned n, unsigned slot, unsigned param, int16_t value) {
    if (n < pad_chain_base) { send({type, uint8_t(n), uint8_t(param), uint16_t(slot), value}); return; }
    n -= pad_chain_base;
    Type pad = type == Type::FxKind ? Type::PadFxKind : type == Type::FxParam ? Type::PadFxParam : Type::PadFxBypass;
    send({pad, uint8_t(n / sampler_pads), uint8_t(n % sampler_pads), uint16_t(slot | param << 8), value});
}

void Context::set_return(unsigned bus, int level) {
    project.buses[bus % bus_count].level = uint8_t(std::clamp(level, 0, 100));
    send({Type::Return, 0, 0, uint16_t(bus % bus_count), int16_t(level)});
}

void Context::sync_song() {
    const auto& song = project.song;
    for (unsigned n = 0; n < song.count; ++n) {
        Command c {Type::SongClip, 0, 0, uint16_t(n)};
        c.clip = song.clips[n];
        send(c);
    }
    send({Type::SongCount, 0, 0, 0, int16_t(song.count)});
    send({Type::SongLoop, 0, 0, song.loop_start, int16_t(song.loop_end)});
    for (unsigned n = 0; n < song.tempo.count; ++n) { // roadmap P5: its tempo lane
        const auto& p = song.tempo.points[n];
        Command c {Type::SongTempo, 0, uint8_t(p.ramp), uint16_t(n), int16_t(p.tempo)};
        c.position = p.bar;
        send(c);
    }
    send({Type::SongTempoCount, 0, 0, 0, int16_t(song.tempo.count)});
}

// On the Song page Play plays the arrangement from the cursor; elsewhere the
// patterns (open question 4: Song's controls).
void Context::set_arp(unsigned track, bool on) {
    uint8_t n = uint8_t(track % track_count);
    auto& t = project.tracks[n];
    t.arp = on;
    // Notes the pads hold on that track stop; the arp starts with what is pressed next.
    for (unsigned p = 0; p < pad_keys.size(); ++p)
        if (pad_track[p] == n) for (auto& k : pad_keys[p]) if (k >= 0) { note(n, k, 0); k = -1; }
    if (on) {
        send({Type::Arp, n, 0, 1, t.arp_mode}); send({Type::Arp, n, 0, 2, t.arp_rate});
        send({Type::Arp, n, 0, 3, int16_t(t.engine == EngineKind::Sampler ? 1 : t.arp_octaves)}); // a kit repeats its pad
        send({Type::Arp, n, 0, 4, t.arp_gate});
    }
    send({Type::Arp, n, 0, 0, int16_t(on)});
}

void Context::set_repeat(unsigned track, bool on) {
    uint8_t n = uint8_t(track % track_count);
    auto& t = project.tracks[n];
    t.repeat = on;
    // Notes the pads hold on that track stop; Note Repeat starts with what is pressed next.
    for (unsigned p = 0; p < pad_keys.size(); ++p)
        if (pad_track[p] == n) for (auto& k : pad_keys[p]) if (k >= 0) { note(n, k, 0); k = -1; }
    if (on) {
        send({Type::Repeat, n, 0, 2, t.repeat_rate});
        send({Type::Repeat, n, 0, 5, int16_t(ui.settings.repeats_by_pressure())}); // Settings > PADS: Repeat velocity
    }
    send({Type::Repeat, n, 0, 0, int16_t(on)});
}

void Context::set_click(unsigned mode) {
    ui.settings.click = uint8_t(mode % 3);
    send_click();
    if (store) store->save_settings(ui.settings.text());
}

// The audio thread only hears on or off: Rec is on while Seq Record is.
// Note Repeat's velocity on every track: the pad's strike, or its pressure (Settings > PADS: Repeat velocity).
void Context::send_repeat_velocity() {
    for (unsigned t = 0; t < track_count; ++t) send({Type::Repeat, uint8_t(t), 0, 5, int16_t(ui.settings.repeats_by_pressure())});
}

void Context::send_click() {
    const auto& set = ui.settings;
    bool on = set.click == 1 || (set.click == 2 && (ui.recording || loop_click)); // a loop recording counts (docs/LOOPER.md)
    send({Type::Click, 0, 0, set.click_level, int16_t(on)});
}

// Play: from the start (on Song, the arrangement from the cursor). Seq Record
// armed, the take begins, after a bar's count when Count-In is on.
void Context::play(bool external) {
    ui.roll_stopped_tick = -1;
    if (host.playing()) return;
    played_song = ui.page == PageId::Song;
    ui.span_count = 0; // the punches heard (pad-fx C) counted from this Play
    if (ui.rec_armed) { ui.rec_armed = false; set_recording(true); }
    // A loop armed while stopped counts in as a recording does (docs/LOOPER.md).
    bool count = (ui.recording || host.looper().armed()) && ui.settings.count_in && !external;
    if (played_song) send({Type::Play, uint8_t(count), 0, ui.song_cursor, 1});
    else send({Type::Play, uint8_t(count)});
    if (external) send({Type::ExtSync, 0, 0, 3}); // the ticks wait for the clock's pulses
}

// Play held while playing: Fill, until it is let go (trig conditions FILL and NOT FILL, model/trig.h).
void Context::fill(bool on) {
    if (on == ui.fill) return;
    ui.fill = on;
    send({Type::Fill, 0, 0, 0, int16_t(on)});
    if (on) notice("Fill");
}

// Shift + Play: on from where it stopped (or where the wheel moved it on Patterns).
void Context::play_continue(bool external) {
    ui.roll_stopped_tick = -1;
    if (host.playing()) return;
    ui.span_count = 0; // the punches heard (pad-fx C) counted from this Play
    if (ui.rec_armed) { ui.rec_armed = false; set_recording(true); }
    bool count = (ui.recording || host.looper().armed()) && ui.settings.count_in && !external;
    if (played_song) send({Type::Play, uint8_t(count), 0, uint16_t(host.song_bar()), 1}); // from the bar it stopped in
    else { Command c {Type::Play, uint8_t(count)}; c.position = uint32_t(played_ticks(ui.locate, track().speed)); send(c); } // as the track plays it
    if (external) send({Type::ExtSync, 0, 0, 3});
}

// Shift + Loop: the last pad plays backwards, or forwards again.
void Context::toggle_reverse() {
    auto& t = track();
    if (t.engine != EngineKind::Sampler || !pad().used()) { notice("Reverse: no sample"); return; }
    pad().reverse = !pad().reverse;
    send_pad(ui.track, t.last_pad);
    dirty = true;
    notice(pad().reverse ? "Reverse on" : "Reverse off");
}

void Context::double_length() {
    if (pattern().length * 2 > project.max_length()) { notice("Double Seq: " + std::to_string(max_bars) + " bars at most"); return; }
    edit_pattern(ui.track, track().pattern, "Double Seq", [&] { double_notes(); });
    notice("Double Seq");
}

void Context::double_notes() {
    auto& p = pattern();
    bool copy = ui.settings.double_copies;
    if (!double_pattern(p, project.max_length(), copy)) return; // its motion too (Settings' Empty: the new half bare)
    stop_growing(ui.track, track().pattern);
    p.free = false; // a length set by hand
    sync_pattern(ui.track, track().pattern);
}

void Context::half_length() {
    auto& p = pattern();
    uint32_t half = std::max<uint32_t>(p.length / 2, 1);
    if (half == p.length) return;
    edit_pattern(ui.track, track().pattern, "Half Seq", [&] {
        stop_growing(ui.track, track().pattern);
        p.free = false; // a length set by hand
        half_pattern(p); // its motion past the half goes with the notes
        sync_pattern(ui.track, track().pattern);
    });
    notice("Half Seq");
}

void Context::half_speed() {
    edit_pattern(ui.track, track().pattern, "Half Speed", [&] { scale_notes(true); });
    notice("Half Speed");
}

void Context::double_speed() {
    edit_pattern(ui.track, track().pattern, "Double Speed", [&] { scale_notes(false); });
    notice("Double Speed");
}

// Every note (and its motion) twice as far from the start and twice as long,
// or half; the pattern keeps its length, and what falls past its end goes.
void Context::scale_notes(bool slower) {
    auto& p = pattern();
    scale_pattern(p, slower); // its motion with the notes
    sync_pattern(ui.track, track().pattern);
}

// Time Correct's Do It: the chosen notes onto the nearest step of Q, every
// second step of a straight Q late by the swing, then moved by the shift.
void Context::time_correct() {
    const auto& t = track();
    edit_pattern(ui.track, t.pattern, "Time Correct", [&] {
        time_correct_all(pattern(), ui.tc_all ? nullptr : &ui.tc_keys, ui.tc_swing, ui.tc_shift);
        sync_pattern(ui.track, t.pattern);
    });
    notice("Time Correct");
}

// Seq Record on: the take begins, with what it may change as it is now.
// Off: the clips being written end, and the take goes into the history.
void Context::set_recording(bool on) {
    if (on == ui.recording) return;
    if (track().is_audio() || (!on && audio_take_track >= 0)) { // freeze plan F3: an audio track's take (shell/audio_jobs.cpp)
        ui.rec_armed = false;
        if (on && !record_audio(ui.track)) return;
        if (!on) end_audio(true);
        ui.recording = on;
        if (ui.settings.click == 2) send_click();
        return;
    }
    ui.recording = on;
    send({Type::SongRecord, 0, 0, 0, int16_t(on)});
    if (ui.settings.click == 2) send_click(); // the Rec metronome follows Seq Record
    if (on) {
        ui.rec_armed = false;
        take_track = ui.track; take_pattern = track().pattern;
        take_edit = std::make_unique<Edit>(begin_edit("Take", ui.track, track().pattern, true));
        start_free(ui.track, track().pattern, host.playing() ? host.song_playing() : played_song); // part of the take
        return;
    }
    for (auto& h : held_notes) h.key = -1; // notes held on keep the length they were written with
    end_free(); // a Free pattern's length, in the take
    song_tick(); // finishes the clips and the punch being written
    if (take_edit) commit_edit(std::move(*take_edit));
    take_edit.reset();
}

// Seq Record, as on the MPC: stopped it arms (Play starts the take); playing
// it records at once; recording, it stops recording and playback goes on.
void Context::seq_record() {
    if (ui.recording) { set_recording(false); return; }
    if (frozen_edit(ui.track)) return; // freeze plan F2c: "Unfreeze track N?" first
    if (host.playing()) { set_recording(true); return; }
    ui.rec_armed = !ui.rec_armed;
}

// Stop ends playback and recording together; Shift + Play carries on from here.
void Context::stop() {
    harmony_stop_preview(*this);drum_stop(*this);
    const bool playing = host.playing();
    if (!playing) send({Type::AllNotesOff, 255});
    else if (!host.song_playing()) ui.locate = uint32_t(std::max(host.position_of(ui.track), 0));
    if (melodee_roll_page(ui.page)) {
        const auto index = track().pattern;
        const bool held = ui.roll_stopped_tick >= 0 && ui.roll_stopped_track == ui.track &&
                          ui.roll_stopped_pattern == index;
        const int at = playing && !held && host.pattern_of(ui.track) == index ? host.position_of(ui.track) : 0;
        auto& active_pattern = pattern();
        ui.roll_stopped_tick = active_pattern.length ? int32_t(unsigned(std::max(at, 0)) % active_pattern.length) : 0;
        ui.roll_stopped_track = ui.track;
        ui.roll_stopped_pattern = index;
        ui.locate = uint32_t(ui.roll_stopped_tick);
        ui.step_cursor = int16_t(std::min<uint32_t>(ui.locate / active_pattern.q(), INT16_MAX));
        ui.steps_bar = uint8_t(std::min<unsigned>(unsigned(ui.step_cursor) / bar_steps, 255));
        ui.roll_view = 0;
        roll_follow(active_pattern, ui);
        roll_select(active_pattern, ui, roll_lane(track()));
    }
    ui.rec_armed = false;
    if (ui.recording) set_recording(false);
    send({Type::Stop});
}

// The tempo in play: the global one, or with BPM per pattern the lead pattern's own.
void Context::set_tempo(int tenths) {
    tenths = std::clamp(tenths, 300, 3000);
    touch_tempo(*this);
    if (project.seq_tempo) {
        project.pattern_tempo[ui.lead_pattern % pattern_count] = uint16_t(tenths);
        send({Type::PatternTempo, 0, 0, ui.lead_pattern, int16_t(tenths)});
        return;
    }
    project.tempo = uint16_t(tenths);
    send({Type::Tempo, 0, 0, 0, int16_t(project.tempo)});
}

void Context::tap_tempo() {
    if (tap_count && now - taps[(tap_count - 1) % taps.size()] > 2000) tap_count = 0; // a pause starts over
    taps[tap_count % taps.size()] = now;
    ++tap_count;
    if (tap_count < 2) return;
    unsigned n = std::min<unsigned>(tap_count, unsigned(taps.size()));
    uint32_t first = taps[(tap_count - n) % taps.size()], last = taps[(tap_count - 1) % taps.size()];
    if (last > first) set_tempo(int(600000.0 * (n - 1) / double(last - first) + 0.5));
}

} // namespace melodee
